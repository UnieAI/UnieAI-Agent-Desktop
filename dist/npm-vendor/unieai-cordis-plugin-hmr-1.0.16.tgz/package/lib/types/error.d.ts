import { Context } from '@unieai/cordis';
/** Log HMR build failures with code frames when source locations are available. */
export declare function handleError(ctx: Context, e: any): void;
//# sourceMappingURL=error.d.ts.map