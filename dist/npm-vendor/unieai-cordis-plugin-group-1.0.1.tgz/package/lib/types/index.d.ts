import { Group } from '@unieai/cordis-plugin-loader';
export default Group;
//# sourceMappingURL=index.d.ts.map