/** Execution-time authority checks for the model-facing goal tools. */
import type { Context } from '@unieai/cordis';
import type { Agent } from '@unieai/uad-agent';
import type { GoalView } from '@unieai/uad-goal';
import type { SessionEvent } from '@unieai/uad-session';
import type { ToolRunContext } from '@unieai/uad-tools';
type TurnStartEvent = Extract<SessionEvent, {
    type: 'turn/start';
}>;
/** Current open turn plus the events accepted after its start boundary. */
export interface GoalToolExecution {
    readonly agent: Agent;
    readonly start: TurnStartEvent;
    readonly events: readonly SessionEvent[];
}
/** Hard authority granted to one state-changing call. */
export type GoalToolAuthority = {
    readonly kind: 'direct-human';
} | {
    readonly kind: 'goal-round';
    readonly goal: GoalView;
};
/**
 * Resolve and authenticate the calling agent and its driver boundary.
 * @param ctx - Context carrying the live agent registry.
 * @param exec - Tool execution metadata supplied by the registry.
 * @returns The authenticated agent and its current turn window.
 */
export declare function goalToolExecution(ctx: Context, exec: ToolRunContext): GoalToolExecution;
/**
 * Require authority originating in a human message accepted by a runtime root.
 * @param ctx - Context carrying the live agent graph.
 * @param execution - Authenticated current tool execution.
 */
export declare function requireDirectHuman(ctx: Context, execution: GoalToolExecution): void;
/**
 * Resolve completion authority from either direct human input or the exact goal round.
 * @param ctx - Context carrying live agents and goal state.
 * @param execution - Authenticated current tool execution.
 * @returns The direct-human or exact-goal-round authority grant.
 */
export declare function completionAuthority(ctx: Context, execution: GoalToolExecution): GoalToolAuthority;
export {};
//# sourceMappingURL=authority.d.ts.map