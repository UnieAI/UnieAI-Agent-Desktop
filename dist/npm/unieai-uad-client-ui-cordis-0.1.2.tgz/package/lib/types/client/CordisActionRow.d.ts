/** Localized cards for `cordis_stop` and `cordis_undefine`. */
import type { PropsLocale } from '@unieai/uad-client-ui-slots';
import type { ToolCallViewProps } from '@unieai/uad-client-ui-tool/client';
/** Full action-card props composed by the keyed Tool slot. */
export type CordisActionRowProps = ToolCallViewProps & PropsLocale<'cordis'>;
/** Render one Stop or Remove call with Cordis-owned localized copy. */
export declare function CordisActionRow({ callId, toolName, block, inspect, t }: CordisActionRowProps): import("react").JSX.Element;
//# sourceMappingURL=CordisActionRow.d.ts.map