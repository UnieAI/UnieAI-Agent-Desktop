/**
 * Browser plugin owning Session export download state, its sidebar row menu
 * entry, and the frame-wide modal both that entry and `/export` report through.
 */
import type { ClientContext } from '@unieai/uad-client-runtime/client';
import { SessionLogDownloadController } from './controller.ts';
import { type SessionLogDownloadKey } from './locales.ts';
declare module '@unieai/cordis' {
    interface Context {
        sessionLogDownload: SessionLogDownloadController;
    }
}
declare module '@unieai/uad-client-ui-slots' {
    interface LocaleNamespaceMap {
        'session-log-download': SessionLogDownloadKey;
    }
}
export type { SessionLogDownloadEntry, SessionLogDownloadState } from './controller.ts';
export declare const inject: string[];
/**
 * Provide the download controller, add its row to every sidebar session row's
 * overflow menu, and mount the result modal on the frame-wide overlay.
 * @param ctx - browser context carrying slots and locale services.
 */
export declare function apply(ctx: ClientContext): void;
export type { SessionLogDownloadDialogProps, SessionLogDownloadOverlayInjected, SessionLogDownloadOverlayProps, } from './Dialog.tsx';
export type { SessionLogDownloadRowActionInjected, SessionLogDownloadRowActionProps } from './RowMenuAction.tsx';
//# sourceMappingURL=index.d.ts.map