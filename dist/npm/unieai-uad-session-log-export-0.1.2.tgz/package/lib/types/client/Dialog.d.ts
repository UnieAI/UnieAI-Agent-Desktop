import type { ObservableSnapshot, SessionId } from '@unieai/uad-client-runtime/client';
import type { InjectFace, PropsLocale, PropsRuntime } from '@unieai/uad-client-ui-slots';
import type { SessionLogDownloadState } from './controller.ts';
import { NS } from './locales.ts';
/** Browser state and dismissal injected into the frame-wide dialog contribution. */
export interface SessionLogDownloadOverlayInjected {
    hooks: {
        sessionLogDownload: ObservableSnapshot<SessionLogDownloadState>;
    };
    dismiss: (sessionId: SessionId) => void;
}
/**
 * Full overlay props: the frame's empty owner share plus the bound controller
 * state, dismissal, and localized copy.
 */
export type SessionLogDownloadOverlayProps = PropsRuntime<'shell.overlay'> & PropsLocale<typeof NS> & InjectFace<SessionLogDownloadOverlayInjected>;
/** One Session's dialog share, composed by the overlay from its own props. */
export type SessionLogDownloadDialogProps = Pick<SessionLogDownloadOverlayProps, 'useSessionLogDownload' | 'dismiss' | 't'> & {
    /** Session whose download entry this dialog reports. */
    sessionId: SessionId;
};
/**
 * Modal reporting one Session's download outcome.
 * @param props - Session id, bound controller state, dismissal, and localized copy.
 * @returns the modal portal contribution.
 */
export declare function SessionLogDownloadDialog({ sessionId, useSessionLogDownload, dismiss, t, }: SessionLogDownloadDialogProps): import("react").JSX.Element;
/**
 * Frame-wide seat for every Session's download dialog.
 *
 * The dialog cannot live where the gesture starts: the sidebar row's menu row
 * unmounts the moment the menu closes, and `/export` runs with no Session
 * surface open at all. `shell.overlay` outlives both, so one entry reports
 * whichever Sessions currently have an open dialog.
 * @param props - bound controller state, dismissal, and localized copy.
 * @returns one dialog per Session with an open download entry.
 */
export declare function SessionLogDownloadOverlay(props: SessionLogDownloadOverlayProps): import("react").JSX.Element;
//# sourceMappingURL=Dialog.d.ts.map