/** Package-owned background-job snapshot invariants. @module @unieai/uad-jobs/invariant */
import type { Context } from '@unieai/cordis';
/** Cordis companion plugin name. */
export declare const name = "jobs-invariant";
/** Service required before the companion can reserve package ownership. */
export declare const inject: string[];
/**
 * Register the job-registry invariant companion.
 * @param ctx - Cordis context carrying the invariant service.
 * @returns the installed registration's disposer after setup succeeds.
 */
export declare const apply: (ctx: Context) => Promise<() => void>;
//# sourceMappingURL=invariant.d.ts.map