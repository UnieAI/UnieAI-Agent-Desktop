/** `settings.locale` namespace dictionaries (the Language row's copy). */
/** Simplified Chinese dictionary (the key-set source of truth). */
export declare const zh: {
    'language.title': string;
};
/** The settings.locale namespace key union. */
export type SettingsLocaleKey = keyof typeof zh;
/** English dictionary, checked complete against the zh key set. */
export declare const en: {
    'language.title': string;
};
/** Traditional Chinese dictionary, checked complete against the zh key set. */
export declare const zhTW: {
    'language.title': string;
};
/** Japanese dictionary, checked complete against the zh key set. */
export declare const ja: {
    'language.title': string;
};
//# sourceMappingURL=settings.d.ts.map