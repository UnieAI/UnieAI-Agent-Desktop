/**
 * Reduce a picked image to the square the account's avatar is stored as.
 *
 * The web product's profile form does this before it uploads, and the desktop
 * must do the same for one concrete reason: the avatar travels and is stored
 * as a base64 data URL, so an uncropped phone photo would put several
 * megabytes into the account row and into every later profile read on BOTH
 * surfaces. Cropping centred to 512px is what keeps that a few hundred
 * kilobytes.
 *
 * The reference also paints the canvas white before drawing. That fill is
 * unreachable there and is not reproduced here: the source rectangle is the
 * largest centred square of the image and it is drawn over the whole canvas,
 * so no pixel is ever left unpainted.
 */
/** Encoding of the stored square; PNG, as the reference encodes it. */
export declare const CROPPED_MIME_TYPE = "image/png";
/** File extension matching {@link CROPPED_MIME_TYPE}. */
export declare const CROPPED_EXTENSION = ".png";
/**
 * Crop one image to a centred square and re-encode it.
 * @param src - the picked image as a data URL.
 * @returns the cropped square as a PNG data URL.
 * @throws when the image cannot be decoded, carries no pixels, or the document
 * grants no 2D drawing context — each of which leaves nothing to store.
 */
export declare function centerCropSquare(src: string): Promise<string>;
//# sourceMappingURL=center-crop.d.ts.map