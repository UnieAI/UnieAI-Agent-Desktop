import type { Translate } from '@deepseek-ai/dsh-client-ui-slots';
import type { UnieAiAccountIdentity, UnieAiProfilePatch, UnieAiProfileSaveResult } from '../account-contract.ts';
import type { AccountKey } from './locales.ts';
/** Props of the profile form. */
export interface ProfileFormProps {
    /** The stored identity this form edits. */
    identity: UnieAiAccountIdentity;
    /** Section copy. */
    t: Translate<AccountKey>;
    /**
     * Store the change.
     * @param patch - the display name, and an avatar only when one was picked.
     * @returns whether the supplier stored it.
     */
    saveProfile: (patch: UnieAiProfilePatch) => Promise<UnieAiProfileSaveResult>;
}
/**
 * Render the profile form.
 * @param props - the stored identity, section copy, and the save.
 * @returns the form element tree.
 */
export declare function ProfileForm({ identity, t, saveProfile }: ProfileFormProps): import("react").JSX.Element;
//# sourceMappingURL=ProfileForm.d.ts.map