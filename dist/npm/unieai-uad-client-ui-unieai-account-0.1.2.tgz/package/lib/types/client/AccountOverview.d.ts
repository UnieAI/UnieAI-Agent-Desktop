/**
 * The Overview header of the Account section, in the arrangement the UnieAI
 * web product's settings page uses: a 64px identity mark, the display name,
 * the plan under it, and the five-cell activity strip.
 *
 * The header is also the profile EDITOR — see {@link ProfileHeader}. There is
 * no second card printing the same name and the same photo below it: one fact,
 * one place on the page, and that place is where it is changed.
 *
 * The second line is the plan and only the plan. The web product prints
 * `@handle · Plan` there; this product has no handle — no column, no route,
 * nothing to report one — and the address that used to stand in for it already
 * has a home in the session card below, so standing it in here printed the
 * same address twice on one page.
 *
 * The strip is drawn in every state, because it is what this screen IS — but
 * a cell whose figure the supplier has not reported reads as unknown, never
 * as zero. With no gateway composed there is no account at all, so every cell
 * is unknown and the name says nobody is signed in.
 */
import type { Translate } from '@unieai/uad-client-ui-slots';
import type { UnieAiAccount, UnieAiProfilePatch, UnieAiProfileSaveResult } from '../account-contract.ts';
import type { AccountKey } from './locales.ts';
/** Props of the Overview header. */
export interface AccountOverviewProps {
    /** The account, when one is loaded; absent in every other state. */
    account: UnieAiAccount | undefined;
    /** Section copy. */
    t: Translate<AccountKey>;
    /**
     * Store a name or avatar change. Only a loaded account has anything to
     * store, so the header edits nothing in the other states.
     * @param patch - the change to store.
     * @returns whether the supplier stored it.
     */
    saveProfile: (patch: UnieAiProfilePatch) => Promise<UnieAiProfileSaveResult>;
}
/**
 * Render the identity header and the activity strip.
 * @param props - the account (when loaded), section copy, and the save.
 * @returns the overview element tree.
 */
export declare function AccountOverview({ account, t, saveProfile }: AccountOverviewProps): import("react").JSX.Element;
//# sourceMappingURL=AccountOverview.d.ts.map