import type { Translate } from '@unieai/uad-client-ui-slots';
import type { UnieAiInviteResult } from '../account-contract.ts';
import type { AccountKey } from './locales.ts';
/**
 * Whether an address is worth sending. One local address part, one `@`, and a
 * dotted domain — the shape below which the request cannot succeed, so the
 * button says so before a round trip. Everything narrower than that is the
 * supplier's rule and is not repeated here.
 * @param email - the address as typed, already trimmed.
 * @returns whether the dialog will submit it.
 */
export declare function isPlausibleEmail(email: string): boolean;
/** Props of the invite dialog. */
export interface InviteFriendDialogProps {
    /** Whether the dialog is showing. */
    open: boolean;
    /** Section copy. */
    t: Translate<AccountKey>;
    /**
     * Invite one address. Required rather than optional: the card mounts this
     * dialog only where the gateway offers the write, so a Send that cannot send
     * is unreachable rather than disabled.
     * @param email - the address to invite, trimmed.
     * @returns what the attempt established.
     */
    sendInvite: (email: string) => Promise<UnieAiInviteResult>;
    /** Dismiss the dialog; the caller stops rendering it. */
    onClose: () => void;
}
/**
 * Render the invite dialog.
 * @param props - visibility, copy, the send gesture, and dismissal.
 * @returns the dialog element tree; nothing while closed.
 */
export declare function InviteFriendDialog({ open, t, sendInvite, onClose }: InviteFriendDialogProps): import("react").JSX.Element;
//# sourceMappingURL=InviteFriendDialog.d.ts.map