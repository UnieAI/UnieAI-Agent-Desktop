import type { Translate } from '@unieai/uad-client-ui-slots';
import type { UnieAiAvatarUpload } from '../account-contract.ts';
import type { AccountKey } from './locales.ts';
/** Props of the change-avatar dialog. */
export interface AvatarEditorDialogProps {
    /** Whether the dialog is showing. */
    open: boolean;
    /** Whether a profile save is in flight, which freezes both actions. */
    saving: boolean;
    /** Section copy. */
    t: Translate<AccountKey>;
    /** Close without choosing anything. */
    onClose: () => void;
    /**
     * A new avatar was confirmed.
     * @param upload - the image to store.
     * @param animated - whether it was passed through rather than cropped, which
     * the caller reports in different words.
     */
    onPicked: (upload: UnieAiAvatarUpload, animated: boolean) => void;
    /**
     * The pick could not be used.
     * @param message - localized text explaining why.
     */
    onFailed: (message: string) => void;
}
/**
 * Render the change-avatar dialog.
 * @param props - visibility, copy, and the three outcomes.
 * @returns the dialog element tree; nothing while closed.
 */
export declare function AvatarEditorDialog({ open, saving, t, onClose, onPicked, onFailed }: AvatarEditorDialogProps): import("react").JSX.Element;
//# sourceMappingURL=AvatarEditorDialog.d.ts.map