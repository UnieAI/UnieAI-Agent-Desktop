/**
 * The Invite friends settings section: the account's referral standing and the
 * one write the product actually offers on it. A page of its own, for the same
 * reason usage is one — inviting someone is a task, not a paragraph at the
 * bottom of the account page.
 *
 * Signed out it draws the not-connected card rather than leaving the nav row
 * pointing at a blank page or removing the row entirely; the reasoning is
 * written out in {@link UsageSection}, and the two pages answer it the same
 * way on purpose.
 */
import type { InjectFace, PropsLocale, PropsRuntime } from '@unieai/uad-client-ui-slots';
import type { UnieAiInviteResult } from '../account-contract.ts';
import type { AccountSource } from './account-source.ts';
/** Injected business face of the invite section (slot `inject`). */
export interface InviteSectionInjected {
    hooks: {
        /** Account state, bound by the UI renderer as useAccount. */
        account: AccountSource;
    };
    /** Start or retry the device-code sign-in. */
    signIn: () => void;
    /**
     * Invite one address, when the composed gateway offers the write.
     * @param email - the address to invite, as typed.
     * @returns what the attempt established.
     */
    sendInvite: ((email: string) => Promise<UnieAiInviteResult>) | undefined;
}
/** Full component props: runtime share + locale seat + injected face. */
export type InviteSectionComponentProps = PropsRuntime<'settings.section'> & PropsLocale<'settings.account'> & InjectFace<InviteSectionInjected>;
/**
 * Render the invite section.
 * @param props - composed slot props.
 * @returns the section element tree.
 */
export declare function InviteSection(props: InviteSectionComponentProps): import("react").JSX.Element;
//# sourceMappingURL=InviteSection.d.ts.map