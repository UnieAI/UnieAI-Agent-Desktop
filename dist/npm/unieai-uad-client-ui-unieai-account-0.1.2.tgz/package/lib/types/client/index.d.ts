/**
 * UnieAI account settings plugin, browser half: registers THREE settings pages
 * over one account state — Account (identity, profile editing, token
 * activity, the session), Regular usage limits, and Invite friends — as the
 * first pages of the settings panel, plus the account row at the sidebar's
 * foot, which is where the same identity appears while the panel is closed.
 *
 * Three pages rather than one page with three anchors: usage and invites are
 * each a topic a reader opens the panel for on its own, and the panel's nav is
 * the only thing that can say so. Every page renders in every account state —
 * a page that vanished when the session did would move the nav rows under the
 * reader's aim and would leave the account menu's row opening whichever page
 * happened to be first.
 *
 * The data comes from a desktop BFF, reached through whatever plugin provides
 * the `unieaiAccount` gateway service (see `src/account-contract.ts`). Until
 * one does, the section renders its not-connected card: this package calls no
 * endpoint and ships no sample account.
 *
 * Appearance and language are deliberately absent — `ui-theme` and `locale`
 * already own those rows in the General section.
 *
 * Export discipline: packages/client/AGENTS.md.
 */
import type { ClientContext } from '@unieai/uad-client-runtime/client';
export type { UnieAiAccount, UnieAiAccountGateway, UnieAiAccountIdentity, UnieAiAccountPlan, UnieAiAccountState, UnieAiActivity, UnieAiActivityDay, UnieAiActivityStatId, UnieAiActivityStats, UnieAiAvatarUpload, UnieAiInviteRefusal, UnieAiInviteResult, UnieAiInvites, UnieAiProfilePatch, UnieAiProfileSaveReason, UnieAiProfileSaveResult, UnieAiSentInvite, UnieAiUsageQuota, } from '../account-contract.ts';
export { ACCOUNT_GATEWAY_SERVICE, ACTIVITY_STAT_IDS, PROFILE_SAVE_REASONS, } from '../account-contract.ts';
export type { AccountSectionComponentProps, AccountSectionInjected } from './AccountSection.tsx';
export type { UsageSectionComponentProps, UsageSectionInjected } from './UsageSection.tsx';
export type { InviteSectionComponentProps, InviteSectionInjected } from './InviteSection.tsx';
export type { AccountLocaleState, SidebarAccountRowComponentProps, SidebarAccountRowInjected, } from './SidebarAccountRow.tsx';
export type { AccountKey } from './locales.ts';
/**
 * Required services (cordis fiber inject). `settings.section` is declared by
 * ui-settings-general's apply, whose activation order relative to this one is
 * NOT constrained; the registration waits on the declaration through
 * `slots.inject()`. The account gateway is deliberately not injected: its
 * absence is a state this section renders, not a reason to stay pending.
 */
export declare const inject: string[];
/**
 * Register the Account section over whatever account gateway this composition
 * provides, and the section's dictionaries.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map