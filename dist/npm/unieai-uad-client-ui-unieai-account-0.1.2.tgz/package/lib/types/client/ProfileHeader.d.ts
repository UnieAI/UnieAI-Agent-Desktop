import type { Translate } from '@unieai/uad-client-ui-slots';
import type { UnieAiAccountIdentity, UnieAiProfilePatch, UnieAiProfileSaveResult } from '../account-contract.ts';
import type { AccountKey } from './locales.ts';
/** Props of the editable identity header. */
export interface ProfileHeaderProps {
    /** The stored identity this header draws and edits. */
    identity: UnieAiAccountIdentity;
    /** The plan line under the name; absent where the supplier reported none. */
    planLabel: string | undefined;
    /** Section copy. */
    t: Translate<AccountKey>;
    /**
     * Store the change.
     * @param patch - the display name, and an avatar only when one was picked.
     * @returns whether the supplier stored it.
     */
    saveProfile: (patch: UnieAiProfilePatch) => Promise<UnieAiProfileSaveResult>;
}
/**
 * Render the identity header with its in-place editor.
 * @param props - the stored identity, the plan line, section copy, and the save.
 * @returns the header element tree.
 */
export declare function ProfileHeader({ identity, planLabel, t, saveProfile }: ProfileHeaderProps): import("react").JSX.Element;
//# sourceMappingURL=ProfileHeader.d.ts.map