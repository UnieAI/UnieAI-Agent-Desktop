/**
 * The Regular usage limits settings section: how much of each allowance the
 * account has left, and when it resets. A page of its own rather than a block
 * inside Account, because "how much have I got left?" is a question a reader
 * opens the panel for on its own, and the panel's nav is what tells them the
 * answer has a place.
 *
 * Signed out, this page draws the same not-connected card the Account page
 * does instead of vanishing from the nav. Two reasons, and both are about the
 * reader rather than about tidiness: a nav whose rows appear and disappear
 * with the session moves the rows the reader was aiming at, and the account
 * menu's Usage row opens THIS id — a section that is not registered would fall
 * the panel back to whichever page happens to be first, so the row would
 * quietly open something else. The card says why the page is empty and offers
 * the one action that fills it.
 */
import type { InjectFace, PropsLocale, PropsRuntime } from '@unieai/uad-client-ui-slots';
import type { AccountSource } from './account-source.ts';
/** Injected business face of the usage section (slot `inject`). */
export interface UsageSectionInjected {
    hooks: {
        /** Account state, bound by the UI renderer as useAccount. */
        account: AccountSource;
    };
    /** Start or retry the device-code sign-in. */
    signIn: () => void;
}
/** Full component props: runtime share + locale seat + injected face. */
export type UsageSectionComponentProps = PropsRuntime<'settings.section'> & PropsLocale<'settings.account'> & InjectFace<UsageSectionInjected>;
/**
 * Render the usage section.
 * @param props - composed slot props.
 * @returns the section element tree.
 */
export declare function UsageSection(props: UsageSectionComponentProps): import("react").JSX.Element;
//# sourceMappingURL=UsageSection.d.ts.map