/**
 * Account copy, shared by the three settings sections this package registers
 * (Account, Regular usage limits, Invite friends) and by the sidebar's account
 * menu. The wording tracks the UnieAI web product's personal settings
 * (`Settings` / `SettingsPage` / `SettingsSubscription` / `InviteFriend` /
 * `SettingsUsageBilling` namespaces) so the desktop app reads as the same
 * product; the shipped Chinese locale here is `zh` (Simplified), matching
 * every other dictionary in this repository.
 *
 * The Usage and Invite navigation rows are labelled from `menu.usage` and
 * `menu.invite` rather than from nav keys of their own: the account menu row
 * and the settings-panel row open the SAME page, and one page named two ways
 * is how a reader ends up believing there are two.
 */
/** Simplified Chinese dictionary (the key-set source of truth). */
export declare const zh: {
    nav: string;
    title: string;
    intro: string;
    'connect.eyebrow': string;
    'connect.body': string;
    'connect.action': string;
    'connect.unavailable': string;
    'connect.failed': string;
    'connect.retry': string;
    'row.signedOut': string;
    'menu.profile': string;
    'menu.usage': string;
    'menu.invite': string;
    'menu.lightMode': string;
    'menu.darkMode': string;
    'menu.language': string;
    'menu.signOut': string;
    'stat.totalTokens': string;
    'stat.peakTokens': string;
    'stat.longestTask': string;
    'stat.currentStreak': string;
    'stat.longestStreak': string;
    'activity.title': string;
    'activity.daily': string;
    'activity.weekly': string;
    'activity.cumulative': string;
    'activity.cell': string;
    'activity.empty': string;
    'profile.email': string;
    'profile.managed': string;
    'profile.signOut': string;
    'profile.displayName': string;
    'profile.displayNameRequired': string;
    'profile.editName': string;
    'profile.save': string;
    'profile.saving': string;
    'profile.updated': string;
    'profile.updateFailed': string;
    'profile.changeAvatar': string;
    'profile.selectAvatar': string;
    'profile.unsupportedImage': string;
    'profile.readImageFailed': string;
    'profile.avatarUpdated': string;
    'profile.avatarUpdatedGif': string;
    'profile.saveAvatarFailed': string;
    'profile.cancel': string;
    'profile.confirm': string;
    'profile.close': string;
    'plan.title': string;
    'usage.title': string;
    'usage.intro': string;
    'usage.remaining': string;
    'usage.unlimited': string;
    'usage.resetAt': string;
    'usage.resetEvery': string;
    'usage.empty': string;
    'invite.title': string;
    'invite.body': string;
    'invite.reward': string;
    'invite.credits': string;
    'invite.sentCount': string;
    'invite.noneSent': string;
    'invite.empty': string;
    'invite.compose': string;
    'invite.emailPlaceholder': string;
    'invite.send': string;
    'invite.sending': string;
    'invite.sentBody': string;
    'invite.errorToast': string;
    'invite.errorInvalidEmail': string;
    'invite.errorSelfInvite': string;
    'invite.errorAlreadyInvited': string;
    'invite.unsupported': string;
    'invite.copy': string;
    'invite.copied': string;
    'invite.copyFailed': string;
    'general.hint': string;
};
/** The account namespace key union. */
export type AccountKey = keyof typeof zh;
declare module '@unieai/uad-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** The Account settings section's copy. */
        'settings.account': AccountKey;
    }
}
/** English dictionary, checked complete against the zh key set. */
export declare const en: {
    nav: string;
    title: string;
    intro: string;
    'connect.eyebrow': string;
    'connect.body': string;
    'connect.action': string;
    'connect.unavailable': string;
    'connect.failed': string;
    'connect.retry': string;
    'row.signedOut': string;
    'menu.profile': string;
    'menu.usage': string;
    'menu.invite': string;
    'menu.lightMode': string;
    'menu.darkMode': string;
    'menu.language': string;
    'menu.signOut': string;
    'stat.totalTokens': string;
    'stat.peakTokens': string;
    'stat.longestTask': string;
    'stat.currentStreak': string;
    'stat.longestStreak': string;
    'activity.title': string;
    'activity.daily': string;
    'activity.weekly': string;
    'activity.cumulative': string;
    'activity.cell': string;
    'activity.empty': string;
    'profile.email': string;
    'profile.managed': string;
    'profile.signOut': string;
    'profile.displayName': string;
    'profile.displayNameRequired': string;
    'profile.editName': string;
    'profile.save': string;
    'profile.saving': string;
    'profile.updated': string;
    'profile.updateFailed': string;
    'profile.changeAvatar': string;
    'profile.selectAvatar': string;
    'profile.unsupportedImage': string;
    'profile.readImageFailed': string;
    'profile.avatarUpdated': string;
    'profile.avatarUpdatedGif': string;
    'profile.saveAvatarFailed': string;
    'profile.cancel': string;
    'profile.confirm': string;
    'profile.close': string;
    'plan.title': string;
    'usage.title': string;
    'usage.intro': string;
    'usage.remaining': string;
    'usage.unlimited': string;
    'usage.resetAt': string;
    'usage.resetEvery': string;
    'usage.empty': string;
    'invite.title': string;
    'invite.body': string;
    'invite.reward': string;
    'invite.credits': string;
    'invite.sentCount': string;
    'invite.noneSent': string;
    'invite.empty': string;
    'invite.compose': string;
    'invite.emailPlaceholder': string;
    'invite.send': string;
    'invite.sending': string;
    'invite.sentBody': string;
    'invite.errorToast': string;
    'invite.errorInvalidEmail': string;
    'invite.errorSelfInvite': string;
    'invite.errorAlreadyInvited': string;
    'invite.unsupported': string;
    'invite.copy': string;
    'invite.copied': string;
    'invite.copyFailed': string;
    'general.hint': string;
};
/**
 * The product-published copy in the two locales this package's own
 * dictionaries do not otherwise cover, taken verbatim from the UnieAI web
 * product's `AgentNext`, `Settings`, `SettingsPage`, `SettingsSubscription`
 * and `InviteFriend` messages rather than translated here — plus the handful
 * of lines this section had to write itself (an invite balance, an empty
 * heatmap, a cell's tooltip), which are authored in all four locales because
 * the product publishes no equivalent to copy.
 *
 * They are deliberately PARTIAL. Locale lookup falls back per key to the
 * English dictionary, so registering only the keys that are actually settled
 * gives a zh-TW or ja reader the product's own wording where it exists while
 * every other key keeps resolving exactly as it does today. The alternative —
 * a complete dictionary — would mean inventing translations for the keys the
 * product never published.
 */
export declare const partialZhTW: Partial<Record<AccountKey, string>>;
/** Japanese half of the same partial copy. */
export declare const partialJa: Partial<Record<AccountKey, string>>;
/**
 * Traditional Chinese copy.
 *
 * The lines the web product publishes are the ones `partialZhTW` carries
 * verbatim, and they are kept exactly. The rest are this package's own words —
 * states the product's page cannot be in — and translating OUR copy is not
 * inventing the product's, which is why they are here rather than falling back
 * to English and leaving the page half translated.
 */
export declare const zhTW: {
    nav: string;
    title: string;
    intro: string;
    'connect.eyebrow': string;
    'connect.body': string;
    'connect.action': string;
    'connect.unavailable': string;
    'connect.failed': string;
    'connect.retry': string;
    'row.signedOut': string;
    'menu.profile': string;
    'menu.usage': string;
    'menu.invite': string;
    'menu.lightMode': string;
    'menu.darkMode': string;
    'menu.language': string;
    'menu.signOut': string;
    'stat.totalTokens': string;
    'stat.peakTokens': string;
    'stat.longestTask': string;
    'stat.currentStreak': string;
    'stat.longestStreak': string;
    'activity.title': string;
    'activity.daily': string;
    'activity.weekly': string;
    'activity.cumulative': string;
    'activity.cell': string;
    'activity.empty': string;
    'profile.email': string;
    'profile.managed': string;
    'profile.signOut': string;
    'profile.displayName': string;
    'profile.displayNameRequired': string;
    'profile.editName': string;
    'profile.save': string;
    'profile.saving': string;
    'profile.updated': string;
    'profile.updateFailed': string;
    'profile.changeAvatar': string;
    'profile.selectAvatar': string;
    'profile.unsupportedImage': string;
    'profile.readImageFailed': string;
    'profile.avatarUpdated': string;
    'profile.avatarUpdatedGif': string;
    'profile.saveAvatarFailed': string;
    'profile.cancel': string;
    'profile.confirm': string;
    'profile.close': string;
    'plan.title': string;
    'usage.title': string;
    'usage.intro': string;
    'usage.remaining': string;
    'usage.unlimited': string;
    'usage.resetAt': string;
    'usage.resetEvery': string;
    'usage.empty': string;
    'invite.title': string;
    'invite.body': string;
    'invite.reward': string;
    'invite.credits': string;
    'invite.sentCount': string;
    'invite.noneSent': string;
    'invite.empty': string;
    'invite.compose': string;
    'invite.emailPlaceholder': string;
    'invite.send': string;
    'invite.sending': string;
    'invite.sentBody': string;
    'invite.errorToast': string;
    'invite.errorInvalidEmail': string;
    'invite.errorSelfInvite': string;
    'invite.errorAlreadyInvited': string;
    'invite.unsupported': string;
    'invite.copy': string;
    'invite.copied': string;
    'invite.copyFailed': string;
    'general.hint': string;
};
/** Japanese copy, on the same terms as {@link zhTW}. */
export declare const ja: {
    nav: string;
    title: string;
    intro: string;
    'connect.eyebrow': string;
    'connect.body': string;
    'connect.action': string;
    'connect.unavailable': string;
    'connect.failed': string;
    'connect.retry': string;
    'row.signedOut': string;
    'menu.profile': string;
    'menu.usage': string;
    'menu.invite': string;
    'menu.lightMode': string;
    'menu.darkMode': string;
    'menu.language': string;
    'menu.signOut': string;
    'stat.totalTokens': string;
    'stat.peakTokens': string;
    'stat.longestTask': string;
    'stat.currentStreak': string;
    'stat.longestStreak': string;
    'activity.title': string;
    'activity.daily': string;
    'activity.weekly': string;
    'activity.cumulative': string;
    'activity.cell': string;
    'activity.empty': string;
    'profile.email': string;
    'profile.managed': string;
    'profile.signOut': string;
    'profile.displayName': string;
    'profile.displayNameRequired': string;
    'profile.editName': string;
    'profile.save': string;
    'profile.saving': string;
    'profile.updated': string;
    'profile.updateFailed': string;
    'profile.changeAvatar': string;
    'profile.selectAvatar': string;
    'profile.unsupportedImage': string;
    'profile.readImageFailed': string;
    'profile.avatarUpdated': string;
    'profile.avatarUpdatedGif': string;
    'profile.saveAvatarFailed': string;
    'profile.cancel': string;
    'profile.confirm': string;
    'profile.close': string;
    'plan.title': string;
    'usage.title': string;
    'usage.intro': string;
    'usage.remaining': string;
    'usage.unlimited': string;
    'usage.resetAt': string;
    'usage.resetEvery': string;
    'usage.empty': string;
    'invite.title': string;
    'invite.body': string;
    'invite.reward': string;
    'invite.credits': string;
    'invite.sentCount': string;
    'invite.noneSent': string;
    'invite.empty': string;
    'invite.compose': string;
    'invite.emailPlaceholder': string;
    'invite.send': string;
    'invite.sending': string;
    'invite.sentBody': string;
    'invite.errorToast': string;
    'invite.errorInvalidEmail': string;
    'invite.errorSelfInvite': string;
    'invite.errorAlreadyInvited': string;
    'invite.unsupported': string;
    'invite.copy': string;
    'invite.copied': string;
    'invite.copyFailed': string;
    'general.hint': string;
};
//# sourceMappingURL=locales.d.ts.map