import type { Translate } from '@unieai/uad-client-ui-slots';
import type { UnieAiActivityDay } from '../account-contract.ts';
import type { AccountKey } from './locales.ts';
/** Props of the Token Activity block. */
export interface TokenActivityProps {
    /** Days that recorded usage, ascending. */
    daily: readonly UnieAiActivityDay[];
    /** Active locale id, which names the months under the grid. */
    locale: string;
    /** Section copy. */
    t: Translate<AccountKey>;
}
/**
 * Render the Token Activity block.
 * @param props - the series, the locale, and section copy.
 * @returns the block's element tree.
 */
export declare function TokenActivity({ daily, locale, t }: TokenActivityProps): import("react").JSX.Element;
//# sourceMappingURL=TokenActivity.d.ts.map