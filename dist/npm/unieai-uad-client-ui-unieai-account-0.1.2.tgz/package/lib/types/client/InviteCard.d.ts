import type { Translate } from '@unieai/uad-client-ui-slots';
import type { UnieAiInviteResult, UnieAiInvites } from '../account-contract.ts';
import type { AccountKey } from './locales.ts';
/** Props of the invite card. */
export interface InviteCardProps {
    /** The referral standing; absent where the supplier reports none. */
    invites: UnieAiInvites | undefined;
    /** Section copy. */
    t: Translate<AccountKey>;
    /**
     * Send one invite, when the gateway offers the write.
     * @param email - the address to invite, as typed.
     * @returns what the attempt established.
     */
    sendInvite: ((email: string) => Promise<UnieAiInviteResult>) | undefined;
}
/**
 * Render the invite card.
 * @param props - the referral standing, section copy, and the send gesture.
 * @returns the card element tree.
 */
export declare function InviteCard({ invites, t, sendInvite }: InviteCardProps): import("react").JSX.Element;
//# sourceMappingURL=InviteCard.d.ts.map