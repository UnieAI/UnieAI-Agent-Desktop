/**
 * Remaining usage: one meter per allowance the account reports. The section
 * shows what is LEFT (the web product's `{pct}% remaining` reading), so the
 * bar is drawn as the unspent share; an unmetered allowance has no bar at all
 * rather than a full one, which would read as "about to run out".
 *
 * The card carries no heading of its own: it is the whole body of the Regular
 * usage limits page, and that page's own title already says so. A second copy
 * of those three words is how one topic starts looking like two.
 *
 * Nothing here invents a number: an account that reports no allowances says
 * so in one line.
 */
import type { Translate } from '@unieai/uad-client-ui-slots';
import type { UnieAiUsageQuota } from '../account-contract.ts';
import type { AccountKey } from './locales.ts';
/** Props of the usage block. */
export interface UsageMetersProps {
    /** The allowances the supplier reported, in its own order. */
    usage: readonly UnieAiUsageQuota[];
    /** Section copy. */
    t: Translate<AccountKey>;
}
/**
 * Render the usage-limits card.
 * @param props - the allowances and section copy.
 * @returns the card element tree.
 */
export declare function UsageMeters({ usage, t }: UsageMetersProps): import("react").JSX.Element;
//# sourceMappingURL=UsageMeters.d.ts.map