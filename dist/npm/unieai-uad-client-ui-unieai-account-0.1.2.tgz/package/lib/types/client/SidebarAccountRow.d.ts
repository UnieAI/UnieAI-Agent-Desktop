import type { HostObservable, InjectFace, PropsLocale, PropsRuntime } from '@unieai/uad-client-ui-slots';
import type { AccountSource } from './account-source.ts';
import type { MenuLocale } from './AccountMenu.tsx';
/** Active locale plus the locales this build ships. */
export interface AccountLocaleState {
    active: string;
    locales: readonly MenuLocale[];
}
/** Injected business face of the account row (slot `inject`). */
export interface SidebarAccountRowInjected {
    hooks: {
        /** Account state, bound by the UI renderer as useAccount. */
        account: AccountSource;
        /** Resolved colour scheme, bound as useColorScheme; null with no theme service. */
        colorScheme: HostObservable<'light' | 'dark' | null>;
        /** Locale state, bound as useLocaleState. */
        localeState: HostObservable<AccountLocaleState>;
        /**
         * Whether a settings panel is composed to open, bound as
         * useSettingsPanel. A live fact rather than an apply-time snapshot:
         * cordis activation order is unconstrained, so the panel may arrive
         * after this row does.
         */
        settingsPanel: HostObservable<boolean>;
    };
    /** Start or retry the device-code sign-in. */
    signIn: () => void;
    /** Drop the local session (the gateway posts the logout and reloads). */
    signOut: () => void;
    /** Open the settings panel on one of this package's three account sections. */
    openAccountSettings: (sectionId: string) => void;
    /** Switch the theme preference. */
    setColorScheme: (scheme: 'light' | 'dark') => void;
    /** Switch the active locale. */
    setLocale: (locale: string) => void;
}
/** Full component props: runtime share + locale seat + injected face. */
export type SidebarAccountRowComponentProps = PropsRuntime<'sidebar.account'> & PropsLocale<'settings.account'> & InjectFace<SidebarAccountRowInjected>;
/**
 * Render the sidebar account row and its menu.
 * @param props - composed slot props.
 * @returns the trigger element wrapped in the menu and its tooltip.
 */
export declare function SidebarAccountRow(props: SidebarAccountRowComponentProps): import("react").JSX.Element;
//# sourceMappingURL=SidebarAccountRow.d.ts.map