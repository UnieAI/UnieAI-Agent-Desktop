/**
 * The account menu: the popup the sidebar's identity row opens, and the same
 * menu the UnieAI web product's own sidebar foot opens.
 *
 * Every row here is wired to something dsh already has. Nothing is drawn for
 * a capability this build lacks: the header prints only what the account
 * source actually reports, and Sign out exists only while a session does —
 * a menu row that would do nothing is worse than an absent one.
 *
 * Platform administration is absent for the reason it is absent in the
 * reference: that row is already conditional on `isAdmin` there, and this is
 * the personal edition, so the condition is never true and the branch does
 * not exist. Nothing was removed.
 */
import type { MenuEntry } from '@unieai/uad-client-ui-primitives';
import type { Translate } from '@unieai/uad-client-ui-slots';
import type { UnieAiAccountState } from '../account-contract.ts';
import type { AccountKey } from './locales.ts';
/**
 * The three settings sections the personal rows open. Each row opens a page of
 * its own rather than scrolling one page to a position in it: the panel's nav
 * is the tab strip here, so a row that landed mid-page would leave the nav
 * pointing at a heading the reader is no longer looking at.
 */
export declare const ACCOUNT_SECTION_ID = "unieai-account";
export declare const USAGE_SECTION_ID = "unieai-usage";
export declare const INVITE_SECTION_ID = "unieai-invite";
/** Menu row ids. Ids are the menu's own vocabulary, not a slot contract. */
export declare const MENU_IDS: {
    readonly profile: "account.profile";
    readonly usage: "account.usage";
    readonly invite: "account.invite";
    readonly appearance: "account.appearance";
    readonly language: "account.language";
    readonly signOut: "account.signOut";
    readonly signIn: "account.signIn";
};
/** Prefix marking a language submenu row; the suffix is the locale id. */
export declare const LANGUAGE_PREFIX = "account.language.";
/** One locale the menu can switch to. */
export interface MenuLocale {
    id: string;
    label: string;
}
/** Everything the menu needs to decide what it contains. */
export interface AccountMenuModel {
    /** Current account state; decides the header and whether Sign out exists. */
    state: UnieAiAccountState;
    /** Whether a settings panel is composed to open (the three personal rows). */
    canOpenSettings: boolean;
    /** Whether the theme service is composed (the appearance row). */
    canSwitchTheme: boolean;
    /** True while the resolved theme is dark, so the row offers the other one. */
    isDark: boolean;
    /** Locales the language submenu offers; empty hides the row. */
    locales: readonly MenuLocale[];
    /** Active locale id, shown as the submenu's selection. */
    activeLocale: string;
}
/**
 * Build the menu's entries for one model, in the reference's own order:
 * header, Profile, Usage, Invite friends, appearance, Language, then the
 * separator and Sign out.
 *
 * @param model - what this composition can actually do.
 * @param t - section copy.
 * @returns the ordered entries, header first.
 */
export declare function accountMenuEntries(model: AccountMenuModel, t: Translate<AccountKey>): MenuEntry[];
/**
 * The submenu selection the menu shows: the active locale's row.
 * @param activeLocale - the active locale id.
 * @returns the selected entry id.
 */
export declare function selectedLanguageId(activeLocale: string): string;
/** What a selected row asks the row component to do. */
export type AccountMenuAction = {
    kind: 'openSettings';
    section: string;
} | {
    kind: 'toggleTheme';
} | {
    kind: 'setLocale';
    locale: string;
} | {
    kind: 'signOut';
} | {
    kind: 'signIn';
} | {
    kind: 'none';
};
/**
 * Resolve a selected row id into the gesture it stands for.
 * @param id - the selected entry id.
 * @returns the action, or `none` for a row that only opens a submenu.
 */
export declare function accountMenuAction(id: string): AccountMenuAction;
//# sourceMappingURL=AccountMenu.d.ts.map