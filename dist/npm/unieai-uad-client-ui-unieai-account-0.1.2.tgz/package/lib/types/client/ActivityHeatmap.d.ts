import type { UnieAiActivityDay } from '../account-contract.ts';
import type { Translate } from '@unieai/uad-client-ui-slots';
import type { AccountKey } from './locales.ts';
/** How the cells are coloured. */
export type HeatmapMode = 'daily' | 'weekly' | 'cumulative';
/** The toggle's order, which is the web product's order. */
export declare const HEATMAP_MODES: readonly HeatmapMode[];
/** Props of the heatmap. */
export interface ActivityHeatmapProps {
    /** Days that recorded usage, ascending; days with none are absent. */
    daily: readonly UnieAiActivityDay[];
    /** Which quantity colours a cell. */
    mode: HeatmapMode;
    /** Active locale id, which names the months under the grid. */
    locale: string;
    /** Section copy. */
    t: Translate<AccountKey>;
}
/** One rendered cell. */
interface Cell {
    /** The day, as `YYYY-MM-DD`. */
    key: string;
    /** That day's tokens, whatever the mode colours by. */
    tokens: number;
    /** Shade step, 0-4. */
    level: number;
}
/**
 * Build the week columns and the month labels under them.
 * @param daily - the reported series.
 * @param mode - which quantity colours a cell.
 * @param locale - the active locale id.
 * @param now - the instant the window ends in; a parameter so a test can pin it.
 * @returns the columns, and one label slot per column (empty where the month
 * did not change).
 */
export declare function buildHeatmap(daily: readonly UnieAiActivityDay[], mode: HeatmapMode, locale: string, now: number): {
    columns: Cell[][];
    monthLabels: string[];
};
/**
 * Render the heatmap.
 * @param props - the series, the mode, the locale, and section copy.
 * @returns the grid element tree.
 */
export declare function ActivityHeatmap({ daily, mode, locale, t }: ActivityHeatmapProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=ActivityHeatmap.d.ts.map