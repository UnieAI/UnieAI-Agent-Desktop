/**
 * What the desktop does to a picked image before it becomes an avatar, in the
 * same steps and with the same values the UnieAI web product's own profile
 * form uses.
 *
 * Two of those steps matter beyond looking the same:
 *
 *  - **The accepted lists are the product's.** Its `PATCH` refuses an image
 *    whose MIME type and extension are both unknown to it, so a wider list
 *    here would only produce a picker that accepts files the save rejects.
 *  - **Everything but an animated GIF is cropped to a centred 512px square.**
 *    The avatar travels and is stored as a base64 data URL, so an uncropped
 *    phone photo would put megabytes into the account row and into every later
 *    profile read on BOTH surfaces. A GIF is passed through instead, because
 *    a canvas re-encode would keep only its first frame.
 */
import type { UnieAiAvatarUpload } from '../account-contract.ts';
/** Extensions the product accepts, in its own order. */
export declare const ACCEPTED_EXTENSIONS: readonly string[];
/** MIME types the product accepts, in its own order. */
export declare const ACCEPTED_MIME_TYPES: readonly string[];
/**
 * The accepted formats, as the file-picker area prints them. There is one
 * printing of this list, in the dialog that does the picking: the caption that
 * used to sit under the avatar belonged to a profile card the Account page no
 * longer has.
 */
export declare const FORMATS_HINT = "jpg / png / gif / webp / heic / tif / tiff";
/**
 * The extension a picked file carries, lowercased and dotted.
 * @param fileName - the file's name.
 * @returns the extension including its dot, or an empty string for a name with
 * none.
 */
export declare function extensionOf(fileName: string): string;
/**
 * Whether the product would accept this file at all.
 *
 * Either identification suffices, exactly as it does in the product's own
 * validation: a browser that reports no MIME type for a `.heic` pick must not
 * make that pick unusable.
 * @param fileName - the picked file's name.
 * @param fileType - the MIME type the browser reported, possibly empty.
 * @returns whether the pick is one of the accepted formats.
 */
export declare function isAcceptedImage(fileName: string, fileType: string): boolean;
/**
 * Describe a finished data URL as the upload the supplier is given.
 *
 * Both fields are read back out of the data URL rather than carried over from
 * the picked file, because the crop re-encodes: the stored image's own type is
 * the only one that can agree with its bytes, and the product cross-checks
 * exactly that.
 * @param dataUrl - the image to upload.
 * @returns the upload, whose MIME type and extension are empty when the data
 * URL declares no type — the supplier then falls back to its other check.
 */
export declare function describeUpload(dataUrl: string): UnieAiAvatarUpload;
/**
 * Crop one image to a centred square and re-encode it as PNG.
 *
 * The reference paints the canvas white before drawing; that fill is
 * unreachable and is not reproduced, because the source rectangle is the
 * largest centred square of the image and it is drawn over the whole canvas,
 * so no pixel is left unpainted.
 * @param src - the picked image as a data URL.
 * @returns the cropped square as a PNG data URL.
 * @throws when the image cannot be decoded, carries no pixels, or the document
 * grants no 2D drawing context — each of which leaves nothing to store.
 */
export declare function centerCropSquare(src: string): Promise<string>;
//# sourceMappingURL=avatar.d.ts.map