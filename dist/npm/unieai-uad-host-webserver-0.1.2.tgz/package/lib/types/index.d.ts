/**
 * @unieai/uad-host-webserver — Web route-registration plugin: a node:http
 * server plus the `webServer` service (HTTP and upgrade route registries, the
 * structured index injection table with raw transform taps behind it, and the
 * single fallback seat for everything no route claims). Knows no harness concepts and serves no files; the composing
 * application's frontend plugin owns dist serving through the fallback hook.
 * Web shape only — Electron loads dist over file:// and carries fetch over an
 * IPC bridge. This package never prints: the URL line belongs to the shell.
 */
import type { IncomingMessage, ServerResponse } from 'node:http';
import type { Duplex } from 'node:stream';
import { Context, Service } from '@unieai/cordis';
import z from '@unieai/schemastery';
import { type IndexInjection } from './injections.ts';
export { renderIndexInjections } from './injections.ts';
export type { IndexInjection, IndexInjectionPlacement } from './injections.ts';
declare module '@unieai/cordis' {
    interface Context {
        webServer: WebServer;
    }
    interface Events {
        /**
         * Collect the structured index injection table. Emitted on every index
         * render and every worker boot-payload request; listeners push their
         * current rows, so a row's data is read fresh at emit time.
         * @param table - Mutable row table; listeners append in activation order.
         * @mode emit
         */
        'webserver/index-inject'(table: IndexInjection[]): void;
    }
}
/** Route match kind: 'exact' matches the pathname verbatim; 'prefix' p matches p and p/<anything>. */
export type WebRouteKind = 'exact' | 'prefix';
/** One named route registration. */
export interface WebRoute {
    kind: WebRouteKind;
    /** Absolute pathname, no trailing slash. */
    path: string;
    /** Owns the full response lifecycle (may hold the response open, e.g. SSE). */
    handler: (req: IncomingMessage, res: ServerResponse) => void | Promise<void>;
}
/**
 * Decides whether one request may reach dispatch at all.
 *
 * `true` continues to the route table. `false` means the guard has already
 * answered — it owns the status, the body, and, on the upgrade path, the
 * socket. `reply.socket` is present only for upgrade requests.
 */
export type WebGuard = (req: IncomingMessage, reply: {
    res?: ServerResponse;
    socket?: Duplex;
}) => boolean | Promise<boolean>;
/** One exact-path HTTP upgrade registration. */
export interface WebUpgradeRoute {
    /** Absolute pathname, no trailing slash. */
    path: string;
    /** Owns protocol negotiation and the upgraded socket after dispatch. */
    handler: (req: IncomingMessage, socket: Duplex, head: Buffer) => void | Promise<void>;
}
/** Gateway config: the listen address. */
export interface Config {
    /** Listen host; the two supported values are loopback and all-interfaces. */
    host: '127.0.0.1' | '0.0.0.0';
    /** Listen port; zero requests an OS-assigned port. */
    port: number;
}
/**
 * The browser HTTP carrier service. Activation listens immediately. Route
 * registration order does not affect requests because configured named routes
 * must be distinct, and the fallback handler answers anything not yet claimed
 * during startup with 404 until its owner registers. A listen failure rejects
 * initialization, and the boot process reports the failed fiber.
 */
export declare class WebServer extends Service {
    private config;
    static Config: z<Config>;
    private readonly exact;
    private readonly prefixes;
    private readonly upgrades;
    private readonly upgradedSockets;
    private readonly indexTaps;
    private fallback;
    private guard;
    private server;
    private listenedPort;
    constructor(ctx: Context, config: Config);
    /** The listening port (the OS-assigned value when config.port is 0). */
    get port(): number;
    /** The configured bind host (the loopback or all-interfaces literal). */
    get host(): Config['host'];
    /**
     * Register a named route. Duplicate (kind, path) throws — route patterns are
     * a composition-level contract, so a collision is a misconfiguration.
     * @param route - kind, path, and the owning handler.
     * @returns the disposer removing the route.
     */
    register(route: WebRoute): () => void;
    /**
     * Register an exact-path HTTP upgrade route. Duplicate paths throw because
     * one socket can have only one protocol owner.
     * @param route - pathname and handler owning negotiation plus socket use.
     * @returns the disposer removing the route.
     */
    registerUpgrade(route: WebUpgradeRoute): () => void;
    /**
     * Claim the fallback seat: the handler answering every request no named
     * route matches (the SPA dist server in the shipped Web composition). One
     * owner only — a second registration throws, because two fallbacks cannot
     * compose.
     * @param handler - owns the full response lifecycle of unmatched requests.
     * @returns the disposer releasing the seat.
     */
    registerFallback(handler: WebRoute['handler']): () => void;
    /**
     * Claim the request-guard seat: the one decision consulted before ANY
     * dispatch, on both the HTTP and the upgrade path.
     *
     * This exists so an authentication layer can cover every seat at once —
     * named routes, the fallback SPA, the plugin-bundle prefix, and the
     * WebSocket downlinks. Gating one route cannot do that: an anonymous visitor
     * would still be served the application shell and its boot manifest, and
     * only then fail every call it made.
     *
     * A guard that refuses OWNS the response: it writes the status and body, or
     * destroys the socket, and returns `false`. `true` continues to ordinary
     * dispatch. One owner only — two guards would have no defined precedence.
     * @param guard - decides one request; owns the response when it refuses.
     * @returns the disposer releasing the seat.
     */
    registerGuard(guard: WebGuard): () => void;
    /**
     * Consult the guard, if one is registered. A guard that throws refuses: an
     * authentication decision that cannot be reached is a decision to deny.
     * @param req - the request being admitted.
     * @param reply - the response or socket the guard owns when it refuses.
     * @returns true when dispatch may continue.
     */
    private admits;
    /**
     * Register a raw-HTML index transform, the escape hatch for markup no
     * {@link IndexInjection} row expresses: {@link renderIndex} applies taps in
     * registration order after rendering the structured rows.
     * @param transform - pure html-to-html function.
     * @returns the disposer removing the transform.
     */
    tapIndex(transform: (html: string) => string): () => void;
    /** Listen; resolves once the socket is bound (rejection = FAILED fiber). */
    [Service.init](): Promise<void>;
    /** Longest-prefix-wins over the prefix table after an exact-table miss. */
    private match;
    /**
     * Run an index.html body through the registered taps in registration order
     * — called by the fallback owner on every index response it renders.
     * @param html - the raw index.html body.
     * @returns the transformed body.
     */
    applyIndexTaps(html: string): string;
    /**
     * Gather the structured injection table: one `webserver/index-inject` emit,
     * every subscriber pushes its current rows. Fresh per call, so subscribers
     * read live state (module graph, theme preference) at emit time.
     * @returns rows in subscriber activation order.
     */
    collectIndexInjections(): IndexInjection[];
    /**
     * Render one index.html body: the structured injection table first, then
     * the raw `tapIndex` transforms over the result.
     * @param html - the raw index.html body.
     * @returns the transformed body.
     */
    renderIndex(html: string): string;
}
export default WebServer;
//# sourceMappingURL=index.d.ts.map