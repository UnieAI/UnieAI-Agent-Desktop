/** `deliverables` namespace dictionaries. */
/** Dictionary namespace owned by this plugin. */
export declare const NS = "deliverables";
/** Simplified Chinese dictionary (the key-set source of truth). */
export declare const zh: {
    'produced.label': string;
    'produced.moreOne': string;
    'produced.more': string;
    'produced.open': string;
    'produced.showInFolder': string;
};
/** English dictionary (same key set). */
export declare const en: Record<DeliverablesKey, string>;
/** Union of this namespace's dictionary keys. */
export type DeliverablesKey = keyof typeof zh;
/** Traditional Chinese dictionary (same key set). */
export declare const zhTW: Record<DeliverablesKey, string>;
/** Japanese dictionary (same key set). */
export declare const ja: Record<DeliverablesKey, string>;
//# sourceMappingURL=locales.d.ts.map