/**
 * What this session produced, collected from its own tool calls.
 *
 * An artifact panel answers "what came out of this conversation", and the
 * conversation already carries the answer: every file the agent wrote or edited
 * is a settled tool call with the path in its arguments. So this reads the
 * snapshot the panel is already subscribed to and derives a list — no host
 * call, no filesystem read, and nothing that can disagree with the transcript
 * beside it.
 *
 * WHY NOT READ THE FILES. The browser has no way to: `file-reference` lists
 * path candidates and returns no content, and adding a read would publish the
 * agent's whole filesystem to a page. It would also answer a different
 * question — a file's state NOW, rather than what this session did to it, which
 * is what a panel sitting beside the transcript is for.
 *
 * WRITES AND EDITS ONLY. A read is not an artifact: the session did not produce
 * it. `bash` is excluded for a harder reason — a command may write a dozen
 * files or none, and nothing in the call says which, so listing every command
 * would fill the panel with rows that promise a file and cannot name one.
 */
import type { ConversationSnapshot } from '@unieai/uad-client-runtime/client';
/** One thing the session produced. */
export interface SessionArtifact {
    /** The call it came from; the panel selects by this. */
    callId: string;
    /** Turn the call belongs to, which a selection target carries. */
    turnSeq: number;
    /** Path exactly as the call named it, relative or absolute. */
    path: string;
    /** The tool that produced it, for the row's second line. */
    tool: string;
    /** Whether the call has settled, and whether it failed. */
    state: 'running' | 'done' | 'error';
}
/**
 * Every artifact this session produced, newest last.
 *
 * The same path written twice appears twice on purpose: they are two acts, the
 * second may have failed, and collapsing them would hide that the last thing
 * that happened to a file was an error.
 * @param snapshot - the conversation as the panel currently sees it.
 * @returns the artifacts, in the order the session produced them.
 */
export declare function collectArtifacts(snapshot: ConversationSnapshot): SessionArtifact[];
/**
 * The file name at the end of a path, for the row's first line.
 * @param path - the path the call named.
 * @returns the last segment, or the whole path when it has no separator.
 */
export declare function fileName(path: string): string;
/**
 * Whether two collected lists describe the same artifacts.
 *
 * `collectArtifacts` derives fresh objects from every snapshot, and a
 * conversation produces a snapshot per streamed token. Comparing by reference
 * would rerender the panel on every one of them; comparing the fields the rows
 * actually display settles it in one pass over a short list.
 * @param left - one list.
 * @param right - the other.
 * @returns true when nothing the panel renders has changed.
 */
export declare function sameArtifacts(left: readonly SessionArtifact[], right: readonly SessionArtifact[]): boolean;
//# sourceMappingURL=artifacts.d.ts.map