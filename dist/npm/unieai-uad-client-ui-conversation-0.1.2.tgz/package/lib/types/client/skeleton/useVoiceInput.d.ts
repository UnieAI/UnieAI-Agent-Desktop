/**
 * Browser speech-to-text for the composer's mic control.
 *
 * A thin wrapper over the native Web Speech API, matching what the web product
 * does: recognition runs in the browser and streams interim plus final
 * transcripts back, so there is no audio endpoint to deploy and no recording
 * to store. A browser without the API reports `supported: false` and the
 * caller renders no mic rather than a control that cannot work.
 *
 * Only FINALIZED phrases reach `onFinal`. Interim text is exposed separately
 * for a live preview: appending it would make the draft rewrite itself as the
 * engine changes its mind mid-phrase.
 */
/** What the composer needs to drive and render a dictation session. */
export interface VoiceInput {
    /** Whether this browser can recognise speech at all. */
    supported: boolean;
    /** Whether a session is currently open. */
    listening: boolean;
    /** The phrase being recognised right now; empty between phrases. */
    interim: string;
    /** The last error worth showing, or null. */
    error: string | null;
    /** Open a session. A no-op while one is already open. */
    start: () => void;
    /** Close the session; `onend` clears the state. */
    stop: () => void;
}
/**
 * Drive one dictation session for the composer.
 * @param onFinal - receives each finalized phrase, already trimmed.
 * @returns the session state and its two controls.
 */
export declare function useVoiceInput(onFinal: (text: string) => void): VoiceInput;
//# sourceMappingURL=useVoiceInput.d.ts.map