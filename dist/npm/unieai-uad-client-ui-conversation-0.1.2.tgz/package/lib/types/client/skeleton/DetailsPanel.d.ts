/**
 * The details column: a tab container over everything the column can show.
 *
 * Every open thing is a tab — the workspace tree, one file, what this session
 * produced, one selected tool call — and `+` offers the same menu the empty
 * column shows. This replaced a panel that WAS one selected call: opening
 * anything took the switcher away with it, so there was no way back except
 * closing the column, and nothing the column could answer on its own was
 * reachable at all.
 *
 * The selected call is a tab like the others, but its selection lives in the
 * shared chat store rather than here, because the transcript writes it too.
 */
import type { DetailsSlotProps } from '../contract/slots.ts';
/** Full props composed by reference from the contract (automatic shares & injected share). */
export type DetailsPanelProps = DetailsSlotProps;
export declare function DetailsPanel({ useSession, useSessions, sessionId, useStore, actions, renderSlot, closeDetails, toggleDetailsMaximized, listWorkspaceEntries, readWorkspaceFile, openFile, canOpenFileHere, terminals, t, }: DetailsPanelProps): import("react").JSX.Element;
//# sourceMappingURL=DetailsPanel.d.ts.map