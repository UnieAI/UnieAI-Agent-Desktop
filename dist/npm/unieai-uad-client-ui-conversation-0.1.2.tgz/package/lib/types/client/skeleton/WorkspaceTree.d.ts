/**
 * The session's workspace, one level at a time.
 *
 * Lazy by level, never recursive. A repository has more files than a panel can
 * hold and more than a person reads at once, so a directory is listed when it
 * is opened and not before — the cost of showing the tree is the cost of what
 * someone actually looked at.
 *
 * Names only. The Host operation behind this cannot return content, and the
 * bound it enforces (a registered workspace root, a path inside it) is not
 * restated here: a presenter that re-checked it would imply it could also
 * relax it.
 */
import type { WorkspaceListing } from '@unieai/uad-client-runtime/client';
import type { DetailsSlotProps } from '../contract/slots.ts';
/** Props of the workspace file tree. */
export interface WorkspaceTreeProps {
    /** Absolute workspace root; the tree lists nothing outside it. */
    root: string;
    /** Injected Host listing, bounded to `root`. */
    list: (root: string, path?: string, signal?: AbortSignal) => Promise<WorkspaceListing>;
    /** Open a file in whatever the surface uses to show one. */
    onOpen: (path: string) => void;
    /** Path currently shown beside the tree, marked as the current row. */
    selected?: string;
    /** Lowercased substring the rows are filtered by; empty shows everything. */
    filter?: string;
    /** Locale reader; keys live in the conversation namespace. */
    t: DetailsSlotProps['t'];
}
export declare function WorkspaceTree({ root, list, onOpen, selected, filter, t }: WorkspaceTreeProps): import("react").JSX.Element;
//# sourceMappingURL=WorkspaceTree.d.ts.map