/**
 * The workspace, as the details column shows it: a file beside the tree it
 * came from.
 *
 * The tree stays visible while a file is open. Picking the next file is the
 * commonest thing someone does after reading one, and a viewer that replaced
 * the tree would make that a navigation instead of a click.
 *
 * READ ONLY. The Host operation behind this returns text and has no write
 * counterpart; nothing here can save.
 */
import type { WorkspaceFile, WorkspaceListing } from '@unieai/uad-client-runtime/client';
import type { DetailsSlotProps } from '../contract/slots.ts';
/** Props of the file browser. */
export interface FileBrowserProps {
    /** Absolute workspace root; nothing outside it is reachable. */
    root: string;
    /** The file shown beside the tree, or undefined for the empty placeholder. */
    path?: string;
    list: (root: string, path?: string, signal?: AbortSignal) => Promise<WorkspaceListing>;
    read: (root: string, path: string, signal?: AbortSignal) => Promise<WorkspaceFile>;
    /** Open a file, which the container turns into its own tab. */
    onOpen: (path: string) => void;
    /**
     * Hand the path to the operating system's editor, or undefined when that
     * would open it on a machine this reader is not sitting at.
     */
    onOpenExternally?: ((path: string) => void) | undefined;
    t: DetailsSlotProps['t'];
}
export declare function FileBrowser({ root, path, list, read, onOpen, onOpenExternally, t }: FileBrowserProps): import("react").JSX.Element;
//# sourceMappingURL=FileBrowser.d.ts.map