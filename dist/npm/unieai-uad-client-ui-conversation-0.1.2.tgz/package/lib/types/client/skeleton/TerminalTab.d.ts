/**
 * The terminal panel: xterm.js over one Host-owned shell.
 *
 * The renderer is xterm.js because a terminal is not a text box — a shell and
 * the full-screen programs it runs address the cursor, repaint regions, swap
 * to an alternate screen and colour by escape sequence, and anything less than
 * a real emulator turns `vim`, `htop` and even a coloured prompt into rubbish
 * on screen.
 *
 * The shell lives on the Host, not here. This component mounts a view of one,
 * and unmounting it does not end it: closing the tab and reopening it repaints
 * from what the Host retained, which is the behaviour that makes it safe to
 * put a long-running command in here.
 *
 * xterm's own stylesheet is NOT imported here. It is a global sheet whose
 * class names xterm writes into the DOM itself, so CSS modules would rename it
 * out from under the renderer; and this package is built by tsdown, which does
 * not resolve a bare package specifier for CSS. The app shell loads it — see
 * `apps/web/src/main.ts`, which vite builds and which is where third-party
 * global CSS belongs.
 */
import type { DetailsSlotProps } from '../contract/slots.ts';
/** Terminal capabilities the panel is handed. */
export type PanelTerminals = DetailsSlotProps['terminals'];
/** What this component needs. */
export interface TerminalTabProps {
    /**
     * Report which terminal this tab drives, so closing the tab can end it.
     * @param terminalId - the terminal now attached, or undefined once detached.
     */
    onAttached: (terminalId: string | undefined) => void;
    /**
     * Report the terminal's own name, so the tab strip can carry `user@host`
     * instead of the word "Terminal" — the icon already says which kind of tab
     * this is, and only the name says which machine the shell is on.
     */
    onNamed: (title: string) => void;
    /** The workspace whose directory the shell starts in. */
    workspaceId: string;
    /** Absolute path of that workspace. */
    cwd: string;
    /** The terminal seam, injected so this stays a presenter. */
    terminals: PanelTerminals;
    /** Feature copy. */
    t: DetailsSlotProps['t'];
}
/**
 * Show one terminal, opening it on first mount.
 * @param props - workspace, seam, and copy.
 * @returns the terminal surface.
 */
export declare function TerminalTab({ workspaceId, cwd, terminals, onNamed, onAttached, t }: TerminalTabProps): import("react").JSX.Element;
//# sourceMappingURL=TerminalTab.d.ts.map