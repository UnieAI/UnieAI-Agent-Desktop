/**
 * What the details column can open.
 *
 * One list, two placements: the empty column shows it in place, and the tab
 * strip's `+` shows it as a dropdown. Sharing the component is what keeps the
 * two from drifting into different menus for the same act.
 */
import type { DetailsSlotProps } from '../contract/slots.ts';
/** Locale key of a menu row's name. */
type PanelLabel = Parameters<DetailsSlotProps['t']>[0];
/** What one menu row opens. */
export type PanelItemId = 'produced' | 'files' | 'terminal';
/** One row: what it opens, and how it is labelled. */
interface PanelItem {
    id: PanelItemId;
    /** Locale key for the row's name. */
    label: PanelLabel;
}
/**
 * The rows, in the order the column offers them.
 *
 * The browser belongs here too and is absent until it exists: a row that opens
 * nothing teaches someone the menu is unreliable.
 *
 * The terminal row is NOT withheld off loopback. `terminal.*` is pinned on the
 * Host, which is the fence; hiding the row here as well only meant that a
 * person reaching this app through a tunnel, a port forward, or `localhost`
 * rather than `127.0.0.1` found the feature silently missing with nothing to
 * read. A row that opens and then says why it could not is a surface someone
 * can act on; a row that is not there is not.
 */
export declare const PANEL_ITEMS: readonly PanelItem[];
/**
 * The glyph for one row.
 *
 * Exported because the tab strip's dropdown is the shared `Menu` primitive,
 * which takes an icon node per row: one glyph source keeps the two readings of
 * this menu from drifting into different pictures for the same act.
 * @param id - the row.
 * @returns its icon.
 */
export declare function PanelItemIcon({ id }: {
    id: PanelItemId;
}): import("react").JSX.Element;
/** Props of the open-what menu. */
export interface PanelMenuProps {
    /** Open one item; the caller owns whether the menu then closes. */
    onOpen: (id: PanelItemId) => void;
    /**
     * `menu` floats over the strip; `panel` fills the empty column.
     *
     * The floating placement is now the shared `Menu` primitive's job — the
     * details column clips its overflow, and a card positioned inside it is cut
     * off at the column edge. This component keeps the in-place list.
     */
    placement: 'menu' | 'panel';
    t: DetailsSlotProps['t'];
}
export declare function PanelMenu({ onOpen, placement, t }: PanelMenuProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=PanelMenu.d.ts.map