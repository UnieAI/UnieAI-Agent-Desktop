/**
 * The header control that opens the details column.
 *
 * The column used to open only as a side effect of selecting a tool row, so
 * everything it can answer on its own — what this session produced, what is in
 * the workspace — was unreachable until someone clicked something else first.
 * This is the way in, and the way back out: one control both ways, because a
 * button that only opens leaves its own pressed state contradicting the panel.
 */
import type { DetailsToggleInjected } from '../contract/slots.ts';
import type { PropsLocale } from '@unieai/uad-client-ui-slots';
/** Props of the details-column opener. */
export type DetailsToggleProps = DetailsToggleInjected & PropsLocale<'conversation'>;
export declare function DetailsToggle({ toggleDetails, t }: DetailsToggleProps): import("react").JSX.Element;
//# sourceMappingURL=DetailsToggle.d.ts.map