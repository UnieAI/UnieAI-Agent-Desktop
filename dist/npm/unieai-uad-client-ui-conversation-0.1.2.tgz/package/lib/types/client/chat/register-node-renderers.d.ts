import type { Context } from '@unieai/cordis';
/**
 * Register this package's business renderers behind the keyed Chat Node seat.
 * @param ctx - owning UI Conversation context.
 */
export declare function registerChatNodeRenderers(ctx: Context): void;
//# sourceMappingURL=register-node-renderers.d.ts.map