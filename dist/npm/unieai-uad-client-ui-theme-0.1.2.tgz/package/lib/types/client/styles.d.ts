import type { Context } from '@unieai/cordis';
/**
 * Mount the global theme sheets for exactly the owning plugin lifetime.
 * @param ctx - Owning plugin context.
 */
export declare function installThemeStyles(ctx: Context): void;
//# sourceMappingURL=styles.d.ts.map