/** Platform-neutral assembly of generated Host Remote contributions. */
import type { Context } from '@unieai/cordis';
import type { TypertClientRemote } from '@unieai/uad-typert-protocol';
export type { TypertClientRemote as ClientRemote } from '@unieai/uad-typert-protocol';
export type { PluginInventorySnapshot } from '@unieai/uad-host-plugin-inventory/types';
export type {} from '@unieai/uad-commands/remote';
export type {} from '@unieai/uad-file-reference/remote';
export type {} from '@unieai/uad-goal/remote';
export type {} from '@unieai/uad-host-plugin-inventory/remote';
export type {} from '@unieai/uad-message-feedback/remote';
export type {} from '@unieai/uad-session-reference/remote';
export type { ApiRemoteForwardedEvent } from '../types.ts';
export type {} from '@unieai/uad-commands/types';
export type {} from '@unieai/uad-cordis-host-runner/types';
export type {} from '@unieai/uad-credentials/types';
export type {} from '@unieai/uad-llm/types';
export type {} from '@unieai/uad-agent-presets/types';
export type {} from '@unieai/uad-settings/types';
/**
 * The carrier's Client-facing types, re-exported so a business package names one
 * assembly package instead of both this facade and the Connection plugin. Type-only:
 * the carrier's runtime values stay behind their own module edge.
 */
export type { ClientResponse, ConfigurableProviderView, ConnectionHandle, ConnectionSinks, ContentBlock, CredentialView, DirectoryListing, DiscoveredModelView, HistoryEntry, HostFrame, IApiClient, TerminalOpened, TerminalSignalName, TerminalView, MessageId, ModelCatalogFailure, ModelProviderGroup, ModelReasoningEffort, ModelSelection, MuxFrame, PromptContentPart, QuestionResponsePayload, QueueAction, RpcError, RpcId, RpcReceipt, RpcRequest, RpcResponse, RpcResult, SessionId, SessionModels, SessionSearchItem, SessionSummary, SettingsNamespaceView, SettingsPathOpView, SkillEntry, StreamChunk, SubagentAddress, SubagentCatalog, JobView, ToolCallView, ToolEventView, ToolResultView, WorkspaceEntry, WorkspaceFile, WorkspaceId, WorkspaceListing, WorkspaceView, } from '@unieai/uad-client-connection/client';
export type {} from '@unieai/uad-api-gateway/client';
export type {} from '@unieai/uad-cordis-host-runner/remote';
export type { ApprovalRequestId, CordisHalfState, CordisDynamicPackageId, CordisDynamicPluginId, CordisDynamicPluginRunId, CordisDynamicRunMode, CordisInspectMethodManifest, CordisInspectPlatform, CordisInspectProviderManifest, CordisInspectProviderView, CordisInspectQueryRequest, CordisInspectQueryResolution, CordisInspectQueryResolved, CordisInspectRequestId, CordisInspectResolveAck, CordisRunDiagnostic, CordisRunStatus, DynamicCordisClientSource, DynamicCordisHostHalfResult, DynamicCordisInventoryRow, DynamicCordisInvokeResult, DynamicCordisPackage, DynamicCordisRequestResolved, DynamicCordisResolveAck, DynamicCordisRetracted, DynamicCordisRunRequest, DynamicCordisRunResolution, DynamicCordisRunAttempt, DynamicCordisRunResponse, DynamicCordisStopResponse, DynamicCordisUndefineReceipt, RequestRunOutcome, } from '@unieai/uad-cordis-host-runner/types';
export type { JsonValue } from '@unieai/uad-session/types';
export type { FileReferenceCandidate } from '@unieai/uad-file-reference/types';
export type { SessionReferenceMentionCandidate } from '@unieai/uad-session-reference/types';
declare module '@unieai/cordis' {
    interface Context {
        /** Generated Remote namespaces selected by this Client assembly. */
        remote: TypertClientRemote;
    }
}
/** Required service: the typed Client Remote contribution mount. */
export declare const inject: string[];
/**
 * Mount the Host capabilities explicitly selected for this Client assembly.
 * @param ctx - Client Cordis root carrying the typed API service.
 * @returns disposer after every selected Remote namespace is ready.
 */
export declare function apply(ctx: Context): Promise<() => Promise<void>>;
//# sourceMappingURL=index.d.ts.map