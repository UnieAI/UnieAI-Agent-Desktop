/**
 * Typed failures shared by subagent service and provider operations.
 *
 * @module @unieai/uad-subagent
 */
import { HarnessError } from '@unieai/uad-llm';
/** Typed failure for the subagent seam. */
export declare class SubagentError extends HarnessError {
    constructor(message: string, code: string, options?: ErrorOptions);
}
//# sourceMappingURL=error.d.ts.map