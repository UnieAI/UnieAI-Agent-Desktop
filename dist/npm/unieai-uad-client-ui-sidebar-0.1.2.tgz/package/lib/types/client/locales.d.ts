/**
 * `sidebar` namespace dictionaries: the column's own controls (brand row, the
 * New chat nav row, fold toggle). The nav wording tracks the UnieAI web
 * product's own sidebar (`AgentNext.newChat`) so the desktop column reads as
 * the same product.
 */
/** Simplified Chinese dictionary (the key-set source of truth). */
export declare const zh: {
    'session.new': string;
    'session.new.label': string;
    search: string;
    'toggle.open': string;
    'toggle.collapse': string;
};
/** The sidebar namespace key union. */
export type SidebarKey = keyof typeof zh;
/** Traditional Chinese dictionary. */
export declare const zhTW: {
    'session.new': string;
    'session.new.label': string;
    search: string;
    'toggle.open': string;
    'toggle.collapse': string;
};
/** Japanese dictionary. */
export declare const ja: {
    'session.new': string;
    'session.new.label': string;
    search: string;
    'toggle.open': string;
    'toggle.collapse': string;
};
/** English dictionary, checked complete against the zh key set. */
export declare const en: {
    'session.new': string;
    'session.new.label': string;
    search: string;
    'toggle.open': string;
    'toggle.collapse': string;
};
//# sourceMappingURL=locales.d.ts.map