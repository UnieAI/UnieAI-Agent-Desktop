/** Registers the sidebar shell into the layout-owned slot. */
import type { ClientContext } from '@unieai/uad-client-runtime/client';
import { type SidebarKey } from './locales.ts';
export type { SidebarAccountOwnerProps, SidebarBrandMarkOwnerProps, SidebarBrandNameOwnerProps, SidebarFooterActionOwnerProps, SidebarNavActionOwnerProps, SidebarRootComponentProps, SidebarRootInjected, SidebarSectionOwnerProps, SidebarSettingsOwnerProps, } from './contract/slots.ts';
export type { SidebarKey } from './locales.ts';
declare module '@unieai/cordis' {
    interface Events {
        /**
         * The sidebar sent the reader back to the conversation.
         *
         * Emitted on the ACT, not on the state it produces: starting a session
         * while a blank one is already current changes nothing observable, so a
         * surface covering the conversation cannot learn about it from the session
         * store. Anything rendered over the shell listens here to get out of the
         * way.
         */
        'sidebar/navigate': () => void;
    }
}
declare module '@unieai/uad-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** Sidebar shell controls copy. */
        sidebar: SidebarKey;
    }
}
/** Services required by the sidebar plugin. */
export declare const inject: string[];
/** Registers the sidebar shell and its service callbacks.
 * @param ctx - Client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map