import type { PropsLocale, PropsRuntime } from '@unieai/uad-client-ui-slots';
type GoalCommandInputViewProps = PropsRuntime<'conversation.chat.node', 'command-input'> & PropsLocale<'goal'>;
/** Right-aligned `/goal` input bubble without ordinary message actions. */
export declare const GoalCommandInputView: import("react").MemoExoticComponent<({ node, t, }: GoalCommandInputViewProps) => import("react").JSX.Element>;
export {};
//# sourceMappingURL=GoalCommandInputView.d.ts.map