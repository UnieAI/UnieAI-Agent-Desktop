/**
 * Shared browser platform modules. Seeding, bundling externals, and Vite
 * aliases consume this list so their module identities cannot drift.
 * @module @unieai/uad-client-web/src/platform
 */
/** The module specifiers the shell shares into the frozen module table. */
export declare const PLATFORM_MODULES: readonly ["react", "react/jsx-runtime", "react-dom", "react-dom/client", "@unieai/cordis", "@unieai/uad-client-ui-slots", "@unieai/uad-client-ui-primitives"];
/** Client-bundle specifiers whose factories the parser preloads before the shell starts. */
export declare const PRELOADED_CLIENT_EXTERNALS: readonly ["@unieai/uad-client-runtime/client"];
/** One platform module specifier (a seed-table key). */
export type PlatformModule = (typeof PLATFORM_MODULES)[number];
//# sourceMappingURL=platform.d.ts.map