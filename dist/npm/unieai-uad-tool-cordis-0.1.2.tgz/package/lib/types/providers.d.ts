/** First-party Host inspect providers registered by the Cordis tool package. */
import type { Context } from '@unieai/cordis';
import type { HostCordisInspectProviderRegistration } from '@unieai/uad-cordis-host-runner';
/**
 * Construct Host providers over generated Catalogs, evaluator declarations, and live Tool scope.
 * @param ctx - Host context used for Agent-scoped live Tool queries.
 * @returns registrations for static catalogs and live Host capabilities.
 */
export declare function hostInspectProviders(ctx: Context): HostCordisInspectProviderRegistration[];
//# sourceMappingURL=providers.d.ts.map