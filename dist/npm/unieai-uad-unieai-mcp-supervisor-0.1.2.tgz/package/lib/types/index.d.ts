/**
 * @unieai/uad-unieai-mcp-supervisor — mounts the MCP servers the
 * signed-in UnieAI account grants, and keeps them mounted.
 *
 * The web product hosts MCP servers on its users' behalf and hands a desktop a
 * per-user bearer for each one (`/api/desktop/mcp`). `mcp-client` can dial
 * exactly such a server, but it is configured from `cordis.yml` and a
 * composition file cannot know which servers an account has connected — or
 * hold a credential that is minted per sign-in. This plugin is the piece
 * between them: it reads the grants through the sign-in gate and mounts one
 * `mcp-client` instance per server at runtime.
 *
 * ```yaml
 * - id: unieai-mcp-supervisor
 *   name: '@unieai/uad-unieai-mcp-supervisor'
 * ```
 *
 * **The grants expire, and that is the hard part.** Each bearer is good for
 * about an hour, and a mounted server whose bearer lapsed fails every call
 * with nothing else to say why — no disconnect, no reconnect, just refusals.
 * So the supervisor does not wait to be told: it re-reads the list ahead of
 * the earliest expiry it holds and re-mounts anything whose grant changed. A
 * re-mint always changes the bearer, and `mcp-client` captures its headers at
 * construction, so a refresh cycle is a disconnect and a reconnect by
 * construction. The alternative — leaving a connection up with a dead bearer —
 * is a server that is silently broken rather than briefly absent.
 *
 * Signing out drops every instance, because the grants were the account's.
 *
 * @module @unieai/uad-unieai-mcp-supervisor
 */
import { Context } from '@unieai/cordis';
import z from '@unieai/schemastery';
export { matchesGrant, nextRefreshDelay } from './registry.ts';
export type { MountedServer } from './registry.ts';
/** Plugin name for the Loader. */
export declare const name = "unieai-mcp-supervisor";
/** Required service: the sign-in gate that holds the account and its grants. */
export declare const inject: string[];
/** Deployment configuration. */
export interface Config {
    /**
     * How long before a grant expires the list is re-read. The margin has to
     * cover the read, the disconnect, and the reconnect — everything that
     * happens between noticing an expiry and having a working connection again.
     */
    refreshSkewMs: number;
    /**
     * Floor on the wait between two reads. It also covers the cases with no
     * usable deadline at all: a grant whose expiry this build cannot parse, and
     * one that is already past.
     */
    minRefreshMs: number;
    /**
     * Ceiling on the wait. It is what paces the read when nothing is mounted,
     * which is how a server the account connects while signed in is noticed
     * without a signal from the product.
     */
    maxRefreshMs: number;
    /**
     * Wait before trying again after a read failed. Separate from
     * {@link minRefreshMs} because a failed read says nothing about when the
     * grants lapse: whatever is mounted keeps working until it does, and
     * hammering a product that is down does not bring the next list any sooner.
     */
    retryDelayMs: number;
    /** Per-tool-call timeout handed to every mounted instance. */
    toolCallTimeoutMs: number;
}
/** Schema for {@link Config}. */
export declare const Config: z<Config>;
/**
 * Mount and supervise the account's MCP servers.
 * @param ctx - Cordis context carrying `unieaiGate`.
 * @param config - resolved plugin config.
 */
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map