/** Copy dictionaries for the Models settings section. */
/** English strings (the key-set source of truth for this pair). */
export declare const en: {
    nav: string;
    title: string;
    intro: string;
    edit: string;
    editProvider: string;
    remove: string;
    removeProvider: string;
    deleteTitle: string;
    deleteDescription: string;
    deleteDescriptionWithCredential: string;
    deleteConfirm: string;
    deleting: string;
    add: string;
    provider: string;
    close: string;
    cancel: string;
    apply: string;
    applying: string;
    savedProvider: string;
    credentialConfigured: string;
    credentialMissing: string;
    readOnly: string;
    loadFailed: string;
    conflict: string;
    retry: string;
    keyInput: string;
    keyPlaceholder: string;
    keyPlaceholderNative: string;
    keyStored: string;
    keyEnvLocked: string;
    customized: string;
    baseUrl: string;
    baseUrlDefault: string;
    models: string;
    modelsInherited: string;
    modelsCustomized: string;
    resetModels: string;
    model: string;
    modelId: string;
    modelName: string;
    modelNamePlaceholder: string;
    contextWindow: string;
    contextWindowPlaceholder: string;
    maxTokens: string;
    maxTokensPlaceholder: string;
    modelAdvanced: string;
    addModel: string;
    removeModel: string;
    modelsEmpty: string;
    keyBlank: string;
    keyBlankNew: string;
    keyIllegalCharacters: string;
    modelIdRequired: string;
    modelIdDuplicate: string;
    modelNameInvalid: string;
    modelContextInvalid: string;
    modelMaxTokensInvalid: string;
    advancedHint: string;
    modelCapacityInvalid: string;
    modelDuplicate: string;
    modelContextWindow: string;
    modelMaxTokens: string;
    fetchModels: string;
    fetching: string;
    fetchNeedsBaseUrl: string;
    fetchEmpty: string;
    fetchTitle: string;
    fetchDescription: string;
    fetchSelectAll: string;
    fetchDeselectAll: string;
    fetchAdopt: string;
    customAdd: string;
    customTitle: string;
    customTag: string;
    customRoute: string;
    customRouteHint: string;
    customRouteInvalid: string;
    customRouteTaken: string;
    customDisplayName: string;
    customApi: string;
    customApiUnset: string;
    customNeedsBaseUrl: string;
    customNeedsModels: string;
    create: string;
    creating: string;
    welcomeTitle: "Developer Preview";
    welcomeBody: "Rabi is in developer preview. Features and interfaces are still moving quickly, and compatibility-breaking changes are expected along the way.\n\nIt is built on open, composable plugin infrastructure: the model adapter, the tool registry, the session log, and the agent loop itself are all replaceable plugins. We welcome your feedback as we refine it.";
    welcomeContinue: "Continue";
    welcomeError: string;
    keyRequired: string;
};
/** The settings.models namespace key union. */
export type ModelsKey = keyof typeof en;
/** Chinese strings (same keys as {@link en}). */
export declare const zh: {
    [Key in keyof typeof en]: string;
};
/** Traditional Chinese copy. */
export declare const zhTW: {
    [Key in keyof typeof en]: string;
};
/** Japanese copy. */
export declare const ja: {
    [Key in keyof typeof en]: string;
};
//# sourceMappingURL=locales.d.ts.map