/**
 * @unieai/uad-mcp-servers — mounts the MCP servers a person added themselves.
 *
 * WHY THIS EXISTS. `mcp-client` can already connect to any MCP server, and the
 * profile's patch layer can already declare one. What was missing is the act
 * being available to a person who is not editing YAML: connecting a server
 * meant opening `cordis.patch.yml`, knowing the plugin's config shape, and
 * restarting. This keeps the same list in the settings document instead, and
 * mounts it live.
 *
 * IT IS NOT THE ACCOUNT'S LIST. `unieai-mcp-supervisor` mounts what the UnieAI
 * product says this account has connected, with a bearer the product mints and
 * the browser never sees. This one mounts what the person typed on this
 * machine, with a token they typed. The two are deliberately separate services
 * over the same `mcp-client`: one is account state that arrives and expires,
 * the other is local configuration that changes only when someone changes it,
 * and merging them would make an account outage look like a lost setting.
 *
 * RECONCILE, DO NOT RESTART. A settings write remounts only the servers whose
 * name, URL or token moved. Rebuilding the whole set on every keystroke of an
 * unrelated row would drop live connections — and every tool they publish —
 * for the duration.
 */
import { Context } from '@unieai/cordis';
import z from '@unieai/schemastery';
export { MCP_SERVERS_FIELD, MCP_SERVERS_NAMESPACE, McpServersSettings, SERVER_NAME_PATTERN, differs, mountable, problemsWith, type EntryProblem, type McpServerEntry, type McpServersSettingsValue, } from './settings.ts';
/** Cordis plugin name used by loader diagnostics. */
export declare const name = "mcp-servers";
/** Deployment configuration. */
export interface Config {
    /**
     * Per-tool-call timeout handed to every mounted server.
     *
     * One value for the whole list rather than one per row: a person adding a
     * server is answering "where is it", and a timeout is a deployment's
     * judgement about its own machine, not part of the address.
     */
    toolCallTimeoutMs: number;
}
/** Config schema; the Loader resolves the default. */
export declare const Config: z<Config>;
/**
 * Register the durable list and keep the mounted set equal to it.
 * @param ctx - host context that may acquire the settings service.
 * @param config - see {@link Config}.
 */
export declare function apply(ctx: Context, config?: Config): void;
//# sourceMappingURL=index.d.ts.map