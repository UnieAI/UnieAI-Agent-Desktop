#!/usr/bin/env node
/**
 * Standalone process wrapper for the scriptable mock LLM server.
 * @module @unieai/uad-llm-mock-server/src/bin
 */
export {};
//# sourceMappingURL=bin.d.ts.map