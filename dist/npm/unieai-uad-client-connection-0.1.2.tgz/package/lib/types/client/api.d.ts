export type { ApiProxy, SessionsApi, SessionSearchItem, SessionSummary, PromptContentPart, HostApi, EventsApi, MuxFrame, HostFrame, ApprovalResponsePayload, QuestionResponsePayload, HistoryEntry, ToolEventView, DirectoryEntry, DirectoryListing, WorkspaceEntry, WorkspaceFile, WorkspaceListing, ResponseValue, WorkspaceApi, WorkspaceId, WorkspaceView, TerminalApi, TerminalOpened, TerminalSignalName, TerminalView, SkillsApi, SkillEntry, ModelCatalogFailure, ModelCatalogModel, ModelProviderGroup, ModelReasoning, ModelReasoningEffort, ModelSelection, QueueAction, QueuedInboxItem, SessionModels, GoalsApi, GoalRef, SettingsApi, SettingsNamespaceView, SettingsPathOpView, SettingsSecretView, CredentialsApi, CredentialView, ConfigurableProviderView, DiscoveredModelView, LlmApi, SubagentsApi, SubagentAddress, SubagentCatalog, SubagentListEntry, SubagentPromptReceipt, JobView, } from '@unieai/uad-host-apiproxy/api';
export type { ToolCallView, ToolResultView } from '@unieai/uad-tools/presentation';
export type { RpcRequest, RpcResponse, RpcResult, RpcError, RpcErrorCode, ClientRequest, ServerResponse, ServerRequest, ClientResponse, RpcMessage, RpcReceipt, } from '@unieai/uad-host-apiproxy/api';
export { RpcId, SESSION_SEARCH_RESULT_LIMIT, transportError, } from '@unieai/uad-host-apiproxy/api';
export { AbstractApiClient } from '@unieai/uad-host-apiproxy/client';
export type { IApiClient } from '@unieai/uad-host-apiproxy/client';
export type { SessionId, SessionEvent } from '@unieai/uad-session/types';
export type { MessageId } from '@unieai/uad-llm/brand';
export type { ContentBlock, StreamChunk } from '@unieai/uad-llm/types';
/** Successful value returned by the connection-generation host handshake. */
export type HostDescription = import('@unieai/uad-host-apiproxy/api').ResponseValue<'host.describe'>;
import type { RpcResponse, RpcResult } from '@unieai/uad-host-apiproxy/api';
/**
 * Unwrap a unary response: RpcResponse<T> -> RpcResult<T> (business code only
 * cares about the result slot).
 * @param response - the unary response.
 * @returns its result slot.
 */
export declare function resultOf<T>(response: RpcResponse<T>): RpcResult<T>;
//# sourceMappingURL=api.d.ts.map