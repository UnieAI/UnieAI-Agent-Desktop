/** Host-side WebSocket carrier for the two server-to-browser event streams. */
import type { IncomingMessage } from 'node:http';
import type { Duplex } from 'node:stream';
import type { ApiProxy } from '@unieai/uad-host-apiproxy/api';
/**
 * Owns WebSocket negotiation and frame pumping for the connection plugin's
 * two downlinks. Client messages are a protocol violation: upstream traffic
 * remains on HTTP.
 */
export declare class WebSocketDownlinks {
    private readonly api;
    private readonly server;
    private readonly pumps;
    /** @param api - host API supplying the typed event streams. */
    constructor(api: ApiProxy);
    /**
     * Upgrade one socket and pump the mux stream until either side closes.
     * @param req - HTTP upgrade request.
     * @param socket - Raw socket transferred by the HTTP server.
     * @param head - Bytes already read after the upgrade headers.
     */
    handleMux(req: IncomingMessage, socket: Duplex, head: Buffer): void;
    /**
     * Upgrade one socket and pump the host stream until either side closes.
     * @param req - HTTP upgrade request.
     * @param socket - Raw socket transferred by the HTTP server.
     * @param head - Bytes already read after the upgrade headers.
     */
    /**
     * Open the host event stream for one browser.
     *
     * @param req - the upgrade request.
     * @param socket - the upgraded socket.
     * @param head - the upgrade head bytes.
     * @param options - `terminals` carries whether this peer may see
     *   operator-terminal frames. `terminal.*` is loopback-pinned because it
     *   runs commands as the host account; a trusted remote browser that cannot
     *   OPEN a terminal must not READ one either, and this stream is the only
     *   other place a terminal's bytes leave the Host. The carrier decides it
     *   because the carrier is the layer that knows who the peer is — a payload
     *   field would be the client asserting its own privilege.
     */
    handleHost(req: IncomingMessage, socket: Duplex, head: Buffer, options: {
        terminals: boolean;
    }): void;
    /**
     * Terminate owned sockets and await the no-server acceptor plus frame pumps.
     * @returns A promise resolving after every socket and source iterator stops.
     */
    close(): Promise<void>;
    private upgrade;
    private pump;
}
/**
 * Reject an untrusted upgrade before protocol negotiation.
 * @param socket - Raw HTTP socket that remains owned by the caller.
 */
export declare function rejectWebSocketUpgrade(socket: Duplex): void;
//# sourceMappingURL=websocket-downlink.d.ts.map