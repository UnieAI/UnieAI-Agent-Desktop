/**
 * terminal domain zod schemas (names derived from map keys).
 */
import { z } from 'zod';
/** terminal.list request payload (empty object literal). */
export declare const terminalListRequestSchema: z.ZodObject<{}, z.core.$strip>;
/** terminal.list response value. */
export declare const terminalListValueSchema: z.ZodObject<{
    terminals: z.ZodArray<z.ZodObject<{
        terminalId: z.ZodString;
        workspaceId: z.ZodString;
        cwd: z.ZodString;
        shell: z.ZodString;
        title: z.ZodString;
        cols: z.ZodNumber;
        rows: z.ZodNumber;
        live: z.ZodBoolean;
        exitCode: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strip>>;
}, z.core.$strip>;
/** terminal.open request payload. */
export declare const terminalOpenRequestSchema: z.ZodObject<{
    workspaceId: z.ZodString;
    cwd: z.ZodString;
    cols: z.ZodNumber;
    rows: z.ZodNumber;
}, z.core.$strip>;
/** terminal.open response value. */
export declare const terminalOpenValueSchema: z.ZodObject<{
    terminal: z.ZodObject<{
        terminalId: z.ZodString;
        workspaceId: z.ZodString;
        cwd: z.ZodString;
        shell: z.ZodString;
        title: z.ZodString;
        cols: z.ZodNumber;
        rows: z.ZodNumber;
        live: z.ZodBoolean;
        exitCode: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strip>;
    replay: z.ZodString;
}, z.core.$strip>;
/** terminal.replay request payload. */
export declare const terminalReplayRequestSchema: z.ZodObject<{
    terminalId: z.ZodString;
}, z.core.$strip>;
/** terminal.replay response value. */
export declare const terminalReplayValueSchema: z.ZodObject<{
    terminal: z.ZodObject<{
        terminalId: z.ZodString;
        workspaceId: z.ZodString;
        cwd: z.ZodString;
        shell: z.ZodString;
        title: z.ZodString;
        cols: z.ZodNumber;
        rows: z.ZodNumber;
        live: z.ZodBoolean;
        exitCode: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strip>;
    replay: z.ZodString;
}, z.core.$strip>;
/** terminal.write request payload. */
export declare const terminalWriteRequestSchema: z.ZodObject<{
    terminalId: z.ZodString;
    data: z.ZodString;
}, z.core.$strip>;
/** terminal.write response value (empty object literal). */
export declare const terminalWriteValueSchema: z.ZodObject<{}, z.core.$strip>;
/** terminal.resize request payload. */
export declare const terminalResizeRequestSchema: z.ZodObject<{
    terminalId: z.ZodString;
    cols: z.ZodNumber;
    rows: z.ZodNumber;
}, z.core.$strip>;
/** terminal.resize response value (empty object literal). */
export declare const terminalResizeValueSchema: z.ZodObject<{}, z.core.$strip>;
/** terminal.signal request payload. */
export declare const terminalSignalRequestSchema: z.ZodObject<{
    terminalId: z.ZodString;
    signal: z.ZodUnion<readonly [z.ZodLiteral<"SIGINT">, z.ZodLiteral<"SIGTERM">, z.ZodLiteral<"SIGQUIT">, z.ZodLiteral<"SIGTSTP">]>;
}, z.core.$strip>;
/** terminal.signal response value (empty object literal). */
export declare const terminalSignalValueSchema: z.ZodObject<{}, z.core.$strip>;
/** terminal.close request payload. */
export declare const terminalCloseRequestSchema: z.ZodObject<{
    terminalId: z.ZodString;
}, z.core.$strip>;
/** terminal.close response value (empty object literal). */
export declare const terminalCloseValueSchema: z.ZodObject<{}, z.core.$strip>;
//# sourceMappingURL=terminal.schema.d.ts.map