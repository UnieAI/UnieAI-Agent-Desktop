/** Package-owned permission-preset event invariants. @module @unieai/uad-permission-presets/invariant */
import type { Context } from '@unieai/cordis';
/** Cordis companion plugin name. */
export declare const name = "permission-presets-invariant";
/** Service required before the companion can reserve package ownership. */
export declare const inject: string[];
/**
 * Register the permission invariant companion.
 * @param ctx - Cordis context carrying the invariant service.
 * @returns the installed registration's disposer after setup succeeds.
 */
export declare const apply: (ctx: Context) => Promise<() => void>;
//# sourceMappingURL=invariant.d.ts.map