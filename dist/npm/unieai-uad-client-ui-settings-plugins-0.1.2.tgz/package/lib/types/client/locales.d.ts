/**
 * Locale bundles for the cordis plugin area and its plugin cards.
 *
 * `title` names the deployment, not the product. This area sits on the
 * Plugins page under that page's own "Plugins" heading, and two headings
 * reading "Plugins" one above the other would say that the page is this
 * registry — which is the confusion the page was built to end.
 *
 * Vendor names in card copy name the SUPPLIER of a capability, never this
 * product. The web-search card is served by DeepSeek's search API and says
 * so; it is not "the DeepSeek search" of a rebranded desktop.
 */
/** Locale keys these surfaces render. */
export type PluginsSettingsLocaleKey = 'title' | 'intro' | 'tabs' | 'configurableTab' | 'empty' | 'overridden' | 'reset' | 'readOnly' | 'expand' | 'collapse' | 'save' | 'saving' | 'discard' | 'unsaved' | 'saveFailed' | 'invalidNumber' | 'bashTitle' | 'bashDescription' | 'bashTimeoutMs' | 'bashTimeoutMsHint' | 'bashMaxOutputBytes' | 'bashMaxOutputBytesHint' | 'agentLoopTitle' | 'agentLoopDescription' | 'agentLoopMaxParallel' | 'agentLoopMaxParallelHint' | 'webSearchTitle' | 'webSearchDescription' | 'webSearchApiKey' | 'webSearchApiKeyHint' | 'webSearchApiKeySet' | 'webSearchApiKeyUnset' | 'webSearchBaseUrl' | 'webSearchBaseUrlHint' | 'webSearchMaxUses' | 'webSearchMaxUsesHint';
/** English copy. */
export declare const en: Record<PluginsSettingsLocaleKey, string>;
/** Simplified Chinese copy. */
export declare const zh: Record<PluginsSettingsLocaleKey, string>;
/** Traditional Chinese copy. */
export declare const zhTW: Record<PluginsSettingsLocaleKey, string>;
/** Japanese copy. */
export declare const ja: Record<PluginsSettingsLocaleKey, string>;
//# sourceMappingURL=locales.d.ts.map