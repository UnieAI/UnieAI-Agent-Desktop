/**
 * The `unieaiBootstrap` supplier: one read of the host gate's
 * `/auth/bootstrap` route, published as the startup snapshot.
 *
 * It owns no credential and holds no session. The gate's cookie is `HttpOnly`,
 * so this object cannot see whether one exists; the host answers that question
 * and this object publishes the answer. Everything it reads is same-origin,
 * and the API key the host spends on the product never crosses back.
 *
 * Two numbers decide what a bad network does to the desktop:
 *
 * - {@link DEFAULT_READ_TIMEOUT_MS} bounds the read. The application's first
 *   frame waits on it, so it must end — with an answer or without one. Without
 *   one the snapshot is `unavailable`, which is every surface's instruction to
 *   read its own route exactly as it did before this package existed. The
 *   desktop opens either way, because the local agent does not need the cloud.
 * - {@link DEFAULT_FOLLOW_UP_DELAY_MS} is how long a `partial` answer waits
 *   before being asked again, once. The host names the parts it is still
 *   gathering and keeps gathering them, so one later read usually completes
 *   the picture without anybody touching anything. Once, not repeatedly: this
 *   is a warm start, not a poll.
 */
import type { UnieAiBootstrap, UnieAiBootstrapSnapshot } from '../bootstrap-contract.ts';
/**
 * How long one read may take before the desktop stops waiting for it.
 *
 * Above the host's own gathering deadline, because this bound covers the host
 * answering as well as the request reaching it; below what anyone would spend
 * looking at a boot screen.
 */
export declare const DEFAULT_READ_TIMEOUT_MS = 3000;
/** How long a `partial` answer waits before its single follow-up read. */
export declare const DEFAULT_FOLLOW_UP_DELAY_MS = 1500;
/** The browser facilities the reader uses, named so a test can drive them. */
export interface BootstrapEnvironment {
    /**
     * Issue one same-origin request to the host gate.
     * @param path - an absolute path on this origin.
     * @param init - request options.
     * @returns the response.
     */
    request: (path: string, init?: RequestInit) => Promise<Response>;
    /** Bound on one read; defaults to {@link DEFAULT_READ_TIMEOUT_MS}. */
    readTimeoutMs?: number;
    /** Delay before the single follow-up; defaults to {@link DEFAULT_FOLLOW_UP_DELAY_MS}. */
    followUpDelayMs?: number;
}
/**
 * Narrow one `/auth/bootstrap` body.
 *
 * The parts are carried through untouched — this package reads none of them —
 * but the KEYS are not: only the four this build knows about are kept, so a
 * host one deploy ahead cannot put a part into the snapshot under a name no
 * consumer of this contract has heard of.
 * @param body - the parsed response body.
 * @returns the snapshot it describes, or undefined when it describes none.
 */
export declare function readBootstrapResponse(body: unknown): UnieAiBootstrapSnapshot | undefined;
/** Reads the startup answer from the host gate and publishes it. */
export declare class BootstrapReader implements UnieAiBootstrap {
    private readonly environment;
    private readonly listeners;
    private snapshot;
    private followUp;
    private inFlight;
    private disposed;
    /** @param environment - the browser facilities to use. */
    constructor(environment: BootstrapEnvironment);
    /**
     * Read the current snapshot.
     * @returns the standing snapshot; the same reference until a read settles.
     */
    getSnapshot(): UnieAiBootstrapSnapshot;
    /**
     * Subscribe to snapshot changes.
     * @param listener - called after every settled read.
     * @returns unsubscribe.
     */
    subscribe(listener: () => void): () => void;
    /**
     * Read the startup answer, scheduling one follow-up if it was partial.
     * @returns a promise settling when the reading has been published.
     */
    refresh(): Promise<void>;
    /** Stop reading and publishing; a read in flight is cancelled. */
    dispose(): void;
    /**
     * Perform one read and publish what it establishes.
     * @param mayFollowUp - whether a partial answer earns the single follow-up;
     * false for the follow-up itself, which is where the chain ends.
     */
    private read;
    /**
     * Issue one bounded request.
     * @returns what the attempt established; `unavailable` for a host that did
     * not answer, answered late, or answered a body this build cannot read.
     */
    private fetchOnce;
    /**
     * Stand on a new snapshot and notify.
     * @param snapshot - the reading to publish.
     */
    private publish;
}
//# sourceMappingURL=reader.d.ts.map