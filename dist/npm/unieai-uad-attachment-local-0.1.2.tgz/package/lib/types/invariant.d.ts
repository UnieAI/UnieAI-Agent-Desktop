/** Package-owned invariant companion for `@unieai/uad-attachment-local`. @module @unieai/uad-attachment-local/invariant */
import type { Context } from '@unieai/cordis';
/** Cordis companion plugin name. */
export declare const name = "attachment-local-invariant";
/** Services required before package ownership can be reserved. */
export declare const inject: string[];
/**
 * Register the package invariant companion.
 * @param ctx - Cordis context carrying the invariant service.
 * @returns the registration disposer.
 */
export declare const apply: (ctx: Context) => Promise<() => void>;
//# sourceMappingURL=invariant.d.ts.map