/** Validated configuration for the operator terminal. */
import z from '@unieai/schemastery';
/** Public plugin configuration. */
export interface Config {
    /**
     * Whether the GUI may open a terminal at all (default: `true`).
     *
     * This tab runs any command as the user who started the app, which is what a
     * terminal is for; the switch exists so a deployment that does not want that
     * surface can remove it rather than hide it.
     */
    enabled?: boolean;
    /** Interactive shell to run (default: `$SHELL`, then `/bin/bash`, then `/bin/sh`). */
    shellPath?: string;
    /** Maximum retained UTF-8 bytes of output per terminal, for repaint after reconnect. */
    scrollbackMaxBytes?: number;
    /** Maximum simultaneous live terminals per workspace. */
    maxTerminalsPerWorkspace?: number;
    /** Grace before teardown escalates to `SIGKILL`. */
    disposeGraceMs?: number;
}
/** Configuration after Schemastery defaults. */
export type ResolvedConfig = Required<Omit<Config, 'shellPath'>> & Pick<Config, 'shellPath'>;
/** Schemastery config exposed by the plugin. */
export declare const Config: z<Config>;
/**
 * Assert every effective numeric config field is a positive safe integer.
 * @param config - Schemastery-resolved plugin configuration.
 * @returns Narrows the input to the fully resolved configuration.
 */
export declare function validateConfig(config: Config): asserts config is ResolvedConfig;
//# sourceMappingURL=config.d.ts.map