/**
 * The terminal a person drives, as a Host service.
 *
 * This is deliberately NOT the model-facing PTY stack. `ctx.terminals` fences
 * every call to one live `Agent`, reads by polling, and its bash backend runs
 * `--noprofile --norc` so the model meets a shell that behaves the same on
 * every machine. A person wants the opposite of all three: a session that
 * outlives any one chat, output that arrives as it is produced, and their own
 * prompt, aliases and completions. So this owns its own registry over the
 * `ctx.subprocess.spawnTerminal` primitive and shares nothing with that one.
 *
 * Output leaves as a cordis event rather than a return value because a
 * terminal has no request/response shape: the shell speaks whenever it likes,
 * including long after the call that started it returned.
 * @module @unieai/uad-terminal-operator
 */
import { Context, Service } from '@unieai/cordis';
import { Config } from './config.ts';
import { type OperatorTerminalId, type OperatorTerminalOpenSpec, type OperatorTerminalSignal, type OperatorTerminalView } from './types.ts';
export { Config, validateConfig } from './config.ts';
export type { ResolvedConfig } from './config.ts';
export { Scrollback } from './scrollback.ts';
export { operatorTerminalEnv, operatorTerminalTitle, resolveOperatorShell } from './shell.ts';
export { OperatorTerminalError, type OperatorTerminalErrorCode, type OperatorTerminalId, type OperatorTerminalOpenSpec, type OperatorTerminalSignal, type OperatorTerminalView, } from './types.ts';
declare module '@unieai/cordis' {
    interface Context {
        operatorTerminals: OperatorTerminalService;
    }
    interface Events {
        /**
         * Output produced by one operator terminal, in delivery order.
         * @param terminalId - the terminal that produced it.
         * @param chunk - UTF-8 text exactly as the PTY delivered it.
         * @mode emit
         */
        'operator-terminal/output': (terminalId: OperatorTerminalId, chunk: string) => void;
        /**
         * One operator terminal's shell exited; the terminal keeps its scrollback.
         * @param terminalId - the terminal that ended.
         * @param exitCode - platform exit code when one was reported.
         * @mode emit
         */
        'operator-terminal/exited': (terminalId: OperatorTerminalId, exitCode?: number) => void;
        /**
         * The set of operator terminals changed: one opened, or one was closed and
         * forgotten. Sent whole because a reconnecting client has to converge on
         * the same list a second tab sees.
         * @param terminals - every terminal the service still holds.
         * @mode emit
         */
        'operator-terminal/changed': (terminals: OperatorTerminalView[]) => void;
    }
}
/** Filesystem probe the service uses to resolve a shell; injectable for tests. */
export interface ShellProbe {
    /**
     * @param path - absolute path to test.
     * @returns whether an executable file is present there.
     */
    exists(path: string): boolean;
}
/**
 * Registry of the terminals a person opened in the GUI.
 *
 * Terminals are scoped to a workspace, not to a chat session: a shell running
 * `npm run dev` must not die because the user started a new conversation.
 */
export declare class OperatorTerminalService extends Service {
    private readonly probe;
    private readonly env;
    private readonly hostname;
    static inject: string[];
    static Config: import("@unieai/schemastery").default<Config>;
    private readonly terminals;
    private readonly config;
    private nextId;
    private disposing;
    /**
     * @param ctx - Host plugin context.
     * @param config - plugin config; Schemastery defaults are already applied.
     * @param probe - executable-presence test; the real filesystem by default.
     * @param env - environment the shell inherits; this process's by default.
     * @param hostname - this machine's name, for the tab title; the real one by default.
     */
    constructor(ctx: Context, config: Config, probe?: ShellProbe, env?: Record<string, string | undefined>, hostname?: () => string);
    /**
     * Open one terminal in a workspace directory.
     * @param spec - workspace, directory, and the client's current size.
     * @returns the new terminal's view.
     */
    open(spec: OperatorTerminalOpenSpec): Promise<OperatorTerminalView>;
    /**
     * Deliver keystrokes to a terminal.
     * @param terminalId - the terminal to write to.
     * @param data - text exactly as typed; no newline is added.
     */
    write(terminalId: OperatorTerminalId, data: string): Promise<void>;
    /**
     * Tell a terminal its panel changed size.
     * @param terminalId - the terminal to resize.
     * @param cols - column count reported by the client.
     * @param rows - row count reported by the client.
     */
    resize(terminalId: OperatorTerminalId, cols: number, rows: number): Promise<void>;
    /**
     * Deliver a signal to a terminal's foreground process group, which is what
     * Ctrl-C in a real terminal does.
     * @param terminalId - the terminal to signal.
     * @param signal - the signal to deliver.
     */
    signal(terminalId: OperatorTerminalId, signal: OperatorTerminalSignal): Promise<void>;
    /**
     * Everything retained for a terminal, so a reopened panel can repaint.
     * @param terminalId - the terminal to read.
     * @returns its retained output in delivery order.
     */
    replay(terminalId: OperatorTerminalId): string;
    /**
     * Project every terminal this service holds, so a reconnecting client and a
     * second tab converge on the same list.
     * @returns a view of every terminal the service holds, live or finished.
     */
    list(): OperatorTerminalView[];
    /**
     * End a terminal and forget it, including its scrollback.
     * @param terminalId - the terminal to close.
     */
    close(terminalId: OperatorTerminalId): Promise<void>;
    /**
     * Forward one terminal's output until it ends, then publish the exit.
     * @param record - the terminal to follow.
     */
    private pump;
    /**
     * Mark a terminal finished and tell its watchers once.
     * @param record - the terminal that ended.
     * @param exitCode - platform exit code when one was reported.
     */
    private settle;
    /**
     * @param terminalId - the terminal to look up.
     * @returns its record.
     */
    private record;
    /**
     * @param terminalId - the terminal to look up.
     * @returns its record, having proved the shell is still running.
     */
    private live;
    /** Terminate every terminal and await quiescence. */
    private disposeAll;
}
/** Executable-presence test against the real filesystem. */
export declare const FILESYSTEM_SHELL_PROBE: ShellProbe;
export default OperatorTerminalService;
//# sourceMappingURL=index.d.ts.map