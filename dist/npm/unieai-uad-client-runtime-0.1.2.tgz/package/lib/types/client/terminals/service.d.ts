/**
 * The browser half of the terminal a PERSON drives.
 *
 * A terminal has two directions with very different shapes. Everything the
 * person does — open, type, resize, Ctrl-C, close — is a call and gets an
 * answer. Everything the shell does arrives whenever the shell feels like it,
 * so it comes back as host frames and is delivered here to whoever is
 * currently rendering that terminal.
 *
 * This owns no rendering and no scrollback of its own: the Host retains the
 * output (it is the only side that has it while no panel is mounted), and the
 * renderer keeps what it has painted. What this owns is the list, the
 * subscriptions, and the fact that a terminal outlives the panel showing it.
 */
import type { Context } from '@unieai/cordis';
import type { IApiClient, RpcRequest, HostFrame, TerminalSignalName, TerminalView } from '@unieai/uad-api-remotes/client';
import type { SnapshotStore } from '../contract/store.ts';
/** Every terminal the Host holds, as the panel sees them. */
export interface TerminalListState {
    terminals: readonly TerminalView[];
    /** True once the first list has arrived; a panel shows nothing before it. */
    ready: boolean;
}
/** What one mounted renderer is told. */
export interface TerminalSink {
    /**
     * Output arrived.
     * @param chunk - text exactly as the shell produced it.
     */
    output: (chunk: string) => void;
    /**
     * The shell ended.
     * @param exitCode - platform exit code when one was reported.
     */
    exited: (exitCode: number | undefined) => void;
}
/** A structured terminal failure a panel can branch on. */
export declare class TerminalError extends Error {
    readonly code: string;
    constructor(code: string, message: string);
}
/**
 * Terminals as UI consumers see them.
 *
 * Registered on the client context so a panel reaches it the same way it
 * reaches workspaces, rather than being handed an API client and asked to
 * remember which methods are loopback-pinned.
 */
export declare class TerminalRuntime {
    private readonly api;
    /** Every terminal the Host holds; a panel renders its tab strip from this. */
    readonly store: SnapshotStore<TerminalListState>;
    private readonly sinks;
    private readonly writeTails;
    /**
     * @param ctx - client plugin context this service registers on.
     * @param api - the wire face.
     */
    constructor(ctx: Context, api: IApiClient);
    /**
     * Open a terminal in a workspace directory.
     * @param workspaceId - workspace the terminal belongs to.
     * @param cwd - absolute directory the shell starts in; must be a registered workspace root.
     * @param cols - columns the panel currently measures.
     * @param rows - rows the panel currently measures.
     * @returns the new terminal and whatever it has already produced.
     */
    open(workspaceId: string, cwd: string, cols: number, rows: number): Promise<{
        terminal: TerminalView;
        replay: string;
    }>;
    /**
     * The live terminal already running for one workspace, if any.
     *
     * Newest first: if a workspace somehow holds more than one, the last one
     * opened is the one the person was last looking at.
     * @param workspaceId - the workspace to look in.
     * @returns its newest live terminal's id, or undefined.
     */
    liveIn(workspaceId: string): string | undefined;
    /**
     * Re-read a terminal, for a panel that was closed and reopened.
     * @param terminalId - the terminal to read.
     * @returns the terminal and everything the Host still retains for it.
     */
    replay(terminalId: string): Promise<{
        terminal: TerminalView;
        replay: string;
    }>;
    /**
     * Deliver keystrokes verbatim, in the order they were typed.
     *
     * Writes are chained per terminal rather than issued concurrently. Each one
     * is its own HTTP request, and HTTP promises nothing about the order two
     * in-flight requests complete in — typing `echo` fast enough produced `ecoh`
     * on a real shell. A terminal that reorders keystrokes is not a terminal, so
     * the ordering is enforced here, at the only place that knows a keystroke
     * belongs to the same stream as the last one.
     *
     * The chain is per terminal: two panels typing into two shells do not wait
     * on each other. A failed write does not poison the chain — the next
     * keystroke still goes — because the alternative is a terminal that stays
     * dead after one dropped packet.
     * @param terminalId - the terminal to write to.
     * @param data - text exactly as typed.
     * @returns settles once THIS write has been delivered.
     */
    write(terminalId: string, data: string): Promise<void>;
    /**
     * Report the panel's current size.
     * @param terminalId - the terminal to resize.
     * @param cols - columns.
     * @param rows - rows.
     */
    resize(terminalId: string, cols: number, rows: number): Promise<void>;
    /**
     * Signal the foreground process group.
     * @param terminalId - the terminal to signal.
     * @param signal - the signal to deliver.
     */
    signal(terminalId: string, signal: TerminalSignalName): Promise<void>;
    /**
     * End a terminal and forget it.
     * @param terminalId - the terminal to close.
     */
    close(terminalId: string): Promise<void>;
    /**
     * Receive one terminal's traffic while a renderer is mounted.
     *
     * Returns a disposer rather than taking a lifetime, because the thing that
     * ends a subscription is a component unmounting — and the terminal itself
     * keeps running, which is the point.
     * @param terminalId - the terminal to follow.
     * @param sink - where its traffic goes.
     * @returns disposer that removes exactly this subscription.
     */
    subscribe(terminalId: string, sink: TerminalSink): () => void;
    /**
     * Route one host frame.
     * @param envelope - the frame as it arrived.
     */
    handleHostEnvelope(envelope: RpcRequest<HostFrame>): void;
    /**
     * Re-baseline after a reconnect.
     *
     * A dropped websocket loses output that arrived while it was down, so a
     * renderer cannot simply resume: the list is re-read here, and each mounted
     * renderer re-reads its own terminal's retained output.
     */
    handleConnected(): void;
    /** Read the Host's list and publish it. */
    refresh(): Promise<void>;
    /**
     * Unwrap one wire result.
     * @param result - the result as it arrived.
     * @param method - the call, for the message.
     * @returns the value when the call succeeded.
     */
    private value;
}
declare module '@unieai/cordis' {
    interface Context {
        panelTerminals: TerminalRuntime;
    }
}
//# sourceMappingURL=service.d.ts.map