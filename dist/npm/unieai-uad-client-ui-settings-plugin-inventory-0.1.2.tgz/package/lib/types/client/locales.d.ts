/**
 * Copy for the plugin directory.
 *
 * Where the UnieAI Copilot web product publishes an equivalent string, it is
 * copied VERBATIM from `messages/{en,zh-cn,zh-tw,ja}.json` and the source
 * namespace and key are named beside the line. The desktop's Plugins page is
 * this product's plugin destination and the reference product has one of its
 * own; a paraphrase would make the two look like different features.
 *
 * THREE DEVIATIONS, ALL DELIBERATE:
 *   - `enabledTag`/`disabledTag` in zh-CN keep this package's own shipped
 *     pair (`已启用`/`已停用`) rather than the reference's
 *     `SettingsSubscription.enabled`/`.disabled`, whose zh-cn values are
 *     written in TRADITIONAL characters (`啟用`/`停用`) — a defect in that
 *     file, not a translation. zh-TW carries the traditional form of this
 *     package's pair for the same reason. en and ja are verbatim.
 *   - The Loader lifecycle labels (`unobserved` … `unloading`) name Cordis
 *     Fiber states. The reference product has no Loader and no equivalent
 *     copy, so all four locales are this package's own words, unchanged from
 *     what it already shipped in en and zh-CN.
 *   - `intro` and `note` are this package's own. `note` names the command
 *     that actually installs a plugin, because this surface has no install
 *     control and must not grow one that cannot act: the honest replacement
 *     for a dead button is the sentence saying where the action lives, which
 *     is the same thing the Studio MCP area above it does.
 *
 * All four shipped locales carry a complete dictionary, so nothing here falls
 * back to English.
 */
/** Simplified Chinese dictionary and key source of truth. */
export declare const zh: {
    title: string;
    intro: string;
    search: string;
    loading: string;
    error: string;
    retry: string;
    empty: string;
    emptySearch: string;
    enabledTag: string;
    disabledTag: string;
    unobserved: string;
    pending: string;
    loadingPhase: string;
    active: string;
    failed: string;
    unloading: string;
    note: string;
};
/** Plugin directory locale key union. */
export type PluginInventoryLocaleKey = keyof typeof zh;
/** Traditional Chinese dictionary. */
export declare const zhTW: {
    title: string;
    intro: string;
    search: string;
    loading: string;
    error: string;
    retry: string;
    empty: string;
    emptySearch: string;
    enabledTag: string;
    disabledTag: string;
    unobserved: string;
    pending: string;
    loadingPhase: string;
    active: string;
    failed: string;
    unloading: string;
    note: string;
};
/** Japanese dictionary. */
export declare const ja: {
    title: string;
    intro: string;
    search: string;
    loading: string;
    error: string;
    retry: string;
    empty: string;
    emptySearch: string;
    enabledTag: string;
    disabledTag: string;
    unobserved: string;
    pending: string;
    loadingPhase: string;
    active: string;
    failed: string;
    unloading: string;
    note: string;
};
/** English dictionary checked against the Chinese key set. */
export declare const en: {
    title: string;
    intro: string;
    search: string;
    loading: string;
    error: string;
    retry: string;
    empty: string;
    emptySearch: string;
    enabledTag: string;
    disabledTag: string;
    unobserved: string;
    pending: string;
    loadingPhase: string;
    active: string;
    failed: string;
    unloading: string;
    note: string;
};
//# sourceMappingURL=locales.d.ts.map