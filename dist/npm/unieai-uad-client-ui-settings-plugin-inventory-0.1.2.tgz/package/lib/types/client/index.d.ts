/**
 * The plugin directory, browser half: one area on the Plugins page listing
 * every plugin the Cordis Loader reports for this build.
 *
 * WHY THE PAGE AND NOT THE SETTINGS PANEL. This used to be the `all` tab
 * inside `ui-settings-plugins`' section, and that section has since become an
 * area on the standalone Plugins page. Two things follow. First, there is no
 * `plugins` settings section any more — `ui-settings-general` hides its
 * Plugins nav row exactly when none exists — so putting the directory back
 * into the panel would resurrect a second Plugins destination, which is the
 * thing the page was created to end. Second, a directory is what the page IS:
 * behind a tab in a developer-facing configuration section it is a subsection
 * of a subsection, and its chrome (the tab strip, the heading above it)
 * belongs to another package.
 *
 * So it registers into `plugins.page.area`, the seat the page documents for a
 * surface of its own, at `order` 5: after the account's Studio MCP servers
 * and before the cordis configuration cards. Account, then build, then the
 * developer's knobs.
 *
 * The Remote is read lazily, when the page first mounts the area — the
 * inventory belongs to a Loader that can change under a long-lived document,
 * and a read at boot would show a stale answer for the rest of the session.
 */
import type { ClientContext } from '@unieai/uad-client-runtime/client';
import { type PluginInventoryLocaleKey } from './locales.ts';
export type { PluginDirectoryAreaInjected, PluginDirectoryAreaProps } from './PluginDirectoryArea.tsx';
export type { PluginInventoryLocaleKey } from './locales.ts';
declare module '@unieai/uad-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** Read-only Host plugin directory copy. */
        'settings.pluginInventory': PluginInventoryLocaleKey;
    }
}
/** Dictionary namespace owned by this plugin. */
export declare const NS = "settings.pluginInventory";
/** Services required by the page registration and generated Remote face. */
export declare const inject: string[];
/**
 * Contribute the plugin directory to the Plugins page.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map