/**
 * The plugin directory: every plugin this build loads, on the Plugins page.
 *
 * IT LISTS. IT DOES NOT INSTALL, ENABLE, DISABLE OR REMOVE, and it draws no
 * control that would suggest it could. `pluginInventory.list()` is the only
 * plugin RPC that exists on this deployment; installing is a CLI command
 * (`rabi plugin --profile web add <spec>`, a pnpm forwarder) and enablement is
 * a line in the profile's `cordis.patch.yml`. The reference directory's `+`
 * and `✓` would therefore fail on press, every time, so the trailing column
 * carries a runtime status DOT instead — a mark, not a button — and the
 * sentence under the list names the command that actually works.
 *
 * WHAT THE HEADINGS ARE, AND WHY THERE ARE ONLY TWO. The reference groups by
 * an editorial category (`Featured`, `Coding`) drawn from a curated
 * catalogue, and filters by provenance (`Curated by OpenAI`, `Shared with
 * you`) drawn from who published each plugin. This deployment has neither
 * fact. The wire carries exactly four fields per row — the Loader entry id,
 * the module specifier, effective enablement, and the root Fiber's phase — of
 * which one, `enabled`, is a stated partition. So the directory groups by it:
 * Enabled and Disabled, in Loader order inside each.
 *
 * The groupings NOT taken, and why:
 *   - By bundle (`dsh-base` / `dsh-web-app` / a profile-installed bundle).
 *     This is the true equivalent of the reference's provenance filter and it
 *     is the one worth having, but the composer applies each bundle's patch
 *     list over an empty root IN MEMORY and the resulting Loader entry keeps
 *     no memory of which layer inserted it. Nothing on the wire can be made
 *     to say it; see the README.
 *   - By host plane versus browser plane. Every browser row happens to be
 *     named `@unieai/uad-client-*` — but `@unieai/uad-api-remotes`
 *     is a browser row too, and `dsh-client-modules` is both. That is a
 *     naming convention with exceptions, not data, and segmentation dressed
 *     as taxonomy reads as fact.
 *   - By Fiber phase. Five buckets, four of them usually empty, and the row
 *     already carries its phase as the dot.
 *
 * THE ROW IS NOT A CARD. No border, no fill, no radius: a heading with a
 * hairline under it, and under that a reflowing grid of two-line rows. The
 * plain name is the title and the exact module specifier is the line beneath
 * it, in the code face, because that specifier is what a reader would have to
 * type. The Loader entry id is a coordinate into `cordis.patch.yml` rather
 * than a description of anything, so it is searchable and carried on the row
 * as `data-plugin-entry`, but it is not drawn: for all but a handful of rows
 * it repeats the title.
 */
import { type ReactNode } from 'react';
import type { PluginInventorySnapshot } from '@unieai/uad-api-remotes/client';
import type { InjectFace, PropsLocale, PropsRuntime } from '@unieai/uad-client-ui-slots';
/** Registration-side Remote face used by the directory. */
export interface PluginDirectoryAreaInjected {
    /** Read a current Host inventory snapshot. */
    list: () => Promise<PluginInventorySnapshot>;
}
/** Full component props assembled by the Plugins page's slot renderer. */
export type PluginDirectoryAreaProps = PropsRuntime<'plugins.page.area'> & PropsLocale<'settings.pluginInventory'> & InjectFace<PluginDirectoryAreaInjected>;
/**
 * Render the read-only plugin directory.
 * @param props - composed slot props.
 * @returns the area element tree.
 */
export declare function PluginDirectoryArea({ list, t }: PluginDirectoryAreaProps): ReactNode;
//# sourceMappingURL=PluginDirectoryArea.d.ts.map