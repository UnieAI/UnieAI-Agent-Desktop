/** Host loader entry for the plugin-directory browser implementation exported from `./client`. */
/** Host plugin body — no host-side behavior for the plugin directory. */
export declare function apply(): void;
//# sourceMappingURL=index.d.ts.map