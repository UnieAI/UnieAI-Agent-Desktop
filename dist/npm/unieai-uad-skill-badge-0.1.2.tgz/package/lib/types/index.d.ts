/**
 * Bundled `dsh-badge` skill provider.
 *
 * @module @unieai/uad-skill-badge
 */
import type { Context } from '@unieai/cordis';
/** Cordis plugin name. */
export declare const name = "skill-badge";
/** Service required by the bundled provider. */
export declare const inject: string[];
/** Register the bundled `dsh-badge` provider on `ctx.skills`. */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map