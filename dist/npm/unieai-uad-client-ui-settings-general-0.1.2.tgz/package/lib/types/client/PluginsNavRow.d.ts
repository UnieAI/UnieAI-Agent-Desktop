import type { PluginsNavRowComponentProps } from './shell-contract.ts';
/**
 * Render the Plugins nav row.
 * @param props - composed slot props (contract in shell-contract.ts).
 * @returns the row button, or null while no plugins section is registered.
 */
export declare function PluginsNavRow({ wide, t, useSections, openPanel }: PluginsNavRowComponentProps): import("react").JSX.Element | null;
//# sourceMappingURL=PluginsNavRow.d.ts.map