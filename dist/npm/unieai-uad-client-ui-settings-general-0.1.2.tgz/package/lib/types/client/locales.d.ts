/**
 * Shell chrome, sidebar nav-row, and General-nav dictionaries; feature rows
 * own their copy. The nav-row wording tracks the UnieAI web product's own
 * sidebar (`AgentNext.plugins`).
 *
 * `subtitle` is the header band's summary line. The reference enumerates the
 * features its own settings page carries; this one does not, because the
 * sections here are whatever the composition registered — an enumeration
 * would name pages a given build may not have.
 */
/** Simplified Chinese dictionary (the key-set source of truth). */
export declare const zh: {
    trigger: string;
    title: string;
    subtitle: string;
    close: string;
    openDocument: string;
    'openDocument.error': string;
    'general.nav': string;
    'nav.plugins': string;
    'nav.group.personal': string;
    'nav.group.chat': string;
};
/** The settings namespace key union. */
export type SettingsKey = keyof typeof zh;
/** English dictionary, checked complete against the zh key set. */
export declare const en: {
    trigger: string;
    title: string;
    subtitle: string;
    close: string;
    openDocument: string;
    'openDocument.error': string;
    'general.nav': string;
    'nav.plugins': string;
    'nav.group.personal': string;
    'nav.group.chat': string;
};
/** Traditional Chinese dictionary, checked complete against the zh key set. */
export declare const zhTW: {
    trigger: string;
    title: string;
    subtitle: string;
    close: string;
    openDocument: string;
    'openDocument.error': string;
    'general.nav': string;
    'nav.plugins': string;
    'nav.group.personal': string;
    'nav.group.chat': string;
};
/** Japanese dictionary, checked complete against the zh key set. */
export declare const ja: {
    trigger: string;
    title: string;
    subtitle: string;
    close: string;
    openDocument: string;
    'openDocument.error': string;
    'general.nav': string;
    'nav.plugins': string;
    'nav.group.personal': string;
    'nav.group.chat': string;
};
//# sourceMappingURL=locales.d.ts.map