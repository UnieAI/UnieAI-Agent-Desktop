/**
 * Settings shell contract — the types of the `sidebar.settings` occupant this
 * package renders. They live here rather than in ui-settings because they
 * reference the sidebar's own slot type: ui-settings is the settings domain's
 * base layer and must not depend on any `ui-*` presentation package, or the
 * reference graph closes a cycle through ui-sidebar → ui-layout → ui-theme.
 * The settings SLOT types (what registrants contribute) stay in ui-settings.
 */
import type { HostObservable, InjectFace, PropsLocale, PropsRenderSlots, PropsRuntime } from '@unieai/uad-client-ui-slots';
import type { SettingsPanelState } from './settings-panel-store.ts';
/** One nav row projected from a settings.section registration's options. */
export interface SettingsSectionRow {
    id: string;
    order: number;
    label: string;
}
/** One ordered onboarding step projected from a slot registration. */
export interface SettingsOnboardingStep {
    id: string;
    order: number;
}
/**
 * Registrant-private injected share of the settings shell (assembled in
 * apply): the ledger's nav-row projection as a hooks-compartment source —
 * the shell reads no locale state and subscribes through the bound hook.
 */
export type SettingsRootInjected = {
    hooks: {
        /** settings.section ledger projected into ordered nav rows. */
        sections: HostObservable<readonly SettingsSectionRow[]>;
        /** settings.onboarding ledger projected into coordinator order. */
        onboardingSteps: HostObservable<readonly SettingsOnboardingStep[]>;
        /** Panel open state, bound by the UI renderer as usePanel. */
        panel: HostObservable<SettingsPanelState>;
    };
    /**
     * Open the panel, optionally on a section and an anchor inside it. Same
     * gesture the `settingsPanel` service exposes to other packages.
     */
    openPanel: (sectionId?: string, anchorId?: string) => void;
    /** Move the selection inside the open panel. */
    selectSection: (sectionId: string) => void;
    /** Close the panel. */
    closePanel: () => void;
};
/**
 * Full component props of the settings shell root: the sidebar owner share
 * (wide/rail state) plus the declared render shares, the injected face (hooks
 * compartment bound to useSections and usePanel), and the locale seat. Panel
 * open state and the requested section live in the apply-level controller
 * rather than in local state, because two other surfaces open this panel —
 * the Plugins nav row, and the sidebar account menu through the
 * `settingsPanel` service. The locale seat carries the nav's own group
 * headings, the one piece of copy the shell owns.
 */
export type SettingsRootComponentProps = PropsRuntime<'sidebar.settings'> & PropsRenderSlots<'settings.trigger' | 'settings.header' | 'settings.action' | 'settings.close' | 'settings.section' | 'settings.onboarding'> & InjectFace<SettingsRootInjected> & PropsLocale<'settings'>;
/**
 * Full component props of the Plugins nav row: the sidebar nav owner share,
 * the same section ledger the shell projects (so the row can tell whether a
 * plugins section exists), the panel controller it opens, and the locale seat.
 */
export type PluginsNavRowComponentProps = PropsRuntime<'sidebar.nav.action'> & InjectFace<SettingsRootInjected> & PropsLocale<'settings'>;
//# sourceMappingURL=shell-contract.d.ts.map