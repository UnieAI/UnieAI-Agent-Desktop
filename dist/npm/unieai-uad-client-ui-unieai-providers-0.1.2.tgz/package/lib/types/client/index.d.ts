/**
 * UnieAI API Provider settings plugin, browser half: registers the API
 * Provider section, which mirrors the account's providers from the UnieAI
 * Copilot web product and can add one back to it.
 *
 * The section reads and writes the sign-in gate's `/auth/providers` routes.
 * That indirection is the point: the API key authenticating the product's
 * `/api/desktop/*` surface lives in the gate's session table on the host, and
 * must never reach a page. The browser asks the host, the host asks the
 * product. The provider credential a create carries travels the same way, and
 * nothing on the return path carries any credential at all.
 *
 * This section sits AFTER Models in the panel. Models is the desktop's own
 * provider surface over `settings.yaml` and is what a local agent actually
 * runs on; this one is the cloud account's list, and putting it second says
 * which of the two the desktop owns.
 *
 * Export discipline: packages/client/AGENTS.md.
 */
import type { ClientContext } from '@unieai/uad-client-runtime/client';
export type { ProvidersSectionComponentProps, ProvidersSectionInjected } from './ProvidersSection.tsx';
export type { ProvidersKey } from './locales.ts';
export type { ProviderDraft, ProviderFailure, ProviderOutcome, ProviderPatch, ProviderRow, ProvidersState, } from './provider-source.ts';
/**
 * Required services (cordis fiber inject). `settings.section` is declared by
 * another package's apply, whose activation order relative to this one is NOT
 * constrained; the registration waits on the declaration through
 * `slots.inject()`.
 */
export declare const inject: string[];
/**
 * Register the API Provider section and its dictionaries, and start its first
 * read.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map