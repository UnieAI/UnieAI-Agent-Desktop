import type { InjectFace, PropsLocale, PropsRuntime } from '@unieai/uad-client-ui-slots';
import type { ProviderDraft, ProviderOutcome, ProviderPatch, ProviderSource } from './provider-source.ts';
/** Injected business face of the API Provider section (slot `inject`). */
export interface ProvidersSectionInjected {
    hooks: {
        /** Provider list state, bound by the UI renderer as useProviders. */
        providers: ProviderSource;
    };
    /** Re-read the list from the host. */
    refresh: () => void;
    /** Submit one new provider to the web product. */
    create: (draft: ProviderDraft) => Promise<ProviderOutcome>;
    /** Apply one edit to a provider the account already has. */
    update: (id: string, patch: ProviderPatch) => Promise<ProviderOutcome>;
    /** Remove one provider, and with it every model it offered. */
    remove: (id: string) => Promise<ProviderOutcome>;
}
/** Full component props: runtime share + locale seat + injected face. */
export type ProvidersSectionComponentProps = PropsRuntime<'settings.section'> & PropsLocale<'settings.providers'> & InjectFace<ProvidersSectionInjected>;
/**
 * Render the API Provider section.
 * @param props - composed slot props.
 * @returns the section element tree.
 */
export declare function ProvidersSection({ t, useProviders, refresh, create, update, remove }: ProvidersSectionComponentProps): import("react").JSX.Element;
//# sourceMappingURL=ProvidersSection.d.ts.map