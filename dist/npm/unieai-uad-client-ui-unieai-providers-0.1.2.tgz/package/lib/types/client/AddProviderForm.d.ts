import type { ReactNode } from 'react';
import type { TranslateNS } from '@unieai/uad-client-ui-slots';
import type { ProviderFailure, ProviderDraft } from './provider-source.ts';
/** Props of {@link AddProviderForm}. */
export interface AddProviderFormProps {
    /** Section copy. */
    t: TranslateNS<'settings.providers'>;
    /** Submit the draft; resolves with what the product decided. */
    onCreate: (draft: ProviderDraft) => Promise<{
        ok: true;
    } | {
        ok: false;
        reason: ProviderFailure;
    }>;
    /** Close the card; `created` reports whether a provider was actually added. */
    onClose: (created: boolean) => void;
}
/**
 * Render the Add Provider card.
 * @param props - copy plus the submit and close callbacks.
 * @returns the card.
 */
export declare function AddProviderForm({ t, onCreate, onClose }: AddProviderFormProps): ReactNode;
//# sourceMappingURL=AddProviderForm.d.ts.map