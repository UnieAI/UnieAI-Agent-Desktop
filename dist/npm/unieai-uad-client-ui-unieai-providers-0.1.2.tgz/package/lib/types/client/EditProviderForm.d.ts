import type { ReactNode } from 'react';
import type { TranslateNS } from '@unieai/uad-client-ui-slots';
import type { ProviderOutcome, ProviderPatch, ProviderRow } from './provider-source.ts';
/** What one closed card leaves behind on the section. */
export type EditResult = 'saved' | 'deleted' | undefined;
/** Props of {@link EditProviderForm}. */
export interface EditProviderFormProps {
    /** Section copy. */
    t: TranslateNS<'settings.providers'>;
    /** The provider being edited, as the product last reported it. */
    row: ProviderRow;
    /** Apply the patch; resolves with what the product decided. */
    onSave: (patch: ProviderPatch) => Promise<ProviderOutcome>;
    /** Remove the provider; resolves with what the product decided. */
    onDelete: () => Promise<ProviderOutcome>;
    /** Close the card, naming what it changed. */
    onClose: (result: EditResult) => void;
}
/**
 * Render the Edit Provider card.
 * @param props - the row, the section's copy, and the three callbacks.
 * @returns the card.
 */
export declare function EditProviderForm({ t, row, onSave, onDelete, onClose }: EditProviderFormProps): ReactNode;
//# sourceMappingURL=EditProviderForm.d.ts.map