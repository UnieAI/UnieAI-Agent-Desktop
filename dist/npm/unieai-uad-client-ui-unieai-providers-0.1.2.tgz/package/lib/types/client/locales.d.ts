/**
 * API Provider section copy.
 *
 * Every key whose text the UnieAI Copilot web product already publishes is
 * copied VERBATIM from `messages/{en,zh-tw,zh-cn,ja}.json`'s `Settings`
 * namespace — the source keys are named beside each line. That is not a
 * stylistic preference: this section shows the same rows as that product's
 * "API Provider Settings" page, and a paraphrase would make one list look like
 * two features.
 *
 * `API URL` and `API Key` are literals in the reference's own markup, in every
 * locale, so they are literals here too. The remaining keys — the ones below
 * the divider in each dictionary — are this package's own words, and they are
 * of two sorts: states the web page cannot be in (no session, an unreachable
 * host, a list that is still loading), and the two managed-row explanations
 * that the product publishes ONLY as hard-coded Traditional Chinese inside
 * `app/api/user/providers/[id]/route.ts` (`managedNoDelete`, `error.managed`).
 * The zh-TW lines of those two are that route's own text, character for
 * character; the other three locales are translations of it, because there is
 * no published original to copy.
 *
 * Three keys deliberately DIVERGE from the reference, each one a case where
 * copying verbatim would state something this build cannot honour:
 *
 *   - `nav` is the settings column's row label, not the page heading. The
 *     reference publishes no separate nav string, and
 *     `apiProviderSettingsTitle` is twenty characters against a 176px column,
 *     so it rendered as `API Provider Setti…`. The words are still the
 *     reference's own — the name it gives the page where it enumerates it in
 *     `SettingsPage.description`: `API Providers` in English, `API Provider`
 *     elsewhere. `title` carries the heading verbatim, unchanged.
 *   - `managed` is a state badge, not a name. The reference's badge text is
 *     the words `UnieAI Studio`, and on this desktop it sits beside a provider
 *     whose display name is ALSO `UnieAI Studio` — a badge repeating the row's
 *     own name carries nothing and competes with the routing prefix next to
 *     it. It says what being managed means instead, in the one-word shape the
 *     `disabled` badge sharing its slot already uses.
 *   - `managedHint` and `emptyHint` drop the reference's `Sync models`
 *     sentence. No such control exists here and none can: the projection this
 *     page reads reports model IDS rather than the catalogue objects carrying
 *     the modality flags, so `modelList` is refused as
 *     `model_list_unsupported` and a round trip could only write the catalogue
 *     back flattened. Copy that teaches a button which is not on the screen is
 *     worse than a paraphrase.
 *
 * All four shipped locales carry a complete dictionary, so nothing here falls
 * back to English.
 */
/** Simplified Chinese dictionary (the key-set source of truth). */
export declare const zh: {
    nav: string;
    title: string;
    intro: string;
    add: string;
    empty: string;
    emptyHint: string;
    unnamed: string;
    urlUnset: string;
    disabled: string;
    managed: string;
    managedHint: string;
    models: string;
    'form.name': string;
    'form.namePlaceholder': string;
    'form.prefix': string;
    'form.prefixPlaceholder': string;
    'form.url': string;
    'form.urlPlaceholder': string;
    'form.key': string;
    'form.keyPlaceholder': string;
    'form.submit': string;
    'form.submitting': string;
    'form.cancel': string;
    created: string;
    'error.name': string;
    'error.prefixRequired': string;
    'error.prefixFormat': string;
    'error.prefixExists': string;
    'error.fields': string;
    'error.failed': string;
    edit: string;
    save: string;
    saving: string;
    saved: string;
    delete: string;
    confirmDelete: string;
    deleted: string;
    'error.deleteFailed': string;
    'form.enabled': string;
    'form.models': string;
    'form.selectAll': string;
    'form.clearAll': string;
    loading: string;
    signedOut: string;
    unreadable: string;
    retry: string;
    'error.url': string;
    'error.limit': string;
    'error.notFound': string;
    deleting: string;
    deleteWarning: string;
    'form.keyKeep': string;
    'form.noModels': string;
    managedEditable: string;
    managedNoDelete: string;
    'error.managed': string;
};
/** The provider namespace key union. */
export type ProvidersKey = keyof typeof zh;
declare module '@unieai/uad-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** The API Provider settings section's copy. */
        'settings.providers': ProvidersKey;
    }
}
/** Traditional Chinese dictionary, checked complete against the zh key set. */
export declare const zhTW: {
    nav: string;
    title: string;
    intro: string;
    add: string;
    empty: string;
    emptyHint: string;
    unnamed: string;
    urlUnset: string;
    disabled: string;
    managed: string;
    managedHint: string;
    models: string;
    'form.name': string;
    'form.namePlaceholder': string;
    'form.prefix': string;
    'form.prefixPlaceholder': string;
    'form.url': string;
    'form.urlPlaceholder': string;
    'form.key': string;
    'form.keyPlaceholder': string;
    'form.submit': string;
    'form.submitting': string;
    'form.cancel': string;
    created: string;
    'error.name': string;
    'error.prefixRequired': string;
    'error.prefixFormat': string;
    'error.prefixExists': string;
    'error.fields': string;
    'error.failed': string;
    edit: string;
    save: string;
    saving: string;
    saved: string;
    delete: string;
    confirmDelete: string;
    deleted: string;
    'error.deleteFailed': string;
    'form.enabled': string;
    'form.models': string;
    'form.selectAll': string;
    'form.clearAll': string;
    loading: string;
    signedOut: string;
    unreadable: string;
    retry: string;
    'error.url': string;
    'error.limit': string;
    'error.notFound': string;
    deleting: string;
    deleteWarning: string;
    'form.keyKeep': string;
    'form.noModels': string;
    managedEditable: string;
    managedNoDelete: string;
    'error.managed': string;
};
/** English dictionary, checked complete against the zh key set. */
export declare const en: {
    nav: string;
    title: string;
    intro: string;
    add: string;
    empty: string;
    emptyHint: string;
    unnamed: string;
    urlUnset: string;
    disabled: string;
    managed: string;
    managedHint: string;
    models: string;
    'form.name': string;
    'form.namePlaceholder': string;
    'form.prefix': string;
    'form.prefixPlaceholder': string;
    'form.url': string;
    'form.urlPlaceholder': string;
    'form.key': string;
    'form.keyPlaceholder': string;
    'form.submit': string;
    'form.submitting': string;
    'form.cancel': string;
    created: string;
    'error.name': string;
    'error.prefixRequired': string;
    'error.prefixFormat': string;
    'error.prefixExists': string;
    'error.fields': string;
    'error.failed': string;
    edit: string;
    save: string;
    saving: string;
    saved: string;
    delete: string;
    confirmDelete: string;
    deleted: string;
    'error.deleteFailed': string;
    'form.enabled': string;
    'form.models': string;
    'form.selectAll': string;
    'form.clearAll': string;
    loading: string;
    signedOut: string;
    unreadable: string;
    retry: string;
    'error.url': string;
    'error.limit': string;
    'error.notFound': string;
    deleting: string;
    deleteWarning: string;
    'form.keyKeep': string;
    'form.noModels': string;
    managedEditable: string;
    managedNoDelete: string;
    'error.managed': string;
};
/** Japanese dictionary, checked complete against the zh key set. */
export declare const ja: {
    nav: string;
    title: string;
    intro: string;
    add: string;
    empty: string;
    emptyHint: string;
    unnamed: string;
    urlUnset: string;
    disabled: string;
    managed: string;
    managedHint: string;
    models: string;
    'form.name': string;
    'form.namePlaceholder': string;
    'form.prefix': string;
    'form.prefixPlaceholder': string;
    'form.url': string;
    'form.urlPlaceholder': string;
    'form.key': string;
    'form.keyPlaceholder': string;
    'form.submit': string;
    'form.submitting': string;
    'form.cancel': string;
    created: string;
    'error.name': string;
    'error.prefixRequired': string;
    'error.prefixFormat': string;
    'error.prefixExists': string;
    'error.fields': string;
    'error.failed': string;
    edit: string;
    save: string;
    saving: string;
    saved: string;
    delete: string;
    confirmDelete: string;
    deleted: string;
    'error.deleteFailed': string;
    'form.enabled': string;
    'form.models': string;
    'form.selectAll': string;
    'form.clearAll': string;
    loading: string;
    signedOut: string;
    unreadable: string;
    retry: string;
    'error.url': string;
    'error.limit': string;
    'error.notFound': string;
    deleting: string;
    deleteWarning: string;
    'form.keyKeep': string;
    'form.noModels': string;
    managedEditable: string;
    managedNoDelete: string;
    'error.managed': string;
};
//# sourceMappingURL=locales.d.ts.map