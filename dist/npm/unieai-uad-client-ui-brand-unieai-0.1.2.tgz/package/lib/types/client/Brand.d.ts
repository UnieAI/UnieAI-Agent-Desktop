import type { HeroBrandMarkOwnerProps } from '@unieai/uad-client-ui-conversation/client';
import type { SidebarBrandMarkOwnerProps } from '@unieai/uad-client-ui-sidebar/client';
type UnieAiBrandMarkProps = HeroBrandMarkOwnerProps & SidebarBrandMarkOwnerProps;
/**
 * Render the UnieAI mark at the size its host surface requests.
 * @param props - Host-supplied mark presentation.
 * @returns the UnieAI mark.
 */
export declare function UnieAiBrandMark({ size, className }: UnieAiBrandMarkProps): import("react").JSX.Element;
/**
 * Render the product name. The product ships no wordmark artwork, so the name
 * is set in the product typeface rather than drawn.
 * @returns the product name.
 */
export declare function UnieAiBrandName(): import("react").JSX.Element;
export {};
//# sourceMappingURL=Brand.d.ts.map