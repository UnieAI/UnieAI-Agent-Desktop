/** UnieAI occupants for the generic browser-brand slots. */
import type { ClientContext } from '@unieai/uad-client-runtime/client';
/** Required service: the UI slot registry. */
export declare const inject: string[];
/**
 * Fill every shipped brand slot as one declaration-aware registration set.
 *
 * Unlike the upstream official-brand package this registers unconditionally:
 * the build profile selects DeepSeek's occupants, and a UnieAI build removes
 * that row from the roster rather than competing with it for the same cells.
 * @param ctx - Client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map