/**
 * Spawn-only worker entrypoint over {@link runWorkerMain}. Executable logic stays in
 * `bootstrap.ts` for in-process coverage; real-worker tests cover this glue.
 * @module @unieai/uad-code-runtime-worker-thread/src/worker
 */
export {};
//# sourceMappingURL=worker.d.ts.map