/** Package-owned invariant companion for `@unieai/uad-attachment`. @module @unieai/uad-attachment/invariant */
import type { Context } from '@unieai/cordis';
/** Cordis companion plugin name. */
export declare const name = "attachment-invariant";
/** Service required before package ownership can be reserved. */
export declare const inject: string[];
/**
 * Register the package invariant companion.
 * @param ctx - Cordis context carrying the invariant service.
 * @returns the registration disposer.
 */
export declare const apply: (ctx: Context) => Promise<() => void>;
//# sourceMappingURL=invariant.d.ts.map