import type { Context } from '@unieai/cordis';
/**
 * Register Trajectory-owned inbox classification and message records.
 *
 * @param ctx - Plugin context receiving the Definitions.
 */
export declare function registerTrajectoryMessageDefinitions(ctx: Context): void;
//# sourceMappingURL=trajectory-message-definitions.d.ts.map