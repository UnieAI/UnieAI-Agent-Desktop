import type { Context } from '@unieai/cordis';
/**
 * Register Trajectory compaction requests and session boundaries.
 *
 * @param ctx - Plugin context receiving the Definitions.
 */
export declare function registerTrajectoryCompactionDefinitions(ctx: Context): void;
//# sourceMappingURL=trajectory-compaction-definition.d.ts.map