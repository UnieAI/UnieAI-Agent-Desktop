import type { Context } from '@unieai/cordis';
/**
 * Register Trajectory request-header facts.
 *
 * @param ctx - Plugin context receiving the Definition.
 */
export declare function registerTrajectoryRequestHeaderDefinition(ctx: Context): void;
//# sourceMappingURL=trajectory-request-header-definition.d.ts.map