/**
 * Model-facing Consumer of the `ctx.userQuestions` capability seam.
 * The tool pauses until a UI provider returns a human answer, then feeds that
 * answer back into the agent loop as an ordinary tool result.
 *
 * @module @unieai/uad-tool-ask-user
 */
import type { Context } from '@unieai/cordis';
import '@unieai/uad-user-questions';
export declare const name = "tool-ask-user";
export declare const inject: string[];
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map