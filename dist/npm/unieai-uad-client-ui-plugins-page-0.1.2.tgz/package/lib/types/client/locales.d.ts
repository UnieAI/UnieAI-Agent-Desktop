/**
 * Plugins page copy.
 *
 * Every key whose text the UnieAI Copilot web product already publishes is
 * copied VERBATIM from `messages/{en,zh-tw,zh-cn,ja}.json` — the source
 * namespace and key are named beside each line. The page is this product's
 * Plugins destination and the reference product has one of its own; a
 * paraphrase would make the desktop look like a different feature rather than
 * the same one.
 *
 * `Studio MCP` is a literal in every locale. It names where the servers live,
 * and the reference does the same with its own `Agent Remote MCP` heading,
 * which is untranslated in all four of its dictionaries.
 *
 * The remaining keys — the ones below the divider in each dictionary —
 * describe states the reference page cannot be in (no session, a deployment
 * older than the MCP route, a list still loading) and the shape this page
 * gives a row that the reference does not have. They are this package's own
 * words, following the wording the API Provider section already uses for the
 * same three states, because they are the same three states.
 *
 * There is no key for a tool that reported no description, and there must not
 * be one. A card whose only line read "no description available" would be this
 * package writing copy about the host's silence; the card simply stops after
 * the name (see `StudioMcpTool` in `studio-mcp-source.ts`).
 *
 * All four shipped locales carry a complete dictionary, so nothing here falls
 * back to English.
 */
/** Simplified Chinese dictionary (the key-set source of truth). */
export declare const zh: {
    nav: string;
    title: string;
    intro: string;
    back: string;
    refresh: string;
    'mcp.title': string;
    'mcp.intro': string;
    'mcp.empty': string;
    'mcp.toolsTitle': string;
    'mcp.loading': string;
    'mcp.signedOut': string;
    'mcp.unreadable': string;
    'mcp.retry': string;
    'mcp.unsupported': string;
    'mcp.unsupportedBody': string;
    'mcp.emptyBody': string;
    'mcp.readOnly': string;
    'mcp.unnamed': string;
    'mcp.originUnset': string;
    'mcp.toolsNone': string;
    'studio.name': string;
    'studio.iconAlt': string;
    'studio.description': string;
    'studio.bound': string;
    'studio.boundBody': string;
    'studio.unbound': string;
    'studio.bind': string;
    'studio.loading': string;
    'studio.signedOut': string;
    'studio.unsupported': string;
    'studio.failed': string;
    'skills.title': string;
    'skills.intro': string;
    'skills.unsupported': string;
    'manage.title': string;
    'manage.intro': string;
    'directory.loading': string;
    'directory.unsupported': string;
    'directory.signedOut': string;
    'directory.failed': string;
    'directory.retry': string;
    'directory.filterLabel': string;
    'directory.filterAll': string;
    'directory.filterInstalled': string;
    'directory.filterMore': string;
    'directory.searchPlaceholder': string;
    'directory.installedTitle': string;
    'directory.groupOther': string;
    'directory.empty': string;
    'directory.noMatch': string;
    'directory.install': string;
    'directory.remove': string;
    'directory.overflow': string;
    'directory.planNote': string;
};
/** The plugins namespace key union. */
export type PluginsPageKey = keyof typeof zh;
/** Traditional Chinese dictionary. */
export declare const zhTW: {
    nav: string;
    title: string;
    intro: string;
    back: string;
    refresh: string;
    'mcp.title': string;
    'mcp.intro': string;
    'mcp.empty': string;
    'mcp.toolsTitle': string;
    'mcp.loading': string;
    'mcp.signedOut': string;
    'mcp.unreadable': string;
    'mcp.retry': string;
    'mcp.unsupported': string;
    'mcp.unsupportedBody': string;
    'mcp.emptyBody': string;
    'mcp.readOnly': string;
    'mcp.unnamed': string;
    'mcp.originUnset': string;
    'mcp.toolsNone': string;
    'studio.name': string;
    'studio.iconAlt': string;
    'studio.description': string;
    'studio.bound': string;
    'studio.boundBody': string;
    'studio.unbound': string;
    'studio.bind': string;
    'studio.loading': string;
    'studio.signedOut': string;
    'studio.unsupported': string;
    'studio.failed': string;
    'skills.title': string;
    'skills.intro': string;
    'skills.unsupported': string;
    'manage.title': string;
    'manage.intro': string;
    'directory.loading': string;
    'directory.unsupported': string;
    'directory.signedOut': string;
    'directory.failed': string;
    'directory.retry': string;
    'directory.filterLabel': string;
    'directory.filterAll': string;
    'directory.filterInstalled': string;
    'directory.filterMore': string;
    'directory.searchPlaceholder': string;
    'directory.installedTitle': string;
    'directory.groupOther': string;
    'directory.empty': string;
    'directory.noMatch': string;
    'directory.install': string;
    'directory.remove': string;
    'directory.overflow': string;
    'directory.planNote': string;
};
/** Japanese dictionary. */
export declare const ja: {
    nav: string;
    title: string;
    intro: string;
    back: string;
    refresh: string;
    'mcp.title': string;
    'mcp.intro': string;
    'mcp.empty': string;
    'mcp.toolsTitle': string;
    'mcp.loading': string;
    'mcp.signedOut': string;
    'mcp.unreadable': string;
    'mcp.retry': string;
    'mcp.unsupported': string;
    'mcp.unsupportedBody': string;
    'mcp.emptyBody': string;
    'mcp.readOnly': string;
    'mcp.unnamed': string;
    'mcp.originUnset': string;
    'mcp.toolsNone': string;
    'studio.name': string;
    'studio.iconAlt': string;
    'studio.description': string;
    'studio.bound': string;
    'studio.boundBody': string;
    'studio.unbound': string;
    'studio.bind': string;
    'studio.loading': string;
    'studio.signedOut': string;
    'studio.unsupported': string;
    'studio.failed': string;
    'skills.title': string;
    'skills.intro': string;
    'skills.unsupported': string;
    'manage.title': string;
    'manage.intro': string;
    'directory.loading': string;
    'directory.unsupported': string;
    'directory.signedOut': string;
    'directory.failed': string;
    'directory.retry': string;
    'directory.filterLabel': string;
    'directory.filterAll': string;
    'directory.filterInstalled': string;
    'directory.filterMore': string;
    'directory.searchPlaceholder': string;
    'directory.installedTitle': string;
    'directory.groupOther': string;
    'directory.empty': string;
    'directory.noMatch': string;
    'directory.install': string;
    'directory.remove': string;
    'directory.overflow': string;
    'directory.planNote': string;
};
/** English dictionary, checked complete against the zh key set. */
export declare const en: {
    nav: string;
    title: string;
    intro: string;
    back: string;
    refresh: string;
    'mcp.title': string;
    'mcp.intro': string;
    'mcp.empty': string;
    'mcp.toolsTitle': string;
    'mcp.loading': string;
    'mcp.signedOut': string;
    'mcp.unreadable': string;
    'mcp.retry': string;
    'mcp.unsupported': string;
    'mcp.unsupportedBody': string;
    'mcp.emptyBody': string;
    'mcp.readOnly': string;
    'mcp.unnamed': string;
    'mcp.originUnset': string;
    'mcp.toolsNone': string;
    'studio.name': string;
    'studio.iconAlt': string;
    'studio.description': string;
    'studio.bound': string;
    'studio.boundBody': string;
    'studio.unbound': string;
    'studio.bind': string;
    'studio.loading': string;
    'studio.signedOut': string;
    'studio.unsupported': string;
    'studio.failed': string;
    'skills.title': string;
    'skills.intro': string;
    'skills.unsupported': string;
    'manage.title': string;
    'manage.intro': string;
    'directory.loading': string;
    'directory.unsupported': string;
    'directory.signedOut': string;
    'directory.failed': string;
    'directory.retry': string;
    'directory.filterLabel': string;
    'directory.filterAll': string;
    'directory.filterInstalled': string;
    'directory.filterMore': string;
    'directory.searchPlaceholder': string;
    'directory.installedTitle': string;
    'directory.groupOther': string;
    'directory.empty': string;
    'directory.noMatch': string;
    'directory.install': string;
    'directory.remove': string;
    'directory.overflow': string;
    'directory.planNote': string;
};
//# sourceMappingURL=locales.d.ts.map