import type { PluginsPageComponentProps } from './contract/slots.ts';
/** Identifier of one destination on the surface. */
export type PluginsViewId = 'directory' | 'skills' | 'manage';
/**
 * The surface's destinations, and which registered areas each one shows.
 *
 * `entries` names ids owned by other packages. `VIEWS` is exported so the test
 * that guards the coupling can compare it against what those packages
 * actually register.
 */
export declare const VIEWS: readonly [{
    readonly id: "directory";
    readonly title: "title";
    readonly intro: "intro";
    readonly entries: readonly ["unieai-studio", "unieai-directory"];
}, {
    readonly id: "skills";
    readonly title: "skills.title";
    readonly intro: "skills.intro";
    readonly entries: readonly ["skills"];
}, {
    readonly id: "manage";
    readonly title: "manage.title";
    readonly intro: "manage.intro";
    readonly entries: readonly ["studio-mcp", "plugin-directory", "cordis-plugins"];
}];
/** The destinations that appear as pill tabs; `manage` is reached by the gear. */
export declare const TAB_VIEWS: readonly ["directory", "skills"];
/**
 * Render the Plugins view, or nothing while it is closed.
 * @param props - composed slot props (contract in contract/slots.ts).
 * @returns the view element tree, or null.
 */
export declare function PluginsPage({ t, renderSlot, usePage, close, refresh }: PluginsPageComponentProps): import("react").JSX.Element | null;
//# sourceMappingURL=PluginsPage.d.ts.map