/**
 * Plugins plugin, browser half: the main-area surface behind the sidebar's
 * Plugins row, the row itself, and the UnieAI Studio entry, plugin directory,
 * Studio MCP and skills areas on it.
 *
 * WHERE IT SITS. `shell.overlay` is the only additive root seat the frame
 * documents, and it spans the whole app box; the surface offsets its left
 * edge by ui-layout's `--dsh-shell-sidebar-width` so the navigation column
 * stays visible and its Plugins row stays the marked one. A destination
 * reached from the sidebar has to leave the sidebar standing.
 *
 * WHY A PAGE. The word "plugin" meant two different things in this product.
 * The reference web product's Plugins page is where an account's MCP servers
 * and bundles live — a destination people go to. This desktop's Plugins was
 * the cordis registry behind a settings section: real, useful, and
 * developer-facing. The sidebar row promised the first and opened the second.
 * Both are areas on this page now, and neither owns the word alone.
 *
 * WHAT THIS PACKAGE OWNS. The page chrome, its open state, the nav row that
 * opens it, and the `plugins.page.area` hole. The cordis registry is still
 * `ui-settings-plugins`' — that package registers the same section component
 * into the hole below, with its tabs and its cards untouched; nothing was
 * copied out of it. The read-only plugin directory between them is
 * `ui-settings-plugin-inventory`', registered the same way.
 *
 * THE OLD ROW DISAPPEARS BY ITSELF. `ui-settings-general` draws a Plugins nav
 * row that opens the settings panel, and hides it whenever no `plugins`
 * settings section is registered. Moving the cordis section onto this page is
 * exactly that condition, so the two rows never appear together and the
 * settings shell needed no edit.
 *
 * Export discipline: packages/client/AGENTS.md.
 */
import type { ClientContext } from '@unieai/uad-client-runtime/client';
export type { PluginsNavRowComponentProps, PluginsNavRowInjected, PluginsPageAreaOwnerProps, PluginsPageComponentProps, PluginsPageInjected, } from './contract/slots.ts';
export type { SkillsAreaComponentProps, SkillsAreaInjected } from './SkillsArea.tsx';
export type { StudioMcpAreaComponentProps, StudioMcpAreaInjected } from './StudioMcpArea.tsx';
export type { StudioEntryComponentProps, StudioEntryInjected } from './StudioEntry.tsx';
export type { StudioBinding } from './studio-entry.ts';
export { STUDIO_BINDING_URL, STUDIO_ICON, STUDIO_MCP_SERVER_ID, readStudioBinding, } from './studio-entry.ts';
export type { PluginsPageState } from './page-store.ts';
export type { PluginsViewId } from './PluginsPage.tsx';
export { PluginsPageController } from './page-store.ts';
export type { StudioMcpEnvironment, StudioMcpRow, StudioMcpState, StudioMcpTool, } from './studio-mcp-source.ts';
export { StudioMcpSource } from './studio-mcp-source.ts';
export type { DirectoryAreaComponentProps, DirectoryAreaInjected } from './DirectoryArea.tsx';
export type { DirectoryFailure, DirectoryOutcome, DirectoryRow, DirectoryState, } from './directory-source.ts';
export { DirectorySource } from './directory-source.ts';
export type { PluginsPageKey } from './locales.ts';
/**
 * Required services (cordis fiber inject). The target slots are declared by
 * other packages' applies, whose activation order relative to this one is NOT
 * constrained; registrations depend on their slots through `slots.inject()`.
 */
export declare const inject: string[];
/**
 * Register the page, the sidebar row that opens it, the Studio MCP area, and
 * the dictionaries all three read.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map