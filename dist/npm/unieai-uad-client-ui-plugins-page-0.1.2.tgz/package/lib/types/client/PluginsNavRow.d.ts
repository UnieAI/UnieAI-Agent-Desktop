import type { PluginsNavRowComponentProps } from './contract/slots.ts';
/**
 * Render the Plugins nav row.
 * @param props - composed slot props (contract in contract/slots.ts).
 * @returns the row button.
 */
export declare function PluginsNavRow({ wide, t, usePage, toggle }: PluginsNavRowComponentProps): import("react").JSX.Element;
//# sourceMappingURL=PluginsNavRow.d.ts.map