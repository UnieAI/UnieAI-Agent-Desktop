import type { InjectFace, PropsLocale, PropsRuntime } from '@unieai/uad-client-ui-slots';
import type { StudioMcpSource } from './studio-mcp-source.ts';
/** Injected business face of the Studio entry (slot `inject`). */
export interface StudioEntryInjected {
    hooks: {
        /**
         * The same server list `StudioMcpArea` binds, bound here as useServers.
         * One source, so the entry and the area can never disagree about whether
         * the account holds a Studio link.
         */
        servers: StudioMcpSource;
    };
    /** Re-read the list from the host. */
    refresh: () => void;
}
/** Full component props: runtime share + locale seat + injected face. */
export type StudioEntryComponentProps = PropsRuntime<'plugins.page.area'> & PropsLocale<'plugins'> & InjectFace<StudioEntryInjected>;
/**
 * Render the Studio entry.
 * @param props - see {@link StudioEntryComponentProps}.
 * @returns the entry element tree.
 */
export declare function StudioEntry({ t, useServers, refresh }: StudioEntryComponentProps): import("react").JSX.Element;
//# sourceMappingURL=StudioEntry.d.ts.map