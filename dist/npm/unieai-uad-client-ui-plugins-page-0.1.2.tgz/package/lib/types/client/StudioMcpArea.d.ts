import type { InjectFace, PropsLocale, PropsRuntime } from '@unieai/uad-client-ui-slots';
import type { StudioMcpSource } from './studio-mcp-source.ts';
/** Injected business face of the Studio MCP area (slot `inject`). */
export interface StudioMcpAreaInjected {
    hooks: {
        /** Server list state, bound by the UI renderer as useServers. */
        servers: StudioMcpSource;
    };
    /** Re-read the list from the host. */
    refresh: () => void;
}
/** Full component props: runtime share + locale seat + injected face. */
export type StudioMcpAreaComponentProps = PropsRuntime<'plugins.page.area'> & PropsLocale<'plugins'> & InjectFace<StudioMcpAreaInjected>;
/**
 * Render the Studio MCP area.
 * @param props - composed slot props.
 * @returns the area element tree.
 */
export declare function StudioMcpArea({ t, useServers, refresh }: StudioMcpAreaComponentProps): import("react").JSX.Element;
//# sourceMappingURL=StudioMcpArea.d.ts.map