/**
 * The plugin directory this page renders, read and written through the
 * sign-in gate's `/auth/plugins` routes.
 *
 * The catalogue is the web product's, not this build's. That is the whole
 * point of reading it over the wire rather than shipping a list: a plugin
 * added to the product appears here on the next read, with no desktop release
 * involved. This object holds no copy — it mirrors what the host last
 * reported and re-reads after every write, so a row shown here and a row shown
 * on the product's own Plugins page are the same row.
 *
 * It is deliberately separate from the cordis registry the Loader reports.
 * Those are this build's own modules — `include`, `typert-registry` — and a
 * reader cannot install, remove or choose them. Putting both in one list was
 * the mistake this source exists to undo: one of them is a product catalogue
 * and the other is a deployment's parts bill, and only the first is a
 * directory.
 *
 * `unsupported` is a first-class answer, not an error. A deployment whose
 * product predates the route serves a 404 and will keep serving one however
 * many times it is asked, so the page must say "this build cannot show you a
 * directory" rather than offer a Retry that cannot work. That distinction is
 * the same one {@link StudioMcpSource} draws, for the same reason.
 */
/** One plugin as the directory shows it. */
export interface DirectoryRow {
    /** The product's marketplace identifier; the identity it has on both sides. */
    slug: string;
    /** Display name. */
    name: string;
    /** One line, already localised by the product to the reader's locale. */
    description: string;
    /**
     * The manifest's own grouping key, or empty when it declares none.
     *
     * Empty is carried rather than replaced with a bucket name: which heading an
     * ungrouped plugin files under is this page's presentation decision, and a
     * source that pre-decided it would make an ungrouped plugin indistinguishable
     * from one the product really did file under "other".
     */
    category: string;
    /** Who publishes it; empty when the manifest names nobody. */
    author: string;
    /** Absolute URL of the publisher's mark, or null when none is stored. */
    iconUrl: string | null;
    /** How many skills the plugin bundles; 0 is a real answer. */
    skillCount: number;
    /** Example prompts the publisher suggests. Empty when it suggests none. */
    tryAsking: readonly string[];
    /** Whether this account has it installed. */
    installed: boolean;
    /** Whether an installed plugin is active. False when not installed. */
    enabled: boolean;
}
/** What the page knows about the directory right now. */
export type DirectoryState = 
/** The first read has not settled yet. */
{
    status: 'loading';
}
/** This deployment's product serves no directory route at all. */
 | {
    status: 'unsupported';
}
/** The host holds no session, so there is no account to read a directory for. */
 | {
    status: 'signed-out';
}
/** A session exists and the catalogue could not be read. */
 | {
    status: 'failed';
}
/**
 * The catalogue as the product last reported it; empty is a real answer.
 *
 * `canInstall` is the account's plan verdict, reported separately from the
 * rows because it is a property of the reader, not of any plugin: a free
 * account sees the whole catalogue and may install none of it.
 */
 | {
    status: 'ready';
    plugins: readonly DirectoryRow[];
    canInstall: boolean;
};
/** What one install or removal established. */
export type DirectoryOutcome = {
    ok: true;
}
/** `reason` is a dictionary key, chosen from the product's own identifier. */
 | {
    ok: false;
    reason: DirectoryFailure;
};
/** The refusal lines this page can show. */
export type DirectoryFailure = 'error.plan' | 'error.policy' | 'error.notFound' | 'error.failed';
/**
 * The browser facilities this source uses, named so a test can drive them.
 * Production values come from the plugin body; the paths are not configurable,
 * because they belong to the gate's own route table.
 */
export interface DirectoryEnvironment {
    /**
     * Issue one same-origin request to the host gate.
     * @param path - an absolute path on this origin.
     * @param init - request options.
     * @returns the response.
     */
    request: (path: string, init?: RequestInit) => Promise<Response>;
}
/**
 * Read the catalogue envelope.
 * @param body - the parsed response body.
 * @returns the ready state, or undefined when the body is not one.
 */
export declare function readDirectoryResponse(body: unknown): DirectoryState | undefined;
/**
 * The catalogue, as this page reads and writes it.
 *
 * The object caches its state so repeated reads keep one reference between
 * changes — the uSES contract the render machinery relies on.
 */
export declare class DirectorySource {
    private readonly environment;
    private state;
    private readonly listeners;
    private disposed;
    /**
     * @param environment - the browser facilities to read through.
     */
    constructor(environment: DirectoryEnvironment);
    /**
     * The last published reading.
     *
     * Named for the uSES contract the render machinery binds against
     * (`HostObservable`), which is also why the value is cached rather than
     * rebuilt: a snapshot that returned a fresh object each call would re-render
     * on every check.
     * @returns the current state.
     */
    getSnapshot(): DirectoryState;
    /**
     * Subscribe to state changes.
     * @param listener - called after each change.
     * @returns the unsubscribe function.
     */
    subscribe(listener: () => void): () => void;
    /**
     * Read `/auth/plugins` once and publish what it says.
     *
     * The status line decides the three answers that carry no catalogue. A 404
     * is `unsupported` rather than `failed`, because a product older than the
     * route will not start serving it on a retry — that is the state this build
     * stands in until the web product ships its side. A 401 is `signed-out`.
     * Everything else that is not `ok` is `failed`, the one a retry can fix.
     * @returns a promise settling when the reading has been published.
     */
    refresh(): Promise<void>;
    /**
     * Install one plugin for this account, then re-read.
     *
     * The re-read is what moves the row's control, rather than a local flip: the
     * product decides what "installed" means — which version was bound, whether
     * a policy downgraded the request — and a page that assumed success would
     * show a tick the account does not actually have.
     * @param slug - the plugin to install.
     * @returns what the attempt established.
     */
    install(slug: string): Promise<DirectoryOutcome>;
    /**
     * Remove one plugin from this account, then re-read.
     * @param slug - the plugin to remove.
     * @returns what the attempt established.
     */
    remove(slug: string): Promise<DirectoryOutcome>;
    /**
     * Send one write and re-read the catalogue behind it.
     * @param method - the verb the gate route distinguishes on.
     * @param slug - the plugin to act on.
     * @returns what the attempt established.
     */
    private write;
    /** Stop publishing; a read still in flight lands on a closed source. */
    dispose(): void;
    /**
     * Adopt a state and publish it, if it moved anything.
     * @param next - the state to stand on.
     */
    private adopt;
}
//# sourceMappingURL=directory-source.d.ts.map