import type { InjectFace, PropsLocale, PropsRuntime } from '@unieai/uad-client-ui-slots';
import type { DirectorySource } from './directory-source.ts';
/** Injected business face of the directory area (slot `inject`). */
export interface DirectoryAreaInjected {
    hooks: {
        /** Catalogue state, bound by the UI renderer as useDirectory. */
        directory: DirectorySource;
    };
    /** Re-read the catalogue from the host. */
    refresh: () => void;
    /** Install one plugin; settles once the catalogue behind it has been re-read. */
    install: (slug: string) => Promise<void>;
    /** Remove one plugin from this account. */
    remove: (slug: string) => Promise<void>;
}
/** Full component props: runtime share + locale seat + injected face. */
export type DirectoryAreaComponentProps = PropsRuntime<'plugins.page.area'> & PropsLocale<'plugins'> & InjectFace<DirectoryAreaInjected>;
/**
 * Render the directory.
 * @param props - see {@link DirectoryAreaComponentProps}.
 * @returns the area element tree.
 */
export declare function DirectoryArea({ t, useDirectory, refresh, install, remove }: DirectoryAreaComponentProps): import("react").JSX.Element;
//# sourceMappingURL=DirectoryArea.d.ts.map