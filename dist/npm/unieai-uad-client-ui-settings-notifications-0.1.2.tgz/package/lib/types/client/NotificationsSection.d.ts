import type { HostObservable, InjectFace, PropsLocale, PropsRuntime } from '@unieai/uad-client-ui-slots';
import type { NotificationsSettingsState } from './notifications-controller.ts';
import type { NotifySound } from './notify-sounds.ts';
/** Registration-side business face for the section. */
export interface NotificationsSectionInjected {
    hooks: {
        /** Permission state plus the selected cue. */
        notifications: HostObservable<NotificationsSettingsState>;
    };
    /** The selectable cues, in picker order. */
    sounds: readonly NotifySound[];
    /** Ask the browser for notification permission (user gesture only). */
    enable: () => void;
    /**
     * Select a cue and preview it.
     * @param id - catalog id.
     */
    chooseSound: (id: string) => void;
}
/** Props the renderer binds for the section. */
export type NotificationsSectionProps = PropsRuntime<'settings.section'> & PropsLocale<'settings.notifications'> & InjectFace<NotificationsSectionInjected>;
/**
 * Render the Notifications page.
 * @param props - composed slot props.
 * @returns the section element tree.
 */
export declare function NotificationsSection({ t, useNotifications, sounds, enable, chooseSound, }: NotificationsSectionProps): import("react").JSX.Element;
//# sourceMappingURL=NotificationsSection.d.ts.map