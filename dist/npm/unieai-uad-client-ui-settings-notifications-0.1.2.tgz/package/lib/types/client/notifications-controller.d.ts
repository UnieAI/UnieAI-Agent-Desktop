/**
 * The section's state and the completion announcement, in one owner.
 *
 * Both blocks of the section are per-device facts the host never sees: what
 * the browser will do with a notification request, and which cue this machine
 * plays. The same object receives completions from the watcher, so the
 * settings the user is looking at and the behavior they describe cannot drift.
 */
import type { SessionId } from '@unieai/uad-api-remotes/client';
import type { SessionCompletion } from './completion-watcher.ts';
import type { NotificationAccess, NotificationPort } from './notification-port.ts';
import { type NotifySoundPlayer, type NotifySoundStorage } from './notify-sounds.ts';
/** What the section renders. */
export interface NotificationsSettingsState {
    /** Current browser permission state for this origin. */
    readonly access: NotificationAccess;
    /** The cue selected on this device. */
    readonly soundId: string;
    /** Whether a permission prompt is open (the Enable button is disabled meanwhile). */
    readonly requesting: boolean;
}
/** Copy the completion announcement needs, read at announce time so a locale switch lands. */
export interface CompletionCopy {
    /**
     * Notification title line.
     * @returns the localized "Task complete" heading.
     */
    heading(): string;
    /**
     * Body line for one finished session.
     * @param title - the session's display title.
     * @returns the localized body.
     */
    body(title: string): string;
}
/** Collaborators the controller drives. */
export interface NotificationsControllerOptions {
    /** The browser notification capability. */
    readonly port: NotificationPort;
    /** Cue playback. */
    readonly player: NotifySoundPlayer;
    /** Per-device preference cell; absent means the choice lives for this page only. */
    readonly storage: NotifySoundStorage | undefined;
    /** Announcement copy. */
    readonly copy: CompletionCopy;
    /**
     * Bring the finished session on screen — invoked when the user activates the
     * notification, which is the only reason to raise one.
     * @param sessionId - the session that finished.
     */
    readonly openSession: (sessionId: SessionId) => void;
    /** Raise the app's own window; the notification click focuses the page first. */
    readonly focusWindow: () => void;
}
/** Section state owner and the announcement sink the watcher feeds. */
export declare class NotificationsSettingsController {
    private readonly options;
    private readonly store;
    /** @param options - the collaborators this controller drives. */
    constructor(options: NotificationsControllerOptions);
    /**
     * Read the current section state.
     * @returns the snapshot.
     */
    getSnapshot(): NotificationsSettingsState;
    /**
     * Observe section state.
     * @param listener - change callback.
     * @returns the unsubscribe function.
     */
    subscribe(listener: () => void): () => void;
    /**
     * Ask the browser for notification permission.
     *
     * MUST be reached from the Enable button's click and nothing else: a prompt
     * raised without a user gesture is refused, and Chrome counts the refusal
     * against the origin permanently.
     * @returns completion once the user has answered.
     */
    enable(): Promise<void>;
    /**
     * Select a cue and preview it. Selecting is what plays it — the picker has no
     * separate preview control, so the click both stores and demonstrates the choice.
     * @param id - catalog id; an unknown id is ignored.
     */
    chooseSound(id: string): void;
    /**
     * Announce one finished turn.
     *
     * A completion the user watched happen needs no announcement, so an attended
     * one is dropped. Everything else plays the cue, and additionally raises a
     * desktop notification once permission has been granted — the cue is the part
     * that works without asking the browser for anything.
     * @param completion - the observed completion.
     */
    announce(completion: SessionCompletion): void;
    /**
     * Re-read the browser permission value.
     *
     * A permission revoked in site settings does not notify the page, so the
     * section refreshes whenever it comes back on screen.
     */
    refreshAccess(): void;
}
//# sourceMappingURL=notifications-controller.d.ts.map