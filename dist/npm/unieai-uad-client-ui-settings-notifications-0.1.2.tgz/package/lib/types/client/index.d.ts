import type { ClientContext } from '@unieai/uad-client-runtime/client';
import { type NotificationsLocaleKey } from './locales.ts';
export type { NotificationsSectionInjected, NotificationsSectionProps } from './NotificationsSection.tsx';
export type { CompletionWatcherEnvironment, SessionCompletion, SessionCompletionList, SessionCompletionRow, } from './completion-watcher.ts';
export type { CompletionCopy, NotificationsControllerOptions, NotificationsSettingsState, } from './notifications-controller.ts';
export type { NotificationAccess, NotificationPort, NotificationRequest, } from './notification-port.ts';
export type { NotifySound, NotifySoundPlayer, NotifySoundStorage } from './notify-sounds.ts';
export type { NotificationsLocaleKey } from './locales.ts';
declare module '@unieai/uad-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** Notifications settings page copy. */
        'settings.notifications': NotificationsLocaleKey;
    }
}
/** Dictionary namespace owned by this plugin. */
export declare const NS = "settings.notifications";
/**
 * Required services (cordis fiber inject). `settings.section` is declared by
 * the settings shell, whose activation order relative to this one is NOT
 * constrained; the registration waits on the declaration through
 * `slots.inject()`.
 */
export declare const inject: string[];
/**
 * Register the Notifications section and start watching for finished turns.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map