/**
 * "A task finished" as this app can actually observe it.
 *
 * There is no server-side job queue here: a turn runs in the local host and
 * the client already carries its state, because the sessions list publishes a
 * `running` bit per session and the sidebar reads it. A completion is therefore
 * the running→idle edge of one row, and everything this section announces is
 * derived from that edge — no new wire traffic, no host-side subscription.
 */
import type { SessionId } from '@unieai/uad-api-remotes/client';
import type { ObservableSnapshot } from '@unieai/uad-client-runtime/client';
/** The list-row facts a completion is derived from. */
export interface SessionCompletionRow {
    /** Whether the session's agent is mid-turn. */
    readonly running: boolean;
    /** Human-facing label already resolved by the sessions service. */
    readonly displayTitle: string;
}
/** The sessions-list snapshot shape this watcher reads (SessionListState satisfies it). */
export interface SessionCompletionList {
    /** Host-list order. */
    readonly ids: readonly SessionId[];
    /** Row map keyed by session id. */
    readonly byId: Readonly<Record<SessionId, SessionCompletionRow>>;
    /** The session the user currently has open, if any. */
    readonly current: SessionId | undefined;
}
/** One observed turn completion. */
export interface SessionCompletion {
    /** The session whose turn ended. */
    readonly sessionId: SessionId;
    /** That session's display title at the moment it finished. */
    readonly title: string;
    /**
     * Whether the user was already looking at this finish: the window is visible
     * AND this is the session on screen. An attended completion is announced by
     * the screen itself, so the section stays quiet for it.
     */
    readonly attended: boolean;
}
/**
 * Shortest run that counts as a task. Opening a session briefly marks it
 * running before the host's first status frame settles it back, and a
 * reconnect replays the same flicker; both are far below any real turn.
 */
export declare const MIN_RUN_MS = 2000;
/** Ambient facts the watcher needs but must not read directly (suites supply their own). */
export interface CompletionWatcherEnvironment {
    /**
     * Whether the app's window is currently on screen.
     * @returns true when the document is visible.
     */
    visible(): boolean;
    /**
     * Current time.
     * @returns milliseconds since the epoch.
     */
    now(): number;
}
/**
 * The browser's own environment.
 * @returns visibility from `document`, time from `Date`; a runtime without a
 * document (node e2e boot) counts as not visible, which is the safe side —
 * it announces rather than suppresses.
 */
export declare function browserCompletionEnvironment(): CompletionWatcherEnvironment;
/**
 * Watch a sessions list and report each turn completion once.
 *
 * The first snapshot only records running bits: sessions already idle at load
 * never finished while anyone was watching, and one already running has no
 * known start, so neither is announced.
 */
export declare class SessionCompletionWatcher {
    private readonly list;
    private readonly environment;
    private readonly announce;
    private readonly minRunMs;
    /** Last observed running bit per session; the true→false edge is the event. */
    private readonly running;
    /** When each currently running session was first seen running. */
    private readonly startedAt;
    /**
     * @param list - the sessions list snapshot source.
     * @param environment - visibility and clock.
     * @param announce - receives every completion the watcher accepts.
     * @param minRunMs - shortest run that counts (see {@link MIN_RUN_MS}).
     */
    constructor(list: ObservableSnapshot<SessionCompletionList>, environment: CompletionWatcherEnvironment, announce: (completion: SessionCompletion) => void, minRunMs?: number);
    /**
     * Subscribe to the list and begin reporting completions.
     * @returns the disposer; it also drops the retained per-session bits.
     */
    start(): () => void;
    /** Reconcile one snapshot against the retained bits and emit what changed. */
    private observe;
}
//# sourceMappingURL=completion-watcher.d.ts.map