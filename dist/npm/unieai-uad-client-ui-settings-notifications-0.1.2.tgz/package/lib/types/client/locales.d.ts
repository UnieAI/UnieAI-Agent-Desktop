/**
 * Notifications section copy.
 *
 * Wording is the UnieAI Copilot web product's, taken from its `AgentNext` and
 * `SettingsPage` message catalogs in all four shipped locales, so the desktop
 * app reads as the same product. Two deliberate departures, because the
 * desktop cannot do what the web product's strings promise:
 *
 * - `desktop.title` replaces the web product's "Push notifications" wording.
 *   There is no Web Push here (no service worker, no VAPID sender); what this
 *   section enables is the browser's own Notification permission.
 * - `desktop.desc` drops the web product's "or closed" clause for the same
 *   reason: nothing can notify you once this page is gone.
 *
 * The button and status lines come from the web product's push toggle, which
 * ships English only; the other three locales are adapted from the sentences
 * above rather than invented wholesale.
 */
/** Simplified Chinese dictionary and key source of truth. */
export declare const zh: {
    nav: string;
    title: string;
    'desktop.title': string;
    'desktop.desc': string;
    'desktop.enable': string;
    'desktop.enabled': string;
    'desktop.blocked': string;
    'desktop.unsupported': string;
    'sound.title': string;
    'sound.desc': string;
    'sound.pick': string;
    'complete.heading': string;
    'complete.body': string;
    'complete.untitled': string;
};
/** Notifications section locale key union. */
export type NotificationsLocaleKey = keyof typeof zh;
/** Traditional Chinese dictionary. */
export declare const zhTW: {
    nav: string;
    title: string;
    'desktop.title': string;
    'desktop.desc': string;
    'desktop.enable': string;
    'desktop.enabled': string;
    'desktop.blocked': string;
    'desktop.unsupported': string;
    'sound.title': string;
    'sound.desc': string;
    'sound.pick': string;
    'complete.heading': string;
    'complete.body': string;
    'complete.untitled': string;
};
/** Japanese dictionary. */
export declare const ja: {
    nav: string;
    title: string;
    'desktop.title': string;
    'desktop.desc': string;
    'desktop.enable': string;
    'desktop.enabled': string;
    'desktop.blocked': string;
    'desktop.unsupported': string;
    'sound.title': string;
    'sound.desc': string;
    'sound.pick': string;
    'complete.heading': string;
    'complete.body': string;
    'complete.untitled': string;
};
/** English dictionary checked against the Chinese key set. */
export declare const en: {
    nav: string;
    title: string;
    'desktop.title': string;
    'desktop.desc': string;
    'desktop.enable': string;
    'desktop.enabled': string;
    'desktop.blocked': string;
    'desktop.unsupported': string;
    'sound.title': string;
    'sound.desc': string;
    'sound.pick': string;
    'complete.heading': string;
    'complete.body': string;
    'complete.untitled': string;
};
//# sourceMappingURL=locales.d.ts.map