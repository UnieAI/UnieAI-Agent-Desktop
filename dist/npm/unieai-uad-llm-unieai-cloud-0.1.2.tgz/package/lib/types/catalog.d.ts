/**
 * Translation of the UnieAI account's entitled models into one pi-ai provider
 * route.
 *
 * The product publishes what an account may run, not how to run it: an entry
 * carries an identity (`${prefix}-${modelId}`), a label, and whether it takes
 * images, and deliberately carries neither an endpoint nor a credential. What
 * makes those entries runnable is the product's own relay — one
 * OpenAI-compatible endpoint that resolves the upstream server-side, meters the
 * turn against the plan, and streams back — so every entitled model becomes a
 * model on ONE route pointed at that endpoint, named by the value the relay
 * expects.
 *
 * Capacities are the one thing neither side knows. The product does not report
 * a context window or an output cap, and there is nothing to interrogate: the
 * relay is a facade over whichever provider the account is entitled to. So the
 * route carries deployment-set defaults rather than a guess buried here.
 *
 * @module dsh-llm-unieai-cloud/catalog
 */
import type { ResolvedPiAiProviderProfile } from '@unieai/uad-llm-pi-ai';
import type { EntitledModel } from '@unieai/uad-unieai-web-gate';
/** What the route needs beyond the models themselves. */
export interface RouteFacts {
    /** The `llm` route key this plugin owns. */
    provider: string;
    /** Name shown by model selectors. */
    displayName: string;
    /** The web product's origin, without a trailing slash. */
    productUrl: string;
    /** Context capacity assumed for every entitled model. */
    defaultContextWindow: number;
    /** Output capability assumed for every entitled model. */
    defaultMaxTokens: number;
}
/**
 * The absolute endpoint this route sends completions to.
 * @param productUrl - the web product's origin, without a trailing slash.
 * @returns the relay's base URL, which pi-ai appends `/chat/completions` to.
 */
export declare const relayBaseUrl: (productUrl: string) => string;
/**
 * Build the route profile for one entitled-model list.
 *
 * An empty list yields no profile at all: a pi-ai route with no models cannot
 * be resolved, and a route that advertises nothing is not a route worth
 * registering. The caller keeps the previous profile in that case rather than
 * dropping a route a person may be mid-turn on.
 * @param models - the account's entitled models.
 * @param facts - the route key, display name, endpoint, and capacity defaults.
 * @returns the resolved profiles keyed by route, or undefined for an empty list.
 */
export declare function buildRouteProfiles(models: readonly EntitledModel[], facts: RouteFacts): ReadonlyMap<string, ResolvedPiAiProviderProfile> | undefined;
//# sourceMappingURL=catalog.d.ts.map