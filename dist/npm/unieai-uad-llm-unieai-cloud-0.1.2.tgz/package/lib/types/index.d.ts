/**
 * @unieai/uad-llm-unieai-cloud — the UnieAI account's models, made
 * runnable.
 *
 * The web product knows which models an account may run and refuses to send a
 * desktop the credential that would run one — a key on a laptop spends the
 * account's allowance with nothing on the product able to count it. What it
 * publishes instead is a relay: `POST {product}/api/desktop/v1/chat/completions`,
 * authenticated by the desktop API key, which resolves the upstream
 * server-side, enforces the plan's quota, meters the turn, and streams back.
 *
 * This plugin is the desktop half of that arrangement. It registers ONE `llm`
 * route pointed at the relay, whose models are the account's entitled models
 * and whose credential is the gate session's API key. Nothing about the route
 * comes from a composition file: both halves are facts about who is signed in.
 *
 * ```yaml
 * - id: llm-unieai-cloud
 *   name: '@unieai/uad-llm-unieai-cloud'
 * ```
 *
 * **Signed out, the route offers nothing.** `credentialReady` answers `false`
 * whenever the gate holds no session, which is the seam
 * `buildModelCatalog` drops a whole route on — so a signed-out desktop shows no
 * cloud models rather than a menu of names that fail the moment they are
 * chosen. Before the first sign-in the route is not registered at all, because
 * there is no catalog to register it with.
 *
 * The adapter itself is `dsh-llm-pi-ai`'s. Only the two things a settings
 * document would normally supply — the catalog and the credential — are
 * answered from the sign-in gate instead.
 *
 * @module @unieai/uad-llm-unieai-cloud
 */
import { Context } from '@unieai/cordis';
import z from '@unieai/schemastery';
export { buildRouteProfiles, relayBaseUrl } from './catalog.ts';
export type { RouteFacts } from './catalog.ts';
/** Plugin name for the Loader. */
export declare const name = "llm-unieai-cloud";
/** Required services: the LLM registry, and the gate that holds the account. */
export declare const inject: string[];
/** Deployment configuration. */
export interface Config {
    /**
     * The `llm` route key this plugin owns. Configurable only because a route
     * key is global across adapter families: a deployment that already runs a
     * route called `unieai` needs somewhere to move this one.
     */
    provider: string;
    /** Name shown by model selectors for the whole route. */
    displayName: string;
    /**
     * Context capacity assumed for every entitled model. A guess by
     * construction: the product reports no capacity, and the relay is a facade
     * over whichever upstream the account is entitled to, so there is nothing to
     * interrogate. A deployment whose plan serves smaller models corrects it.
     */
    defaultContextWindow: number;
    /** Output capability assumed for every entitled model; a guess on the same terms. */
    defaultMaxTokens: number;
    /**
     * How often the entitled-model list is re-read while signed in.
     *
     * Entitlement changes on the product — a provider added from this desktop's
     * own API Providers section changes it — and the product sends no signal
     * when it does, so the list is re-read on a clock. It is not a credential
     * refresh: the session's API key lives as long as the session.
     */
    catalogRefreshMs: number;
}
/** Schema for {@link Config}. */
export declare const Config: z<Config>;
/**
 * Register the account's cloud models as one runnable route.
 * @param ctx - Cordis context carrying `llm` and `unieaiGate`.
 * @param config - resolved plugin config.
 */
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map