import type { PropsRenderSlots, PropsRuntime, PropsStore } from '@unieai/uad-client-ui-slots';
import type { createLayoutStore } from './stores.ts';
/**
 * Custom property carrying the frame's rendered sidebar column width.
 *
 * `shell.overlay` spans the whole frame box, so an occupant that must leave
 * the navigation column uncovered has no other way to learn the column's
 * current width: drag, collapse, and the narrow-viewport auto-collapse all
 * move it, and the store's preference is not the rendered value once the
 * concession chain clamps it. Published on the frame element, so every
 * descendant inherits it.
 */
export declare const SIDEBAR_WIDTH_PROPERTY = "--dsh-shell-sidebar-width";
/** Full composed props: runtime share + child-slot render share + store share. */
export type AppFrameProps = PropsRuntime<'root'> & PropsRenderSlots<'sidebar' | 'conversation' | 'details' | 'shell.overlay'> & PropsStore<ReturnType<typeof createLayoutStore>>;
/** The three-column frame (see module doc). */
export declare function AppFrame({ useStore, useSessions, actions, renderSlot, }: AppFrameProps): import("react").JSX.Element;
//# sourceMappingURL=AppFrame.d.ts.map