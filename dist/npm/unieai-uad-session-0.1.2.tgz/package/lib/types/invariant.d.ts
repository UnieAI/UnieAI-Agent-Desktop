/**
 * Package-owned relational invariants for the session event log. Load this
 * companion beside `@unieai/uad-invariants` to enable the checks.
 *
 * @module @unieai/uad-session/invariant
 */
import type { Context } from '@unieai/cordis';
/** Cordis companion plugin name. */
export declare const name = "session-invariant";
/** Service required before the companion can reserve package ownership. */
export declare const inject: string[];
/**
 * Register the session invariant companion.
 * @param ctx - Cordis context carrying the invariant service.
 * @returns the installed registration's disposer after setup succeeds.
 */
export declare const apply: (ctx: Context) => Promise<() => void>;
//# sourceMappingURL=invariant.d.ts.map