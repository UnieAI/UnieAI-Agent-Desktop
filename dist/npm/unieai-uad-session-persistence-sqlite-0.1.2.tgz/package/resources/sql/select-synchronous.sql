PRAGMA synchronous;
