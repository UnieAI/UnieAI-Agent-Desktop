/**
 * Turn one host account snapshot into the account the settings section reads.
 *
 * The mapping is total in one direction only: every field it writes comes from
 * a field the product reported. Where the product reported nothing, the
 * account carries nothing — no zeroed meter, no invented reset time, no
 * invite list, no activity figure — so an unknown figure keeps rendering as
 * unknown instead of as a fact.
 *
 * This is also where the five activity figures become readings. The account
 * contract makes the supplier format them because the five differ in unit, and
 * this package is that supplier: a count is grouped, a duration takes the
 * product's own hour and minute suffixes, a streak takes its day suffix. A
 * figure the product did not report is left out of the map entirely, so the
 * strip draws that cell as unknown rather than as `0`.
 */
import type { UnieAiAccount, UnieAiAccountState } from '@unieai/uad-client-ui-unieai-account/client';
import type { LocaleId } from '@unieai/uad-client-locale/client';
import type { HostAccountResponse, HostAccountSnapshot } from './host-account.ts';
/**
 * Render a reset instant in the reader's own time zone.
 *
 * The result is deliberately numeric rather than an `Intl` rendering: the
 * account contract already avoids host `Intl` data because it differs between
 * a browser and a Node test run, and a reset time that reorders its fields
 * between the two is worse than one that reads the same everywhere.
 * @param resetAt - the ISO timestamp the product reported, or an empty string.
 * @returns `YYYY-MM-DD HH:mm` local, or undefined when no usable instant was
 * reported — the section then prints no reset line at all.
 */
export declare function formatResetTime(resetAt: string): string | undefined;
/**
 * Map the host snapshot onto the section's account.
 *
 * A meter key this build does not know is dropped rather than shown unlabelled:
 * naming an allowance is the product's job, and this package can only name the
 * ones it has words for.
 * @param snapshot - the host's reading of the product.
 * @param locale - the active locale, which selects the allowance names.
 * @returns the account the section renders.
 */
export declare function mapAccount(snapshot: HostAccountSnapshot, locale: LocaleId): UnieAiAccount;
/**
 * What one attempt to read `/auth/account` established: either an answer the
 * host gave, or the fact that it gave none this build could read.
 */
export type AccountReading = HostAccountResponse
/** The gate did not answer, or answered a body this build cannot read. */
 | {
    status: 'unreachable';
};
/**
 * Project one reading onto the state the section subscribes to.
 * @param reading - the last reading, or undefined before the first attempt
 * finishes.
 * @param locale - the active locale, which selects the failure wording.
 * @returns the account state.
 */
export declare function projectState(reading: AccountReading | undefined, locale: LocaleId): UnieAiAccountState;
//# sourceMappingURL=account-mapping.d.ts.map