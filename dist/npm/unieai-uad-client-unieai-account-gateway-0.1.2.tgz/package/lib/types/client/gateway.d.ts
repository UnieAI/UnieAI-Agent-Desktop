/**
 * The `unieaiAccount` gateway: the Provider role of the account seam, over the
 * host gate's `/auth/*` routes.
 *
 * It owns no credential. The gate's session cookie is `HttpOnly`, so this
 * object cannot read it and cannot forward it anywhere; every request it makes
 * is a same-origin request to the host, and the API key the host uses to reach
 * the product never crosses back into the page.
 *
 * Two gestures leave the single-page app on purpose. Sign-in is a device-code
 * flow the gate renders server-side at `/auth/login`, before any client bundle
 * exists, so it cannot happen inside the app; sign-out drops a cookie the app
 * cannot see, so the document has to be reloaded for the new state to hold.
 * Because sign-in leaves, there is no state between signed-out and signed-in
 * for this object to publish, and the contract carries none.
 */
import type { UnieAiAccountGateway, UnieAiAccountState, UnieAiInviteResult, UnieAiProfilePatch, UnieAiProfileSaveResult } from '@unieai/uad-client-ui-unieai-account/client';
import type { LocaleId } from '@unieai/uad-client-locale/client';
import type { UnieAiBootstrap } from '@unieai/uad-client-unieai-bootstrap/client';
/**
 * The browser facilities the gateway uses, named so a test can drive them.
 * Production values come from the plugin body; nothing here is configurable,
 * because the three paths belong to the gate's own route table.
 */
export interface AccountGatewayEnvironment {
    /**
     * Issue one same-origin request to the host gate.
     * @param path - an absolute path on this origin.
     * @param init - request options.
     * @returns the response.
     */
    request: (path: string, init?: RequestInit) => Promise<Response>;
    /**
     * Leave the app for one of the gate's own pages.
     * @param path - an absolute path on this origin.
     */
    navigate: (path: string) => void;
    /** Reload the current document. */
    reload: () => void;
}
/** Reads the signed-in account from the host gate and publishes it. */
export declare class AccountGateway implements UnieAiAccountGateway {
    private readonly environment;
    private readonly listeners;
    private reading;
    private state;
    private locale;
    private disposed;
    private bootstrap;
    private offBootstrap;
    private ownRead;
    /**
     * @param environment - the browser facilities to use.
     * @param locale - the locale active at composition time.
     */
    constructor(environment: AccountGatewayEnvironment, locale: LocaleId);
    /**
     * Read the current state.
     * @returns the standing state; the same reference until the state moves.
     */
    getSnapshot(): UnieAiAccountState;
    /**
     * Subscribe to state changes.
     * @param listener - called after every change.
     * @returns unsubscribe.
     */
    subscribe(listener: () => void): () => void;
    /** Leave for the gate's device-code page; sign-in cannot happen in the app. */
    signIn(): void;
    /**
     * Drop the gate session and reload.
     *
     * The reload happens either way: the cookie is `HttpOnly`, so the app cannot
     * confirm what the session is now, and a document served after the request
     * shows whatever the gate actually decided.
     */
    signOut(): void;
    /**
     * Take this gateway's first account from the desktop's startup answer
     * instead of reading `/auth/account` itself.
     *
     * The startup answer was gathered on the host before the interface mounted,
     * so following it is what makes the Account section arrive populated rather
     * than filling in a moment later. Only the FIRST account comes from there:
     * every refresh this object performs afterwards — a profile save, an invite,
     * a retry — reads the route directly, because the startup answer describes
     * the start of the document and not the current state of the product.
     *
     * Following twice is a no-op, so a service event that fires more than once
     * cannot stack subscriptions.
     * @param bootstrap - the startup answer to follow.
     */
    followBootstrap(bootstrap: UnieAiBootstrap): void;
    /**
     * Take whatever the standing startup answer says about the account.
     *
     * Three of the five statuses are answers in themselves: `pending` is the
     * read that has not settled, `signed-out` is a desktop with no session —
     * which is a state, not a failure, and costs no request to establish — and
     * `unavailable` means there is no startup answer to be had, so this object
     * falls back to the one read it has always done. `ready` and `partial`
     * differ only in whether the account part is among the gathered ones.
     *
     * Once this object has read the route itself, the startup answer stops
     * being consulted: a gathered account is a description of the start of the
     * document, and republishing it over a live read would undo a save.
     */
    private adoptBootstrap;
    /**
     * Read `/auth/account` once and publish what it says.
     * @returns a promise settling when the reading has been published.
     */
    refresh(): Promise<void>;
    /**
     * Store a profile change through the host, then republish the account.
     *
     * The re-read is the point of the write path: the product decides what it
     * actually stored — a trimmed name, a re-encoded photo — so the section is
     * shown the stored profile rather than the one it submitted. It happens only
     * after a `saved` verdict, because republishing after a refusal would
     * redraw the same account and read as a save that worked.
     * @param patch - the change to store.
     * @returns whether the host reported the change stored.
     */
    saveProfile(patch: UnieAiProfilePatch): Promise<UnieAiProfileSaveResult>;
    /**
     * Invite one address through the host, then republish the account.
     *
     * The re-read is what keeps the card honest: an invite that went out changes
     * the count the card shows, and the count is the product's, not this
     * object's. It happens only after a `sent` verdict — republishing after a
     * refusal would redraw the same account and read as an invite that worked.
     * @param email - the address to invite, as typed.
     * @returns what the attempt established.
     */
    sendInvite(email: string): Promise<UnieAiInviteResult>;
    /**
     * Adopt a new active locale, relabelling the standing reading.
     * @param locale - the locale now active.
     */
    setLocale(locale: LocaleId): void;
    /** Stop publishing; a read still in flight lands on a closed gateway. */
    dispose(): void;
    /**
     * Perform one read.
     * @returns what the attempt established.
     */
    private read;
    /**
     * Retain a reading and publish it, if it moved anything.
     * @param reading - the reading to stand on.
     */
    private adopt;
}
//# sourceMappingURL=gateway.d.ts.map