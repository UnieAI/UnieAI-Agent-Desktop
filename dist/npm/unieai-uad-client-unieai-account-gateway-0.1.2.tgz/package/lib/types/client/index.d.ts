/**
 * UnieAI account gateway, browser half: provides the `unieaiAccount` service
 * that `ui-unieai-account` renders, filled from the sign-in gate's
 * `/auth/account` route.
 *
 * This is the Provider role of the account seam; `ui-unieai-account` owns the
 * Service Definition and is its only Consumer. The split is real: the section
 * must render in a build that has no UnieAI gate at all, and this package must
 * be replaceable by any other supplier of the same service.
 *
 * Composition order matters here and nothing enforces it. The section reads
 * the gateway once, with `ctx.get`, while its own body runs, so a build that
 * activates this row after the section leaves the section permanently
 * unavailable. The bundle roster therefore lists this row ahead of it.
 *
 * Export discipline: packages/client/AGENTS.md.
 */
import type { ClientContext } from '@unieai/uad-client-runtime/client';
import type * as AccountContract from '@unieai/uad-client-ui-unieai-account/client';
declare module '@unieai/cordis' {
    interface Context {
        /** The account seam's Provider, when a build composes one. */
        unieaiAccount: AccountContract.UnieAiAccountGateway;
    }
}
/**
 * Required services.
 *
 * `locale` is a hard dependency because every allowance name and failure line
 * this gateway publishes is already-localized text, and the active locale
 * decides which words those are.
 *
 * `unieaiBootstrap` is a hard dependency because it is an ORDERING one, and
 * inject is the only thing in Cordis that orders activation. The startup
 * answer's supplier is still reading while its consumers' bodies run, and a
 * service is not readable with `ctx.get` until its fiber is active — so a
 * gateway that merely looked for it would find nothing, read `/auth/account`
 * itself, and leave the gathered account unused. Waiting is also what makes
 * this gateway's first published state the settled one.
 *
 * The two rows therefore ship together. Dropping the startup row from a
 * composition that keeps this one leaves this fiber pending, which the boot
 * page reports by name.
 */
export declare const inject: string[];
/**
 * Provide the account gateway and start its first read.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map