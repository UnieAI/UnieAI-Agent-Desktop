/**
 * The text this package owns, in every locale the client ships.
 *
 * The account contract says labels and failure messages arrive at the section
 * already localized, because only the supplier knows what its own figures are
 * called. This package is that supplier, so the allowance names and the two
 * failure lines are translated here rather than in the section's dictionary.
 *
 * The copy is a plain table rather than a `ctx.locale` namespace: these
 * strings are data carried inside the account snapshot, not the copy of a
 * rendered slot, and a namespace would put them behind a `t` seat that no
 * component in this package owns.
 */
import type { LocaleId } from '@unieai/uad-client-locale/client';
/**
 * The product's meter keys, in the order the usage list presents them: the
 * two agent allowances a task actually spends first, then chat, then the
 * call counters, then the session and page counts.
 */
export declare const METER_KEYS: readonly ["agentTurns", "agentTokens", "chatTokens", "mcpCalls", "toolCalls", "agentSessions", "vlmPages"];
/** One allowance key reported by the product's `/api/desktop/usage`. */
export type MeterKey = typeof METER_KEYS[number];
/**
 * Stable contract id per meter key. Written out rather than derived from the
 * key, because the id is a published identifier of the seam and must not move
 * when someone rewrites a spelling rule.
 */
export declare const METER_QUOTA_IDS: Readonly<Record<MeterKey, string>>;
/** The product's own state names for one sent invite. */
export declare const INVITE_STATES: readonly ["pending", "joined", "rewarded"];
/** One invite state this build can name. */
export type InviteState = typeof INVITE_STATES[number];
/** Everything this package puts into words. */
export interface GatewayCopy {
    /** Allowance names, by the product's meter key. */
    meters: Readonly<Record<MeterKey, string>>;
    /** The gate answered, but the product would not describe the account. */
    productUnavailable: string;
    /** The gate itself could not be reached, or answered something unreadable. */
    hostUnreachable: string;
    /**
     * Unit suffixes for the three activity figures that are not plain counts,
     * taken verbatim from the product's own `SettingsPage.profileStats` copy —
     * the same three suffixes its profile page prints, so `2h 5m` and `3d` read
     * identically on both surfaces.
     */
    units: {
        /** Hours suffix of the longest-task reading. */
        hour: string;
        /** Minutes suffix of the longest-task reading. */
        minute: string;
        /** Days suffix of both streak readings. */
        day: string;
    };
    /** Where one sent invite stands, by the product's own state name. */
    inviteStates: Readonly<Record<InviteState, string>>;
}
/** Copy for every shipped locale; the record is total, so no key falls back. */
export declare const COPY: Readonly<Record<LocaleId, GatewayCopy>>;
//# sourceMappingURL=locales.d.ts.map