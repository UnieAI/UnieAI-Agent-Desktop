/**
 * Device-code login against the UnieAI Copilot web product (copilot-v2).
 *
 * The desktop never talks to the agent runtime directly — the runtime is an
 * internal service. It talks to the web product, which proxies the RFC 8628
 * grant and, on approval, also mints the API key the desktop needs for the
 * product's own `/api/desktop/*` surface.
 */
/** What a started login shows the human, and what the poller needs. */
export interface DeviceGrant {
    /** Opaque, single-use; the desktop's only claim while the login is pending. */
    deviceCode: string;
    /** The short code the human types into the browser. */
    userCode: string;
    /** Absolute URL of the approval page. */
    verificationUrl: string;
    /** Seconds until the grant expires. */
    expiresIn: number;
    /** Seconds the client must wait between polls. */
    interval: number;
}
/**
 * The credential and identity a completed login yields.
 *
 * One credential, deliberately: an API key for the web product's
 * `/api/desktop/*` routes. This desktop is a personal application that runs
 * its own agent locally, and it asks the product only for identity, plan, and
 * model credentials. It never accepts work from it, so there is nothing here
 * that would let the product reach back into this machine.
 */
export interface DeviceSession {
    /** Bearer for the web product's `/api/desktop/*` routes. */
    apiKey: string;
    userId: string;
    displayName: string | null;
    email: string;
}
/** One poll's answer. `pending` carries the delay the server asked for. */
export type PollOutcome = {
    status: 'pending';
    retryAfterSeconds?: number;
} | {
    status: 'approved';
    session: DeviceSession;
} | {
    status: 'expired';
} | {
    status: 'denied';
} | {
    status: 'error';
    message: string;
};
/**
 * Open a login. The returned `verificationUrl` is absolute so the page can
 * link straight to it.
 * @param baseUrl - the web product's origin, without a trailing slash.
 * @param signal - cancels the request.
 * @returns the grant to show and to poll with.
 */
export declare function startDeviceLogin(baseUrl: string, signal?: AbortSignal): Promise<DeviceGrant>;
/**
 * Poll once. The caller owns the loop and obeys `interval`, so the desktop and
 * the server never disagree about the rate.
 * @param baseUrl - the web product's origin, without a trailing slash.
 * @param deviceCode - from {@link startDeviceLogin}.
 * @param signal - cancels the request.
 * @returns this poll's outcome.
 */
export declare function pollDeviceLogin(baseUrl: string, deviceCode: string, signal?: AbortSignal): Promise<PollOutcome>;
//# sourceMappingURL=device.d.ts.map