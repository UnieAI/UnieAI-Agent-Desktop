/**
 * @unieai/uad-unieai-web-gate — the browser sign-in gate.
 *
 * Two things live here because they are one decision:
 *
 *  - the `/auth/*` routes and the server-rendered sign-in page, which run
 *    before any client bundle exists; and
 *  - the WebServer guard that decides whether a request reaches dispatch.
 *
 * The guard is the fence. A gate built inside the client plugin tree could not
 * be one: `client/runtime` opens the downlinks and issues its first RPC during
 * the plugin stage, before React mounts, so anything rendered afterwards is a
 * curtain in front of a stage that is already running — and `curl` never sees
 * the curtain at all.
 *
 * Identity comes from the UnieAI Copilot web product over a device-code grant
 * ({@link ./device.ts}). Authorisation is separate and deliberate: this host
 * runs one agent with `bash` and the filesystem tools, so admitting *any* valid
 * account would hand arbitrary code execution to anyone who can register with
 * the product. The first account to sign in claims the instance; later accounts
 * are refused unless an explicit allowlist says otherwise.
 */
import { Context } from '@unieai/cordis';
import z from '@unieai/schemastery';
import { type DeviceSession } from './device.ts';
import type { McpServerGrant } from './mcp.ts';
import type { EntitledModel } from './models.ts';
export type { BootstrapAnswer, BootstrapPart, BootstrapPartReader } from './bootstrap.ts';
export type { DeviceGrant, DeviceSession, PollOutcome } from './device.ts';
export type { AccountMeter, AccountSnapshot } from './account.ts';
export type { InviteSendOutcome, SentInvite } from './invite.ts';
export type { McpServerGrant, McpServerView } from './mcp.ts';
export type { EntitledModel } from './models.ts';
export type { AccountProfile, ProfileRefusal, ProfilePatch, ProfileWriteOutcome } from './profile.ts';
export type { ProviderCreateOutcome, ProviderDeleteOutcome, ProviderDraft, ProviderPatch, ProviderSummary, ProviderUpdateOutcome, } from './providers.ts';
export type { DesktopDailyPoint, DesktopStats } from './stats.ts';
/**
 * The signed-in account, as this host holds it.
 *
 * The API key is a member because a host plugin that dials the product on the
 * account's behalf needs it as a bearer, and there is nowhere else on this
 * host that holds one. It is a HOST-side value in the strictest sense: no
 * `/auth/*` answer carries it, and nothing that reaches a page may.
 */
export interface UnieaiGateSession {
    /** The product's own account id. */
    userId: string;
    /** The desktop API key for `/api/desktop/*`. Never leaves this process. */
    apiKey: string;
}
/**
 * The gate's host-side seam: who is signed in, and what the product will tell
 * this host on their behalf.
 *
 * It exists because the gate's session table is the only place on this host
 * that holds a product credential, and two host plugins need what that
 * credential buys — the MCP supervisor mounts the servers it grants, and the
 * cloud LLM route sends turns through the product's relay with it. Both read
 * through here rather than being handed the table.
 *
 * The two read methods are the same proxied reads `/auth/mcp` and
 * `/auth/models` serve, minus the browser projection: a host consumer needs
 * the endpoint and the bearer that a page must never see.
 */
export interface UnieaiGate {
    /** The web product's origin, without a trailing slash. */
    readonly productUrl: string;
    /**
     * The account currently signed in, or undefined when none is.
     *
     * Sessions expire on idleness, and that expiry is evaluated when a session
     * is read rather than on a timer, so a caller that stops asking stops
     * observing the lapse. Callers that hold something on a session's behalf
     * therefore re-read on their own schedule instead of waiting to be told.
     * @returns the session, or undefined while signed out.
     */
    session(): UnieaiGateSession | undefined;
    /**
     * The MCP servers the account may mount, each with its short-lived bearer.
     * @param signal - cancels the request.
     * @returns the grants, undefined when the product could not be read, or
     * undefined when nobody is signed in — a host consumer distinguishes the two
     * through {@link session}.
     */
    mcpServers(signal?: AbortSignal): Promise<McpServerGrant[] | undefined>;
    /**
     * The models the account is entitled to run on the product — the same list
     * `/auth/models` serves.
     * @param signal - cancels the request.
     * @returns the models, or undefined when the list could not be read.
     */
    entitledModels(signal?: AbortSignal): Promise<EntitledModel[] | undefined>;
}
declare module '@unieai/cordis' {
    interface Context {
        unieaiGate: UnieaiGate;
    }
    interface Events {
        /**
         * The signed-in account changed: a sign-in that produced a session, or the
         * loss of the last one to a sign-out. Carries the new state, so a listener
         * that mounts something per account does not have to ask again.
         *
         * NOT emitted when a session merely lapses on idleness — expiry is lazy,
         * evaluated on read, so nothing observes the moment it happens. A listener
         * holding a resource on the account's behalf must re-read on its own
         * schedule rather than treat this event as the only signal.
         * @param session - the account now signed in, or undefined for none.
         * @mode emit
         */
        'unieai-gate/session'(session: UnieaiGateSession | undefined): void;
    }
}
/** Plugin name for the Loader. */
export declare const name = "unieai-web-gate";
/** Required service: the HTTP carrier this gate guards and serves routes on. */
export declare const inject: string[];
/** Deployment configuration. */
export interface Config {
    /** Origin of the UnieAI Copilot web product this desktop signs in against. */
    productUrl: string;
    /**
     * Whether the guard actually refuses traffic. Off by default so a
     * composition can mount the gate, exercise the sign-in flow at
     * `/auth/login`, and only then commit to it — turning a half-verified fence
     * on by default would lock an operator out of a working machine.
     */
    enforce: boolean;
    /**
     * Accounts allowed in. Empty plus `claimFirstLogin` means the first account
     * to complete a sign-in becomes the owner and the only one admitted.
     */
    allowedUserIds: string[];
    /** Whether an empty allowlist is claimed by the first successful sign-in. */
    claimFirstLogin: boolean;
    /** Idle lifetime of a browser session, in milliseconds. */
    idleTimeoutMs: number;
    /**
     * Admit requests that did not arrive through a reverse proxy.
     *
     * A proxy announces itself with `X-Forwarded-For`; a request without one
     * reached the listen socket directly, which on a desktop deployment means
     * the operator on this machine. Keeping that path open lets the fence be
     * enforced on the public host without locking the operator out of the local
     * port while sign-in is still being brought up.
     *
     * What it does NOT do: it is not a loopback check. Anything that can reach
     * the socket without adding the header is admitted, which includes other
     * containers when the port is published to a bridge. Turn it off for a
     * deployment where that set is not trusted.
     */
    allowDirectRequests: boolean;
}
/** Schema for {@link Config}. */
export declare const Config: z<Config>;
/** A signed-in browser. The cookie itself is never stored, only its digest. */
interface GateSession extends DeviceSession {
    lastSeenAt: number;
}
/**
 * Mount the gate: the `/auth` routes, and the guard when enforcement is on.
 * @param ctx - Cordis context carrying `webServer`.
 * @param config - resolved plugin config.
 */
export declare function apply(ctx: Context, config: Config): void;
/** Expose the session shape for a composition that reads it. */
export type { GateSession };
//# sourceMappingURL=index.d.ts.map