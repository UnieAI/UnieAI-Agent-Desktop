/**
 * Reads the signed-in account's personal activity from the web product's
 * desktop BFF.
 *
 * Same seam as {@link ./account.ts}, for the same reason: the API key that
 * authenticates `/api/desktop/*` lives in the gate's session table and must
 * not reach a page. The browser asks the host, the host asks the product.
 *
 * Nothing here derives a figure. What "total tokens" means, which usage counts
 * as personal, and how a streak is measured are the product's decisions
 * (`lib/desktop/stats.ts`); this module forwards the numbers and drops
 * anything it cannot read as one. A call that fails yields `undefined` rather
 * than a zeroed record — an account with no activity and a statistics read
 * that did not happen must never render the same, because zeroes are a claim
 * and an error is not one.
 */
/** One day's token total, exactly as the product reports it. */
export interface DesktopDailyPoint {
    /** `YYYY-MM-DD`, UTC. */
    date: string;
    /** Tokens attributed to that day. */
    tokens: number;
}
/** The account's personal activity: five figures and the series behind them. */
export interface DesktopStats {
    /** All-time personal tokens, organisation usage excluded. */
    totalTokens: number;
    /** Largest single-day personal total inside the product's window. */
    peakDayTokens: number;
    /** Longest single task, in whole minutes. */
    longestTaskMinutes: number;
    /** Consecutive days of usage ending today or yesterday. */
    currentStreakDays: number;
    /** Longest consecutive run inside the window. */
    longestStreakDays: number;
    /** Days with usage, ascending; a day with none is absent, not zero. */
    daily: DesktopDailyPoint[];
}
/**
 * Read the account's activity statistics.
 * @param baseUrl - the web product's origin, without a trailing slash.
 * @param apiKey - the desktop API key from the gate's session.
 * @param signal - cancels the request.
 * @returns the statistics, or undefined when they could not be read — which
 * the caller reports as a failure rather than as an account with no activity.
 */
export declare function fetchDesktopStats(baseUrl: string, apiKey: string, signal?: AbortSignal): Promise<DesktopStats | undefined>;
//# sourceMappingURL=stats.d.ts.map