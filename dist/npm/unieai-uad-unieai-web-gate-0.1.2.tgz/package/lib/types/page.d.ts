/**
 * The sign-in page, rendered by the host before any client bundle exists.
 *
 * It is deliberately a self-contained document: it is served to visitors who
 * have not been admitted, so it must not pull the application shell, the
 * plugin registry, or any `ui-theme` stylesheet — none of which an
 * unauthenticated request may reach. That is why the design values below are
 * restated inline rather than imported.
 *
 * The layout follows the shadcn/ui `LoginForm` block: a centred card holding a
 * mark, a bold title, a muted description, and a full-width primary action.
 * Its Tailwind classes are resolved to literal values here because this
 * repository ships neither Tailwind nor a component library
 * (`docs/web-styling.md`); the metrics, not the mechanism, are what carry over.
 *
 * What the block's form contains is NOT reproduced, because this product has
 * nowhere to send it. There is no email field: the desktop holds no user
 * database and authenticates only through the web product. There are no
 * per-provider buttons: choosing Google or Microsoft happens on that product's
 * own sign-in page, and two buttons here would open the same URL while
 * implying otherwise. There is no terms line: this deployment publishes no
 * terms or privacy page to link to.
 */
/**
 * Render the sign-in document.
 * @param productUrl - the web product this desktop signs in against, shown so
 * the operator can see which deployment they are about to authorise.
 * @returns a complete HTML document.
 */
export declare function renderLoginPage(productUrl: string): string;
//# sourceMappingURL=page.d.ts.map