/**
 * Reads the signed-in account's plan, usage, and referrals from the web
 * product's desktop BFF.
 *
 * This runs on the host, not in the browser, because the API key that
 * authenticates these calls lives in the gate's session table and must not
 * reach a page. The browser asks the host, the host asks the product.
 *
 * Nothing here interprets a number. The product owns what an allowance means,
 * what window it resets in, and what a plan is called; this module forwards
 * those values and drops only the fields the desktop has no use for. A call
 * that fails leaves its section absent rather than substituting a zero — a
 * missing quota and an exhausted one must never render the same.
 */
import type { SentInvite } from './invite.ts';
import type { DesktopStats } from './stats.ts';
/** One metered allowance, exactly as the product reports it. */
export interface AccountMeter {
    /** Units consumed in the current window. */
    used: number;
    /** Units included, or null when the allowance is unmetered. */
    limit: number | null;
    /** ISO timestamp at which the window rolls over. */
    resetAt: string;
    /** Length of the window, in hours. */
    windowHours: number;
}
/** The account snapshot the browser receives. */
export interface AccountSnapshot {
    /**
     * Sign-in identity. `avatarUrl` is the data URL the product stores for this
     * account, absent when it has none — the same value the web product's own
     * settings page draws, so both surfaces show one photo rather than two.
     */
    user: {
        id: string;
        name: string | null;
        email: string;
        avatarUrl?: string;
    };
    /** Plan name as the product labels it; null when the account is on none. */
    plan: {
        key: string;
        name: string;
    } | null;
    /** Allowances by the product's own meter keys (`agentTurns`, `chatTokens`, ...). */
    usage: Record<string, AccountMeter>;
    /** Referral credits banked but not yet spent; absent when the call failed. */
    inviteCredits?: number;
    /** How many people this account has invited; absent when the call failed. */
    inviteCount?: number;
    /**
     * The invites themselves, in the order the product listed them. Absent when
     * the referral call failed, and empty for an account that has invited
     * nobody — which are different facts, so they arrive differently.
     *
     * Each row is built field by field from {@link SentInvite}'s own members, so
     * a column the product adds later cannot widen what a page receives. The
     * redemption link is among them deliberately: it is what the person is meant
     * to send to someone else, not a credential this desktop is holding.
     */
    invites?: SentInvite[];
    /**
     * Personal activity — the five Overview figures and the day series behind
     * the heatmap — absent when the call failed.
     *
     * It rides on this snapshot rather than being left to `/auth/stats` alone
     * because the browser's account gateway reads one endpoint: a figure that
     * does not arrive here is a figure the Overview strip cannot draw, and it
     * would render an em-dash for an account that has plenty of activity.
     * `/auth/stats` still serves the same record for a caller that wants only
     * this part of it.
     */
    stats?: DesktopStats;
}
/**
 * Fetch the account snapshot.
 *
 * `me` is the only required call: without it there is no account to describe
 * and the caller is told so. Usage, referrals, the profile, and the activity
 * statistics are additive — a deployment that meters nothing, runs no referral
 * programme, or predates either route is a normal deployment, not a failed
 * read, so those sections are simply absent.
 * @param baseUrl - the web product's origin, without a trailing slash.
 * @param apiKey - the desktop API key from the gate's session.
 * @param signal - cancels the requests.
 * @returns the snapshot, or undefined when the account could not be read.
 */
export declare function fetchAccountSnapshot(baseUrl: string, apiKey: string, signal?: AbortSignal): Promise<AccountSnapshot | undefined>;
//# sourceMappingURL=account.d.ts.map