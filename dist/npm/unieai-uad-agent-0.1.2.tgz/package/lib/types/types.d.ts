/**
 * Durable agent session-event vocabulary shared with type-only consumers.
 *
 * @module @unieai/uad-agent/types
 */
import type { UserMessage } from '@unieai/uad-llm/types';
/** One of the two ordered pending-message lists owned by an agent. */
export type InboxTarget = 'next-turn' | 'next-step';
declare module '@unieai/uad-session/types' {
    interface SessionEventMap {
        /**
         * One normalized mutation of an agent's durable pending-message lists.
         * Live dispatch precedes projection mutation, so synchronous observers may
         * read the pre-splice inbox to recover the removed messages.
         */
        'agent/inbox/spliced': {
            target: InboxTarget;
            start: number;
            removedCount?: number;
            inserted: UserMessage[];
            outcome?: 'canceled';
        };
    }
}
//# sourceMappingURL=types.d.ts.map